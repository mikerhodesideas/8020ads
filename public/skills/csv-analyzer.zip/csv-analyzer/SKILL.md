---
name: csv-analyzer
description: "Analyzes CSV files (including Google Ads reports, financial data, sales data) and generates comprehensive statistics, correlations, and visualizations. Use when user provides a CSV file or asks to analyze tabular data."
version: 1.0
---

# CSV Analyzer

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

Analyzes CSV files and provides comprehensive summaries with statistical insights and visualizations.

## When to Use

- User uploads or references a CSV file
- User asks to summarize, analyze, or visualize tabular data
- User requests insights from CSV data

## CRITICAL BEHAVIOR

**DO NOT ASK THE USER WHAT THEY WANT TO DO WITH THE DATA.**
**DO NOT OFFER OPTIONS OR CHOICES.**
**IMMEDIATELY AND AUTOMATICALLY:**
1. Run the comprehensive analysis
2. Generate ALL relevant visualizations
3. Present complete results
4. NO questions, NO options, NO waiting for user input

## How to Run

Run the bundled script at `scripts/analyze.py`:

```bash
python3 scripts/analyze.py /path/to/data.csv
```

For Google Ads ad group reports specifically, use:

```bash
python3 scripts/analyze_google_ads.py /path/to/report.csv
```

### Dependencies

The scripts require: `pandas>=2.0.0`, `matplotlib>=3.7.0`, `seaborn>=0.12.0`

Install with:
```bash
pip3 install pandas matplotlib seaborn
```

Or use the bundled dependency checker:
```bash
python3 scripts/check_deps.py
```

## Analysis Steps

The skill intelligently adapts to different data types:

1. **Load and inspect** the CSV file into pandas DataFrame
2. **Identify data structure** - column types, date columns, numeric columns, categories
3. **Determine relevant analyses** based on data type:
   - **Google Ads data**: Performance analysis, cost trends, conversion metrics
   - **Sales/E-commerce data**: Time-series trends, revenue analysis, product performance
   - **Customer data**: Distribution analysis, segmentation, geographic patterns
   - **Financial data**: Trend analysis, statistical summaries, correlations
   - **Generic tabular data**: Adapts based on column types found
4. **Only create visualizations that make sense** for the specific dataset
5. **Generate comprehensive output** including data overview, key statistics, missing data analysis, visualizations, and actionable insights
6. **Generate actionable insights** - interpret patterns and give specific, actionable advice connecting numbers to business decisions

## Output

- Text summary with statistics printed to stdout
- Visualization PNG files saved to the current working directory
- Key Insights & Recommendations section interpreting the patterns found
