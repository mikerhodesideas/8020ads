---
name: client-onboarding-kit
description: "Generate a complete onboarding package for new agency clients. Collects industry, services, URL, budget, and contacts, then produces platform access checklist, intake questionnaire, kickoff agenda, 30/60/90 plan, baseline audit checklist, and comms schedule as HTML files."
version: 1.0
---

# Client Onboarding Kit Generator

Triggers: "onboard client", "onboarding kit", "new client setup", `/client-onboarding-kit`

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

Collects inputs interactively, then generates 6 HTML documents for the new client.

## Workflow

### Phase 1: Discovery (Interactive)

Collect the following from the user. Ask all in a single structured prompt where practical.

**Question 1: Client basics** (free text)

Ask for: business name, website URL, industry/vertical, primary contact (name + email), secondary contact (optional).

**Question 2: Services purchased**

"Which services has this client purchased?"

| Option | Description |
|--------|-------------|
| Google Ads | Search, Shopping, PMax, Display, YouTube |
| Meta Ads | Facebook + Instagram advertising |
| SEO | Technical SEO, content, link building |
| Email Marketing | Campaign management, automation, list management |
| Analytics & Reporting | GA4 setup, dashboards, monthly reports |
| CRO | Landing pages, A/B testing, UX optimization |
| Social Media Management | Organic social content and community |
| Content Marketing | Blog, video, podcast content creation |

Allow multiple selections.

**Question 3: Budget and contract** (free text)

Ask for: monthly retainer/budget, contract length, start date, special terms.

**Question 4: Agency branding** (optional, free text)

Ask for: agency name (default: blank), primary brand color hex (default: #D64C00).

### Phase 2: Generate Documents

For each document below, generate the content using the collected inputs, then pipe the full JSON payload to the generation script:

```bash
echo '<JSON>' | node scripts/generate-kit.cjs --client-name "ClientName" --output /tmp/onboarding-kit/client-slug/
```

The script wraps content in consistent HTML styling and writes one file per document.

**Input JSON format:**
```json
{
  "clientName": "Acme Corp",
  "agencyName": "My Agency",
  "brandColor": "#D64C00",
  "date": "2026-03-21",
  "documents": [
    { "filename": "01-platform-access-checklist.html", "title": "Platform Access Checklist", "content": "<html content>" }
  ]
}
```

#### Document 1: Platform Access Checklist (`01-platform-access-checklist.html`)

Generate a checklist of every platform account the agency needs access to, customized by services purchased:

| Service | Required Access |
|---------|----------------|
| Google Ads | Google Ads account (MCC link or direct), Google Merchant Center (if Shopping/PMax) |
| Meta Ads | Facebook Business Manager, Ad Account, Pixel access, Instagram account |
| SEO | Google Search Console, Google Business Profile, CMS admin, hosting (for technical fixes) |
| Email Marketing | ESP access (Klaviyo/ActiveCampaign/Mailchimp), subscriber list export |
| Analytics & Reporting | GA4 property (editor access), GTM container, Looker Studio (if exists) |
| CRO | CMS admin, heatmap tool (Hotjar/Clarity), A/B testing tool access |
| Social Media | Platform business accounts, content calendar tool, brand asset folder |
| Content Marketing | CMS admin, brand guidelines doc, content calendar, image/video assets |

**Always include regardless of services:** Google Analytics (GA4), website CMS access, brand guidelines, logo files.

Each checklist item should have: platform name, access level needed, who to request it from, and a checkbox.

#### Document 2: Intake Questionnaire (`02-intake-questionnaire.html`)

Generate an industry-adapted questionnaire covering:

1. **Business Overview** (5-7 questions): Business model, target audience, USP, average deal value/AOV, sales cycle, seasonality
2. **Current Marketing** (4-6 questions): What is working, what is not, past agencies/freelancers, current monthly spend by channel
3. **Goals & KPIs** (3-5 questions): Primary goal (leads/sales/awareness), target CPA/ROAS, growth targets for next 6-12 months
4. **Competitive Landscape** (3-4 questions): Top 3 competitors, key differentiators, competitor strengths to worry about
5. **Brand & Messaging** (3-4 questions): Brand voice description, key messages that resonate, messages to avoid, approved terminology
6. **Service-Specific Questions**: Only include sections relevant to purchased services

Adapt question language to the industry.

#### Document 3: Kickoff Meeting Agenda (`03-kickoff-agenda.html`)

Generate a structured 60-minute kickoff agenda:

| Time | Topic | Duration | Notes |
|------|-------|----------|-------|
| 0:00 | Introductions & roles | 5 min | Who does what on both sides |
| 0:05 | Goals alignment | 10 min | Confirm targets from questionnaire |
| 0:15 | Current state walkthrough | 10 min | Review existing accounts/data together |
| 0:25 | Strategy overview | 10 min | High-level approach for first 90 days |
| 0:35 | Access & setup checklist review | 5 min | Walk through platform access status |
| 0:40 | Communication cadence | 5 min | Agree on meeting frequency, reporting, escalation |
| 0:45 | First 30 days: specific actions | 10 min | Concrete deliverables and timeline |
| 0:55 | Questions & next steps | 5 min | Action items with owners and deadlines |

Include preparation notes for each topic.

#### Document 4: 30/60/90 Day Plan (`04-thirty-sixty-ninety-plan.html`)

Generate milestone-based plan customized to services purchased:

**Days 1-30: Foundation** - Platform access, baseline performance, tracking verified, quick wins, service-specific setup tasks.

**Days 31-60: Optimization** - Audit findings addressed, testing framework, first optimizations live, initial performance comparison, service-specific optimization tasks.

**Days 61-90: Scale** - Performance trends, scaling strategy, first quarterly review, expansion opportunities, service-specific scaling tasks.

Each milestone should have: task description, owner (agency or client), due date (relative to start), and success criteria.

#### Document 5: Baseline Audit Checklist (`05-baseline-audit-checklist.html`)

Generate a checklist of everything to audit before making changes, customized by service. Each item: what to check, what good looks like, where to find the data, priority (must-do vs nice-to-have).

#### Document 6: Communication Schedule (`06-comms-schedule.html`)

Generate a communication cadence document covering: weekly status emails, bi-weekly/monthly strategy calls, monthly reports, quarterly business reviews, and ad-hoc escalation procedures.

### Phase 3: Output

1. Write all 6 HTML files to the output folder
2. Generate an index page (`index.html`) linking to all documents
3. Open the index page: `open /tmp/onboarding-kit/client-slug/index.html`

All documents: light theme, agency branding, client name in header, print-friendly CSS, interactive checkboxes, border-radius 2px max.
