---
name: client-onboarding-kit
description: "Generate a complete onboarding package for new agency clients. Takes industry, services, URL, budget, and contacts, then produces platform access checklist, intake questionnaire, kickoff agenda, 30/60/90 plan, baseline audit checklist, and comms schedule as HTML files."
version: 1.0
last_updated: 2026-03-21
members: true
context: fork
---

# Client Onboarding Kit Generator

Generate a complete onboarding package for a new agency client in one command. Replaces the 3-4 hours of manual document assembly that happens with every new client.

## When to Use

- New client signed, need onboarding documents
- "onboard client", "onboarding kit", "new client setup"
- `/client-onboarding-kit`

## Command Format

```
/client-onboarding-kit
```

No flags needed. The skill collects all inputs interactively.

## Workflow

### Phase 1: Discovery (Interactive)

Use `AskUserQuestion` to collect the following. Ask all in a single structured prompt where practical.

**Question 1: Client basics**

```
Please provide the new client's details:

1. Business name:
2. Website URL:
3. Industry/vertical: (e.g., plumbing, SaaS, ecommerce fashion)
4. Primary contact name and email:
5. Secondary contact name and email (optional):
```

This is a free-text question.

**Question 2: Services purchased**

"Which services has this client purchased?"

| Option | Description |
|--------|-------------|
| Google Ads | Search, Shopping, PMax, Display, YouTube |
| Meta Ads | Facebook + Instagram advertising |
| SEO | Technical SEO, content, link building |
| Email Marketing | Campaign management, automation, list management |
| Analytics & Reporting | GA4 setup, dashboards, monthly reports |
| CRO | Landing pages, A/B testing, UX optimization |
| Social Media Management | Organic social content and community |
| Content Marketing | Blog, video, podcast content creation |

Use AskUserQuestion with multiSelect: true.

**Question 3: Budget and contract**

```
Budget and contract details:

1. Monthly retainer/budget: (e.g., $5,000/month)
2. Contract length: (e.g., 6 months, 12 months, month-to-month)
3. Start date: (e.g., 2026-04-01)
4. Any special terms or notes:
```

This is a free-text question.

**Question 4: Agency branding (optional)**

```
Agency details for branding the documents (or press Enter to skip):

1. Agency name: (default: leave blank)
2. Primary brand color hex: (default: #D64C00)
```

This is a free-text question.

### Phase 2: Generate Documents

Run the generation script:

```bash
node .claude/skills/client-onboarding-kit/scripts/generate-kit.cjs \
  --client-name "ClientName" \
  --output /tmp/onboarding-kit/client-slug/
```

The script generates an HTML file per document. Claude generates the content for each document, then passes it to the script which wraps it in consistent HTML styling and writes the files.

For each document below, generate the content using the collected inputs, then write it as a standalone HTML file using the `generate-kit.cjs` helper for consistent styling.

#### Document 1: Platform Access Checklist

File: `01-platform-access-checklist.html`

Generate a checklist of every platform account the agency needs access to, customized by services purchased:

| Service | Required Access |
|---------|----------------|
| Google Ads | Google Ads account (MCC link or direct), Google Merchant Center (if Shopping/PMax) |
| Meta Ads | Facebook Business Manager, Ad Account, Pixel access, Instagram account |
| SEO | Google Search Console, Google Business Profile, CMS admin, hosting (for technical fixes) |
| Email Marketing | ESP access (Klaviyo/ActiveCampaign/Mailchimp), subscriber list export |
| Analytics & Reporting | GA4 property (editor access), GTM container, Looker Studio (if exists) |
| CRO | CMS admin, heatmap tool (Hotjar/Clarity), A/B testing tool access |
| Social Media | Platform business accounts, content calendar tool, brand asset folder |
| Content Marketing | CMS admin, brand guidelines doc, content calendar, image/video assets |

**Always include regardless of services:** Google Analytics (GA4), website CMS access, brand guidelines, logo files.

Each checklist item should have: platform name, access level needed, who to request it from, and a checkbox.

#### Document 2: Intake Questionnaire

File: `02-intake-questionnaire.html`

Generate an industry-adapted questionnaire covering:

1. **Business Overview** (5-7 questions): Business model, target audience, USP, average deal value/AOV, sales cycle, seasonality
2. **Current Marketing** (4-6 questions): What is working, what is not, past agencies/freelancers, current monthly spend by channel
3. **Goals & KPIs** (3-5 questions): Primary goal (leads/sales/awareness), target CPA/ROAS, growth targets for next 6-12 months
4. **Competitive Landscape** (3-4 questions): Top 3 competitors, key differentiators, competitor strengths to worry about
5. **Brand & Messaging** (3-4 questions): Brand voice description, key messages that resonate, messages to avoid, approved terminology
6. **Service-Specific Questions**: Only include sections relevant to purchased services

Adapt question language to the industry. A plumber gets different questions than a SaaS company.

#### Document 3: Kickoff Meeting Agenda

File: `03-kickoff-agenda.html`

Generate a structured 60-minute kickoff agenda:

| Time | Topic | Duration | Notes |
|------|-------|----------|-------|
| 0:00 | Introductions & roles | 5 min | Who does what on both sides |
| 0:05 | Goals alignment | 10 min | Confirm targets from questionnaire |
| 0:15 | Current state walkthrough | 10 min | Review existing accounts/data together |
| 0:25 | Strategy overview | 10 min | High-level approach for first 90 days |
| 0:35 | Access & setup checklist review | 5 min | Walk through platform access status |
| 0:40 | Communication cadence | 5 min | Agree on meeting frequency, reporting, escalation |
| 0:45 | First 30 days: specific actions | 10 min | Concrete deliverables and timeline |
| 0:55 | Questions & next steps | 5 min | Action items with owners and deadlines |

Include preparation notes for each topic: what the agency should have ready, what the client should prepare.

#### Document 4: 30/60/90 Day Plan

File: `04-thirty-sixty-ninety-plan.html`

Generate milestone-based plan customized to services purchased:

**Days 1-30: Foundation**
- Platform access secured and audited
- Baseline performance documented
- Tracking verified/fixed
- Quick wins identified and implemented
- Service-specific setup tasks (per purchased services)

**Days 31-60: Optimization**
- Initial audit findings addressed
- Testing framework established
- First round of optimizations live
- Initial performance comparison vs baseline
- Service-specific optimization tasks

**Days 61-90: Scale**
- Performance trends established
- Scaling strategy defined
- First quarterly review prepared
- Expansion opportunities identified
- Service-specific scaling tasks

Each milestone should have: task description, owner (agency or client), due date (relative to start), and success criteria.

#### Document 5: Baseline Audit Checklist

File: `05-baseline-audit-checklist.html`

Generate a checklist of everything to audit before making changes, customized by service:

**Google Ads:** Account structure, campaign settings, bid strategies, keyword coverage, negative keywords, ad copy quality, extensions, conversion tracking, audience lists, budget allocation
**Meta Ads:** Campaign structure, audience targeting, creative diversity, pixel events, attribution settings, placement performance, Advantage+ settings
**SEO:** Technical health (crawl errors, speed, mobile), on-page optimization, content inventory, backlink profile, keyword rankings, competitor gap
**Email:** List health, deliverability metrics, automation sequences, segmentation, template design, compliance (CAN-SPAM/GDPR)
**Analytics:** GA4 configuration, event tracking, conversion definitions, audience setup, attribution model, data retention settings
**CRO:** Current conversion rates by page, form completion rates, heatmap data review, user flow analysis

Each item: what to check, what good looks like, where to find the data, priority (must-do vs nice-to-have).

#### Document 6: Communication Schedule

File: `06-comms-schedule.html`

Generate a communication cadence document:

| Touchpoint | Frequency | Format | Attendees | Agenda |
|------------|-----------|--------|-----------|--------|
| Status update email | Weekly | Email | Primary contact | Metrics summary, completed tasks, upcoming tasks |
| Strategy call | Bi-weekly or monthly | Video call (30 min) | Primary + secondary contact | Performance review, strategy adjustments, approvals |
| Monthly report | Monthly | HTML/PDF report | All stakeholders | Full performance report with insights and recommendations |
| Quarterly business review | Quarterly | Video call (60 min) | All stakeholders + leadership | QBR deck: results, learnings, next quarter strategy |
| Ad-hoc escalation | As needed | Slack/email/call | Depends on issue | Urgent issues, budget changes, market shifts |

Include: escalation procedures, response time expectations (both directions), preferred communication channels, holiday/OOO handling.

### Phase 3: Output

1. Write all 6 HTML files to the output folder
2. Generate an index page (`index.html`) linking to all documents
3. Open the index page in the browser: `open /tmp/onboarding-kit/client-slug/index.html`
4. Report what was generated

### Output Format

All documents are standalone HTML files with:
- Light theme, clean professional design
- Agency branding (name and color from Phase 1, or defaults)
- Client name and date in header
- Print-friendly CSS (looks good when printed to PDF)
- Checkboxes where applicable (interactive in browser)
- border-radius: 2px maximum (no rounded corners)

## Files

| File | Purpose |
|------|---------|
| `SKILL.md` | This file (skill definition and workflow) |
| `scripts/generate-kit.cjs` | HTML template generator and file writer |

## Dependencies

No additional dependencies. Uses Node.js built-in `fs` and `path` modules only.
