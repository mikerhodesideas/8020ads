#!/usr/bin/env node

/**
 * Client Onboarding Kit - HTML Generator
 *
 * Generates branded, print-friendly HTML documents for client onboarding.
 * Each document is a standalone HTML file with consistent styling.
 *
 * Usage:
 *   node generate-kit.cjs --client-name "Acme Corp" --output /tmp/onboarding-kit/acme-corp/
 *
 * The script reads JSON content from stdin (piped from Claude) and generates
 * individual HTML files plus an index page.
 *
 * Input JSON format:
 * {
 *   "clientName": "Acme Corp",
 *   "agencyName": "My Agency",
 *   "brandColor": "#D64C00",
 *   "date": "2026-03-21",
 *   "documents": [
 *     { "filename": "01-platform-access-checklist.html", "title": "Platform Access Checklist", "content": "<html content>" },
 *     ...
 *   ]
 * }
 */

const fs = require('fs');
const path = require('path');

// Parse CLI args
const args = process.argv.slice(2);
let clientName = '';
let outputDir = '/tmp/onboarding-kit/';

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--client-name' && args[i + 1]) {
    clientName = args[++i];
  } else if (args[i] === '--output' && args[i + 1]) {
    outputDir = args[++i];
  }
}

// Read JSON from stdin
let inputData = '';
process.stdin.setEncoding('utf-8');
process.stdin.on('data', (chunk) => { inputData += chunk; });
process.stdin.on('end', () => {
  try {
    const data = JSON.parse(inputData);
    generateKit(data);
  } catch (err) {
    console.error('Error parsing input JSON:', err.message);
    process.exit(1);
  }
});

function generateKit(data) {
  const {
    clientName: name = clientName,
    agencyName = '',
    brandColor = '#D64C00',
    date = new Date().toISOString().split('T')[0],
    documents = []
  } = data;

  // Ensure output directory exists
  fs.mkdirSync(outputDir, { recursive: true });

  const cssTemplate = getCSS(brandColor);

  // Write each document
  documents.forEach((doc) => {
    const html = wrapInHTML(doc.title, doc.content, name, agencyName, date, cssTemplate);
    const filePath = path.join(outputDir, doc.filename);
    fs.writeFileSync(filePath, html, 'utf-8');
    console.log(`Written: ${filePath}`);
  });

  // Generate index page
  const indexContent = generateIndex(name, agencyName, date, documents, brandColor);
  const indexPath = path.join(outputDir, 'index.html');
  fs.writeFileSync(indexPath, indexContent, 'utf-8');
  console.log(`Written: ${indexPath}`);
  console.log(`\nOnboarding kit generated: ${outputDir}`);
}

function wrapInHTML(title, content, clientName, agencyName, date, css) {
  const agencyLine = agencyName ? `<div class="agency">${escapeHtml(agencyName)}</div>` : '';
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)} - ${escapeHtml(clientName)}</title>
  <style>${css}</style>
</head>
<body>
  <header>
    ${agencyLine}
    <h1>${escapeHtml(title)}</h1>
    <div class="meta">Prepared for <strong>${escapeHtml(clientName)}</strong> | ${escapeHtml(date)}</div>
  </header>
  <main>
    ${content}
  </main>
  <footer>
    <p>Confidential | Prepared for ${escapeHtml(clientName)} | ${escapeHtml(date)}</p>
  </footer>
</body>
</html>`;
}

function generateIndex(clientName, agencyName, date, documents, brandColor) {
  const agencyLine = agencyName ? `<div class="agency">${escapeHtml(agencyName)}</div>` : '';
  const links = documents.map((doc) =>
    `<a href="${doc.filename}" class="doc-link">
      <span class="doc-title">${escapeHtml(doc.title)}</span>
      <span class="doc-arrow">&rarr;</span>
    </a>`
  ).join('\n    ');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Onboarding Kit - ${escapeHtml(clientName)}</title>
  <style>${getCSS(brandColor)}
  .doc-link {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    margin-bottom: 8px;
    background: #f8f8f8;
    border-left: 3px solid ${brandColor};
    text-decoration: none;
    color: #1a1a1a;
    transition: background 0.15s;
  }
  .doc-link:hover { background: #f0f0f0; }
  .doc-title { font-weight: 600; font-size: 1.05rem; }
  .doc-arrow { color: ${brandColor}; font-size: 1.2rem; }
  </style>
</head>
<body>
  <header>
    ${agencyLine}
    <h1>Client Onboarding Kit</h1>
    <div class="meta">Prepared for <strong>${escapeHtml(clientName)}</strong> | ${escapeHtml(date)}</div>
  </header>
  <main>
    <h2>Documents</h2>
    ${links}
  </main>
  <footer>
    <p>Confidential | Prepared for ${escapeHtml(clientName)} | ${escapeHtml(date)}</p>
  </footer>
</body>
</html>`;
}

function getCSS(brandColor) {
  return `
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #1a1a1a;
      max-width: 900px;
      margin: 0 auto;
      padding: 40px 24px;
      background: #fff;
    }
    header {
      border-bottom: 2px solid ${brandColor};
      padding-bottom: 20px;
      margin-bottom: 32px;
    }
    header .agency {
      font-size: 0.85rem;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: ${brandColor};
      margin-bottom: 8px;
    }
    header h1 { font-size: 1.8rem; font-weight: 700; margin-bottom: 8px; }
    header .meta { font-size: 0.9rem; color: #666; }
    main h2 {
      font-size: 1.3rem;
      margin: 28px 0 12px 0;
      padding-bottom: 6px;
      border-bottom: 1px solid #e0e0e0;
    }
    main h3 { font-size: 1.1rem; margin: 20px 0 8px 0; color: #333; }
    p, li { margin-bottom: 8px; }
    ul, ol { padding-left: 24px; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 16px 0;
      font-size: 0.9rem;
    }
    th, td {
      padding: 10px 12px;
      text-align: left;
      border-bottom: 1px solid #e0e0e0;
    }
    th {
      background: #1a1a1a;
      color: #fff;
      font-weight: 600;
    }
    tr:hover { background: #f8f8f8; }
    .checkbox-item {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid #f0f0f0;
    }
    .checkbox-item input[type="checkbox"] {
      margin-top: 4px;
      width: 18px;
      height: 18px;
      accent-color: ${brandColor};
    }
    .highlight {
      background: #fff8f0;
      border-left: 3px solid ${brandColor};
      padding: 12px 16px;
      margin: 16px 0;
    }
    .phase-header {
      background: #1a1a1a;
      color: #fff;
      padding: 12px 16px;
      margin: 24px 0 0 0;
      font-weight: 600;
      font-size: 1.1rem;
    }
    footer {
      margin-top: 48px;
      padding-top: 16px;
      border-top: 1px solid #e0e0e0;
      font-size: 0.8rem;
      color: #999;
      text-align: center;
    }
    @media print {
      body { padding: 20px; }
      .checkbox-item { break-inside: avoid; }
      header { break-after: avoid; }
      h2, h3 { break-after: avoid; }
      table { break-inside: avoid; }
    }
  `;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
