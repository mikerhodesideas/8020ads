---
name: form-optimization-auditor
description: "Analyze a web form's HTML structure, field composition, and UX to estimate abandonment risk and recommend improvements. Scores 12 dimensions and outputs a report with field-by-field recommendations."
version: 1.0
---

# Form Optimization Auditor

Analyze a web form's HTML structure, field composition, and UX to estimate abandonment risk and recommend specific improvements. Produces a scored assessment with field-by-field recommendations.

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

## When to Use

- User provides a URL with a form they want optimized
- User asks about form abandonment or completion rates
- User provides form HTML and wants a UX review
- User says "form audit", "optimize form", "form conversion"

## Input Requirements

Gather from the user:
1. **Form URL** - The page containing the form
2. **Form purpose** - lead-gen, checkout, signup, contact, application, booking
3. **Current completion rate** (optional) - For baseline comparison
4. **Client/report name** - For the output report

## Process

### Step 1: Fetch Form HTML

Use WebFetch to retrieve the page. Extract all form elements including inputs, labels, buttons, validation attributes, placeholders, and surrounding trust signals.

Save the extracted content as JSON.

**If no forms found:** Still produce a report. Score 0/100 (Grade F) with recommendations for what an ideal form would look like.

### Step 2: Parse Form Structure

Run the bundled parser at `scripts/parse-form.cjs`:

```bash
node scripts/parse-form.cjs \
  --input="page-content.json" \
  --output="form-structure.json"
```

### Step 3: Score the Form

Run the bundled scorer at `scripts/score-form.cjs`:

```bash
node scripts/score-form.cjs \
  --input="form-structure.json" \
  --purpose="lead-gen" \
  --output="scores.json"
```

Scores 12 dimensions:

| Dimension | Points | What It Measures |
|-----------|--------|-----------------|
| Field Count | 15 | Number of fields vs purpose |
| Required/Optional Ratio | 10 | Ambiguity from optional fields |
| Field Type Optimization | 10 | Correct HTML5 types, autocomplete |
| Label Clarity | 10 | Visible labels, descriptiveness |
| Placeholder Usage | 5 | Not used as labels |
| Mobile Input | 10 | Correct keyboards, touch targets |
| Multi-Step Structure | 5 | Progress indicators for long forms |
| Validation UX | 10 | Inline validation, error messages |
| CTA Quality | 10 | Value-oriented vs generic button text |
| Trust Signals | 10 | Privacy text, security badges |
| Above-Fold Placement | 5 | Form visibility without scrolling |
| Accessibility | bonus | Label association, ARIA, tab order |

### Step 4: Generate HTML Report

Run the bundled report generator at `scripts/generate-report.cjs`:

```bash
node scripts/generate-report.cjs \
  --input="scores.json" \
  --name="Client Name" \
  --output="form-audit-report.html"
```

### Step 5: Open Report

Open the HTML report in the browser.

## Grading Scale

| Grade | Score | Meaning |
|-------|-------|---------|
| A | 85-100 | Well-optimized, minor tweaks only |
| B | 70-84 | Good foundation, specific improvements will help |
| C | 55-69 | Significant friction, losing completions |
| D | 40-54 | Major issues hurting conversions |
| F | Below 40 | Needs complete redesign |

## Key Rules

1. Every field you remove is a win - be aggressive about identifying removable fields
2. Mobile-first analysis for >50% mobile traffic
3. Context matters for field count - 3-field lead gen vs 12-field mortgage are different
4. "Submit" is always wrong - CTA should mirror the value the user gets
5. Placeholders are not labels - always flag this
6. Impact estimates are directional ranges, not precise numbers
