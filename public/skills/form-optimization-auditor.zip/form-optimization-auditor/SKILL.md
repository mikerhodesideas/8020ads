---
name: form-optimization-auditor
description: |
  Analyze a web form's HTML structure, field composition, and UX to estimate abandonment risk and
  recommend improvements. Fetches page, identifies form elements, evaluates field count, required/optional
  ratio, field types, label clarity, mobile input types, multi-step structure, validation, CTA text,
  trust signals, and above-fold placement. Outputs scored assessment with field-by-field recommendations.
  AUTO-ACTIVATE for: "form audit", "form optimization", "form abandonment", "form conversion",
  "form UX", "form analysis", "optimize form", "form completion rate", "form fields".
version: 1.0
last_updated: 2026-03-21
members: true
context: fork
hooks:
  PreToolUse:
    - matcher: "WebFetch"
      command: "sleep 2"
---

# Form Optimization Auditor

Analyze a web form's HTML structure, field composition, and UX to estimate abandonment risk and recommend specific improvements. Produces a scored assessment with field-by-field recommendations and estimated completion rate improvement for each change.

## When to Use

- User provides a URL with a form they want optimized
- User asks about form abandonment or completion rates
- User provides form HTML and wants a UX review
- User says "form audit", "optimize form", "form conversion", "form abandonment"
- User wants to reduce friction in their lead gen or checkout form

## Input Requirements

**Required:**
- URL of a page containing a form, OR raw HTML of the form

**Optional:**
- Current form completion rate (if known)
- Industry context (lead gen, e-commerce checkout, SaaS signup, contact form)
- Mobile vs desktop traffic split
- Prepared by name for the report

## Process

### Step 0: Gather Information

Ask the user for:
1. **Form URL** - The page containing the form to audit
2. **Form purpose** - Lead gen, checkout, signup, contact, application, booking
3. **Current completion rate** (optional) - If known, for baseline comparison
4. **Client/report name** - For the output report

### Step 1: Fetch and Extract Form HTML

Use WebFetch to retrieve the page:

```
WebFetch URL with prompt: "Extract all form elements from this page. For each form, capture: the complete form HTML including all input fields, labels, buttons, select elements, textareas, fieldsets, validation attributes, placeholder text, required attributes, input types, aria labels, and any surrounding trust signals (privacy text, security badges, testimonials near the form). Also note the form's position on the page (above or below the fold based on HTML structure)."
```

Save the extracted form data to a temp file for the analysis script.

### Step 2: Parse Form Structure

```bash
node .claude/skills/form-optimization-auditor/scripts/parse-form.cjs \
  --input=".claude/skills/form-optimization-auditor/tmp/page-content.json" \
  --output=".claude/skills/form-optimization-auditor/tmp/form-structure.json"
```

The script identifies and catalogs:
- Every `<input>`, `<select>`, `<textarea>`, `<button>` element
- Field attributes: type, name, id, required, pattern, minlength, maxlength, placeholder, autocomplete
- Associated `<label>` elements (by `for` attribute or wrapping)
- Fieldset/legend groupings
- Multi-step indicators (step divs, progress bars, next/back buttons)
- Submit button text and styling
- Surrounding context (trust signals, help text, error patterns)

Output schema:
```json
{
  "forms": [{
    "id": "lead-form",
    "action": "/submit",
    "method": "POST",
    "fields": [
      {
        "element": "input",
        "type": "text",
        "name": "full_name",
        "label": "Full Name",
        "required": true,
        "placeholder": "Enter your name",
        "autocomplete": "name",
        "mobileInputType": "text",
        "position": 1
      }
    ],
    "submitButton": { "text": "Submit", "type": "submit" },
    "multiStep": false,
    "trustSignals": ["Privacy policy link"],
    "aboveFold": true
  }]
}
```

### Step 3: Score the Form

```bash
node .claude/skills/form-optimization-auditor/scripts/score-form.cjs \
  --input=".claude/skills/form-optimization-auditor/tmp/form-structure.json" \
  --purpose="lead-gen" \
  --output=".claude/skills/form-optimization-auditor/tmp/scores.json"
```

The script evaluates 12 scoring dimensions:

#### Dimension 1: Field Count (15 points)
- **3 or fewer fields**: 15/15 (optimal for lead gen)
- **4-5 fields**: 12/15
- **6-7 fields**: 9/15
- **8-10 fields**: 6/15
- **11+ fields**: 3/15
- Context-adjusted: checkout forms get more lenient scoring (up to 8 fields is normal)
- Each field above the optimal count for the form type incurs ~5-10% estimated completion rate reduction

#### Dimension 2: Required vs Optional Ratio (10 points)
- Best: 100% of fields are required (if you're asking for it, require it; if you don't need it, remove it)
- Deduction for optional fields that should either be required or removed (ambiguity kills completion)
- Deduction for requiring fields that rarely need to be required (phone, company name, job title in early lead gen)

#### Dimension 3: Field Type Optimization (10 points)
- Correct HTML5 input types: `email` for email, `tel` for phone, `number` for numeric, `url` for URLs
- Date fields using `date` type (not text)
- Dropdowns (`<select>`) where there are <7 fixed options (radio buttons better for <5 options)
- Checkboxes for multi-select instead of multi-select dropdown
- Autofill-friendly: `autocomplete` attributes present and correct

#### Dimension 4: Label Clarity (10 points)
- Every field has a visible `<label>` (not just placeholder text)
- Labels are descriptive: "Work email address" better than "Email"
- Labels are above the field (not inline or to the left, which performs worse on mobile)
- No ambiguous labels ("Name" could mean first, last, or full)
- No jargon in labels

#### Dimension 5: Placeholder Text Usage (5 points)
- Placeholders are NOT used as labels (disappear on focus, fail accessibility)
- Placeholders provide helpful examples when present ("e.g., john@company.com")
- No placeholder-only fields (no visible label)

#### Dimension 6: Mobile Input Optimization (10 points)
- `inputmode` or correct `type` attributes trigger the right mobile keyboard
  - `type="email"` or `inputmode="email"` for email fields
  - `type="tel"` or `inputmode="tel"` for phone fields
  - `inputmode="numeric"` for number-only fields (zip codes, quantities)
- Touch target sizes (fields and buttons should be at least 44px tall)
- No tiny checkboxes or radio buttons
- Single-column layout indicators

#### Dimension 7: Multi-Step vs Single-Step (5 points)
- For forms with 5+ fields: multi-step with progress indicator scores higher
- Progress indicator present and clear (step X of Y, or progress bar)
- Each step has a clear, descriptive heading
- Back button available on each step

#### Dimension 8: Validation UX (10 points)
- Inline validation attributes present (pattern, required, minlength, maxlength)
- Real-time validation indicators (not just on submit)
- Error messages are specific, not generic ("Please enter a valid email" not "Invalid input")
- Success states for completed fields (green checkmarks)
- No aggressive validation (marking fields red before the user has finished typing)

#### Dimension 9: CTA Button Quality (10 points)
- Button text is specific and value-oriented:
  - Best: "Get Your Free Quote", "Start My Trial", "Download the Guide"
  - Good: "Sign Up", "Register"
  - Poor: "Submit", "Send", "Go"
- Button is visually prominent (high contrast, adequate size)
- Single primary CTA (no competing buttons)
- Button text matches the offer/page headline

#### Dimension 10: Trust Signals (10 points)
- Privacy text near the form ("We'll never share your email")
- Privacy policy link present
- Security badges (SSL, payment processors for checkout)
- Social proof near the form (testimonials, customer count, rating)
- No-spam promise for email collection forms
- Money-back guarantee for payment forms

#### Dimension 11: Above-Fold Placement (5 points)
- Form (or at least the first step + CTA) is visible without scrolling on desktop
- On mobile: form is within first 1-2 screens of scroll
- If below fold: there's a clear anchor link or scroll indicator pointing to the form

#### Dimension 12: Accessibility (bonus, reported but not scored into main total)
- Proper `<label>` to `<input>` association (for/id match)
- ARIA labels where needed
- Tab order is logical
- Focus states visible
- Color contrast on labels and buttons

### Step 4: Generate Field-by-Field Recommendations

For each field in the form, the analysis produces:
- **Keep / Remove / Make Optional / Modify** recommendation
- Specific changes: rename label, change input type, add autocomplete attribute, etc.
- Estimated completion rate impact of each change
- Priority (high/medium/low)

Common field-level recommendations:

| Field Pattern | Issue | Fix | Impact |
|--------------|-------|-----|--------|
| "Phone" required on lead gen | Unnecessary friction | Make optional or remove | +5-15% completion |
| "Company" on initial contact form | Too much too soon | Remove or defer to follow-up | +3-8% completion |
| Text input for "State" | Unnecessary typing | Change to dropdown | +2-4% completion |
| No autocomplete on name/email | Missed easy win | Add autocomplete attributes | +3-7% completion |
| "Submit" button text | Generic, low motivation | Change to value-oriented CTA | +3-10% completion |
| No visible labels (placeholder only) | Accessibility + usability fail | Add visible labels above fields | +5-12% completion |
| No trust signals near form | Trust barrier | Add privacy text + social proof | +5-15% completion |

### Step 5: Generate HTML Report

```bash
node .claude/skills/form-optimization-auditor/scripts/generate-report.cjs \
  --input=".claude/skills/form-optimization-auditor/tmp/scores.json" \
  --name="Client Name" \
  --output="output/form-audit-CLIENTNAME.html"
```

The report includes:
1. **Overall Form Score** (0-100) with letter grade
2. **Form Screenshot/Visualization** - Annotated representation showing each field and its score
3. **Scoring Breakdown** - Visual bars for each of the 12 dimensions
4. **Field-by-Field Analysis** - Table with every field, its current state, and specific recommendation
5. **Estimated Impact Summary** - Total estimated completion rate improvement if all recommendations are implemented
6. **Priority Action List** - Top 5 changes ranked by impact, with specific implementation instructions
7. **Before/After Mockup** - Text description of the optimized form structure
8. **Mobile-Specific Recommendations** - Separate section for mobile optimization

Open in browser:
```bash
open output/form-audit-CLIENTNAME.html
```

## Scoring Scale

**Overall Form Score** = sum of all dimensions (100 max):

| Grade | Score | Interpretation |
|-------|-------|---------------|
| A | 85-100 | Well-optimized, minor tweaks only |
| B | 70-84 | Good foundation, specific improvements will help |
| C | 55-69 | Significant friction, likely losing completions |
| D | 40-54 | Major issues, form is actively hurting conversions |
| F | Below 40 | Needs complete redesign |

## Output Files

| File | Purpose |
|------|---------|
| `tmp/page-content.json` | Fetched page content (ephemeral) |
| `tmp/form-structure.json` | Parsed form structure (ephemeral) |
| `tmp/scores.json` | Complete scoring data (ephemeral) |
| User-specified HTML | Formatted form audit report |

## Example Prompts

> "Audit the form on this landing page: https://example.com/contact"

> "Here's our lead gen form HTML. It currently converts at 12%. How can we improve it?"

> "Check the checkout form at this URL for mobile optimization issues."

> "We have a 15-field application form. Which fields should we remove or change?"

## Key Rules

1. **Every field you remove is a win** - The single most impactful recommendation for most forms is removing unnecessary fields. Be aggressive about identifying fields that can be removed or deferred.
2. **Mobile-first analysis** - If the client gets >50% mobile traffic, mobile optimization issues should be top priority even if they score lower in the overall weighting.
3. **Context matters for field count** - A 3-field lead gen form and a 12-field mortgage application have very different optimal field counts. Always adjust scoring for form purpose.
4. **"Submit" is always wrong** - Every CTA audit should flag generic button text. The CTA should mirror the value the user gets.
5. **Placeholders are not labels** - This is one of the most common form UX mistakes. Always flag it, even if the form looks "clean" without visible labels.
6. **Impact estimates are directional, not precise** - Quote ranges ("+5-10% completion rate improvement") not exact numbers. These are based on industry research averages, not guarantees.
7. **Trust signals matter more on high-commitment forms** - A newsletter signup needs minimal trust signals. A form collecting payment info or personal health data needs maximum trust.
8. **Test, don't assume** - Always recommend that significant form changes be A/B tested rather than just shipped. Reference the ab-test-analyzer skill for measuring results.

## Related Skills

- `ab-test-analyzer` - For testing form changes after implementation
- `funnel-drop-off-analyzer` - For understanding where form abandonment fits in the broader funnel
- `sellable-landing-page-audit` - For auditing the full landing page, not just the form
