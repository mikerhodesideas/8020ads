#!/usr/bin/env node
/**
 * score-form.cjs
 * Score a parsed form structure across 12 UX dimensions.
 *
 * Usage:
 *   node score-form.cjs --input=form-structure.json --purpose=lead-gen --output=scores.json
 */

const fs = require('fs');
const path = require('path');

function parseArgs() {
  const args = {};
  process.argv.slice(2).forEach(arg => {
    const [key, ...vals] = arg.replace(/^--/, '').split('=');
    args[key] = vals.join('=');
  });
  return args;
}

const PURPOSE_FIELD_THRESHOLDS = {
  'lead-gen': { optimal: 3, acceptable: 5, max: 7 },
  'contact': { optimal: 3, acceptable: 4, max: 6 },
  'signup': { optimal: 3, acceptable: 4, max: 5 },
  'checkout': { optimal: 6, acceptable: 8, max: 12 },
  'application': { optimal: 8, acceptable: 12, max: 20 },
  'booking': { optimal: 4, acceptable: 6, max: 8 }
};

const GOOD_CTA_PATTERNS = [
  /get\s+(your|my|a|the)/i, /start/i, /download/i, /claim/i, /book/i,
  /schedule/i, /request/i, /try/i, /join/i, /unlock/i, /access/i
];
const BAD_CTA_WORDS = ['submit', 'send', 'go', 'ok', 'continue', 'next'];

const AUTOCOMPLETE_MAP = {
  'name': ['name', 'given-name', 'family-name'],
  'email': ['email'],
  'phone': ['tel'],
  'address': ['street-address', 'address-line1'],
  'city': ['address-level2'],
  'state': ['address-level1'],
  'zip': ['postal-code'],
  'country': ['country-name', 'country'],
  'company': ['organization'],
  'url': ['url']
};

function scoreFieldCount(form, purpose) {
  const thresholds = PURPOSE_FIELD_THRESHOLDS[purpose] || PURPOSE_FIELD_THRESHOLDS['lead-gen'];
  const count = form.totalFields;
  const maxScore = 15;

  if (count <= thresholds.optimal) return { score: maxScore, notes: [`${count} fields (optimal for ${purpose})`], recommendations: [] };
  if (count <= thresholds.acceptable) return { score: 12, notes: [`${count} fields (acceptable for ${purpose})`], recommendations: ['Consider reducing to ' + thresholds.optimal + ' fields'] };
  if (count <= thresholds.max) return { score: 9, notes: [`${count} fields (above optimal for ${purpose})`], recommendations: ['Remove or defer ' + (count - thresholds.optimal) + ' non-essential fields'] };
  if (count <= thresholds.max + 3) return { score: 6, notes: [`${count} fields (too many for ${purpose})`], recommendations: ['Significant field reduction needed. Each field above ' + thresholds.optimal + ' reduces completion by ~5-10%'] };
  return { score: 3, notes: [`${count} fields (excessive for ${purpose})`], recommendations: ['Redesign form. Consider multi-step or splitting into phases'] };
}

function scoreRequiredOptional(form) {
  const maxScore = 10;
  let score = maxScore;
  const notes = [];
  const recs = [];

  if (form.optionalFields > 0) {
    score -= Math.min(4, form.optionalFields * 2);
    notes.push(`${form.optionalFields} optional field(s) create ambiguity`);
    recs.push('Either make optional fields required or remove them entirely');
  }

  // Check for commonly over-required fields
  const overRequired = form.fields.filter(f =>
    f.required && /phone|company|title|fax|organization/i.test(f.name + f.label)
  );
  if (overRequired.length > 0) {
    score -= overRequired.length * 2;
    notes.push(`${overRequired.length} potentially over-required field(s): ${overRequired.map(f => f.label || f.name).join(', ')}`);
    recs.push('Consider making these optional or removing: ' + overRequired.map(f => f.label || f.name).join(', '));
  }

  return { score: Math.max(0, score), notes, recommendations: recs };
}

function scoreFieldTypes(form) {
  const maxScore = 10;
  let score = maxScore;
  const notes = [];
  const recs = [];

  for (const field of form.fields) {
    const name = (field.name + ' ' + (field.label || '')).toLowerCase();

    // Check email fields use email type
    if (/email/i.test(name) && field.type !== 'email') {
      score -= 2;
      recs.push(`Change "${field.label || field.name}" from type="${field.type}" to type="email" for proper mobile keyboard`);
    }
    // Check phone fields use tel type
    if (/phone|tel|mobile|cell/i.test(name) && field.type !== 'tel') {
      score -= 2;
      recs.push(`Change "${field.label || field.name}" from type="${field.type}" to type="tel" for numeric keyboard`);
    }
    // Check URL fields
    if (/url|website|site/i.test(name) && field.type !== 'url') {
      score -= 1;
      recs.push(`Change "${field.label || field.name}" to type="url"`);
    }
    // Check autocomplete
    if (!field.autocomplete && field.element === 'input') {
      for (const [pattern, values] of Object.entries(AUTOCOMPLETE_MAP)) {
        if (new RegExp(pattern, 'i').test(name)) {
          score -= 1;
          recs.push(`Add autocomplete="${values[0]}" to "${field.label || field.name}"`);
          break;
        }
      }
    }
  }

  if (recs.length === 0) notes.push('All field types are optimized');

  return { score: Math.max(0, score), notes, recommendations: recs };
}

function scoreLabelClarity(form) {
  const maxScore = 10;
  let score = maxScore;
  const notes = [];
  const recs = [];

  const unlabeled = form.fields.filter(f => !f.label);
  if (unlabeled.length > 0) {
    score -= unlabeled.length * 3;
    recs.push(`${unlabeled.length} field(s) missing visible labels: ${unlabeled.map(f => f.name || f.type).join(', ')}. Add <label> elements.`);
  }

  // Check for vague labels
  const vagueLabels = form.fields.filter(f => f.label && /^(name|info|data|details|other)$/i.test(f.label.trim()));
  if (vagueLabels.length > 0) {
    score -= vagueLabels.length;
    recs.push(`Improve vague labels: ${vagueLabels.map(f => `"${f.label}" -> more specific`).join(', ')}`);
  }

  if (recs.length === 0) notes.push('Labels are clear and descriptive');

  return { score: Math.max(0, score), notes, recommendations: recs };
}

function scorePlaceholders(form) {
  const maxScore = 5;
  let score = maxScore;
  const notes = [];
  const recs = [];

  // Check for placeholder-only fields (no label)
  const placeholderOnly = form.fields.filter(f => f.placeholder && !f.label);
  if (placeholderOnly.length > 0) {
    score -= Math.min(5, placeholderOnly.length * 2);
    recs.push(`${placeholderOnly.length} field(s) use placeholder as label. Add visible <label> elements. Placeholders disappear on focus and fail accessibility.`);
  }

  if (recs.length === 0) notes.push('Placeholder usage is appropriate');

  return { score: Math.max(0, score), notes, recommendations: recs };
}

function scoreMobileInput(form) {
  const maxScore = 10;
  let score = maxScore;
  const notes = [];
  const recs = [];

  for (const field of form.fields) {
    const name = (field.name + ' ' + (field.label || '')).toLowerCase();

    // Check inputmode for numeric fields
    if (/zip|postal|quantity|amount|age/i.test(name) && !field.inputmode && field.type === 'text') {
      score -= 1;
      recs.push(`Add inputmode="numeric" to "${field.label || field.name}" for numeric mobile keyboard`);
    }

    // Check email/tel types trigger correct keyboard
    if (/email/i.test(name) && field.type !== 'email' && field.inputmode !== 'email') {
      score -= 2;
      recs.push(`"${field.label || field.name}" won't trigger email keyboard on mobile`);
    }
    if (/phone/i.test(name) && field.type !== 'tel' && field.inputmode !== 'tel') {
      score -= 2;
      recs.push(`"${field.label || field.name}" won't trigger phone keyboard on mobile`);
    }
  }

  if (recs.length === 0) notes.push('Mobile input types are well-configured');

  return { score: Math.max(0, score), notes, recommendations: recs };
}

function scoreMultiStep(form) {
  const maxScore = 5;
  const notes = [];
  const recs = [];

  if (form.totalFields <= 4) {
    return { score: maxScore, notes: ['Single-step form is appropriate for field count'], recommendations: [] };
  }

  if (form.totalFields >= 5 && !form.multiStep) {
    return {
      score: 2,
      notes: [`${form.totalFields} fields in a single step`],
      recommendations: ['Consider breaking into multi-step form with progress indicator. Forms with 5+ fields see higher completion rates when split into logical steps.']
    };
  }

  if (form.multiStep) {
    return { score: maxScore, notes: ['Multi-step form detected'], recommendations: [] };
  }

  return { score: 3, notes: [], recommendations: [] };
}

function scoreValidation(form) {
  const maxScore = 10;
  let score = 5; // Start at 5, give credit for validation attributes
  const notes = [];
  const recs = [];

  const fieldsWithPattern = form.fields.filter(f => f.pattern);
  const fieldsWithMinMax = form.fields.filter(f => f.minlength || f.maxlength);
  const requiredFields = form.fields.filter(f => f.required);

  if (requiredFields.length > 0) {
    score += 2;
    notes.push(`${requiredFields.length} field(s) have HTML required attribute`);
  } else if (form.totalFields > 0) {
    recs.push('Add required attribute to mandatory fields for inline validation');
  }

  if (fieldsWithPattern.length > 0) {
    score += 2;
    notes.push(`${fieldsWithPattern.length} field(s) have validation patterns`);
  }

  if (fieldsWithMinMax.length > 0) {
    score += 1;
  }

  // Can't fully detect JS validation from HTML alone, note this
  notes.push('Note: JavaScript-based real-time validation cannot be assessed from HTML alone');

  return { score: Math.min(maxScore, score), notes, recommendations: recs };
}

function scoreCTA(form) {
  const maxScore = 10;
  let score = maxScore;
  const notes = [];
  const recs = [];
  const ctaText = form.submitButton.text.toLowerCase().trim();

  if (BAD_CTA_WORDS.includes(ctaText)) {
    score = 3;
    recs.push(`Change CTA from "${form.submitButton.text}" to a value-oriented phrase like "Get Your Free Quote", "Start My Trial", or "Download the Guide"`);
  } else if (GOOD_CTA_PATTERNS.some(p => p.test(ctaText))) {
    notes.push(`CTA "${form.submitButton.text}" is value-oriented`);
  } else {
    score = 7;
    notes.push(`CTA "${form.submitButton.text}" is acceptable but could be more compelling`);
    recs.push(`Consider making CTA more specific to the offer value`);
  }

  return { score, notes, recommendations: recs };
}

function scoreTrustSignals(form, purpose) {
  const maxScore = 10;
  let score = 0;
  const notes = [];
  const recs = [];

  const signalCount = form.trustSignals.length;
  score = Math.min(maxScore, signalCount * 3);

  if (signalCount === 0) {
    recs.push('Add trust signals near the form: privacy text, no-spam promise, or social proof');
    if (purpose === 'checkout' || purpose === 'application') {
      recs.push('For high-commitment forms, add security badges and money-back guarantee');
    }
  } else {
    notes.push(`${signalCount} trust signal(s) detected: ${form.trustSignals.join(', ')}`);
  }

  if (!form.trustSignals.includes('Privacy policy reference') && purpose !== 'checkout') {
    recs.push('Add privacy text near the form (e.g., "We\'ll never share your email")');
    score = Math.max(0, score - 2);
  }

  return { score: Math.min(maxScore, score), notes, recommendations: recs };
}

function scoreAboveFold(form) {
  const maxScore = 5;
  if (form.aboveFold) {
    return { score: maxScore, notes: ['Form appears above the fold'], recommendations: [] };
  }
  return {
    score: 2,
    notes: ['Form appears below the fold'],
    recommendations: ['Move form higher on the page, or add a clear CTA/anchor above the fold pointing to the form']
  };
}

function scoreAccessibility(form) {
  const notes = [];
  const recs = [];

  const unlabeled = form.fields.filter(f => !f.label);
  if (unlabeled.length > 0) {
    recs.push(`${unlabeled.length} field(s) lack proper label association (for/id matching)`);
  }

  const missingId = form.fields.filter(f => !f.id);
  if (missingId.length > 0) {
    recs.push(`${missingId.length} field(s) missing id attribute, needed for label association`);
  }

  if (recs.length === 0) notes.push('Basic accessibility checks pass');

  return { notes, recommendations: recs };
}

function generateFieldRecommendations(form, purpose) {
  return form.fields.map(field => {
    const name = (field.name + ' ' + (field.label || '')).toLowerCase();
    let action = 'keep';
    const changes = [];
    let estimatedImpact = '';
    let priority = 'low';

    // Field removal candidates
    if (purpose === 'lead-gen' || purpose === 'contact') {
      if (/phone/i.test(name) && field.required) {
        action = 'make_optional_or_remove';
        changes.push('Make optional or remove entirely');
        estimatedImpact = '+5-15% completion rate';
        priority = 'high';
      }
      if (/company|organization|business/i.test(name) && form.totalFields > 4) {
        action = 'remove';
        changes.push('Remove, collect during follow-up');
        estimatedImpact = '+3-8% completion rate';
        priority = 'medium';
      }
      if (/title|job|role|position/i.test(name)) {
        action = 'remove';
        changes.push('Remove, not needed for initial contact');
        estimatedImpact = '+3-5% completion rate';
        priority = 'medium';
      }
      if (/fax|address/i.test(name) && !/email/i.test(name)) {
        action = 'remove';
        changes.push('Remove, collect later if needed');
        estimatedImpact = '+3-5% completion rate';
        priority = 'high';
      }
    }

    // Type improvements
    if (/email/i.test(name) && field.type !== 'email') {
      changes.push('Change type to "email"');
      if (priority === 'low') priority = 'medium';
    }
    if (/phone/i.test(name) && field.type !== 'tel' && action !== 'remove') {
      changes.push('Change type to "tel"');
    }
    if (!field.autocomplete && field.element === 'input') {
      for (const [pattern, values] of Object.entries(AUTOCOMPLETE_MAP)) {
        if (new RegExp(pattern, 'i').test(name)) {
          changes.push(`Add autocomplete="${values[0]}"`);
          break;
        }
      }
    }

    // Label improvements
    if (!field.label) {
      changes.push('Add visible <label> element');
      if (priority === 'low') priority = 'medium';
    }

    return {
      field: field.label || field.name || field.type,
      position: field.position,
      currentType: field.type,
      required: field.required,
      action,
      changes,
      estimatedImpact: estimatedImpact || (changes.length > 0 ? '+1-3% completion rate' : ''),
      priority
    };
  });
}

function main() {
  const args = parseArgs();
  if (!args.input || !args.output) {
    console.error('Usage: node score-form.cjs --input=form-structure.json --purpose=lead-gen --output=scores.json');
    process.exit(1);
  }

  const data = JSON.parse(fs.readFileSync(path.resolve(args.input), 'utf-8'));
  const purpose = args.purpose || 'lead-gen';

  if (!data.forms || data.forms.length === 0) {
    console.error('No forms to score');
    process.exit(1);
  }

  const results = data.forms.map(form => {
    const dimensions = {
      fieldCount: scoreFieldCount(form, purpose),
      requiredOptional: scoreRequiredOptional(form),
      fieldTypes: scoreFieldTypes(form),
      labelClarity: scoreLabelClarity(form),
      placeholders: scorePlaceholders(form),
      mobileInput: scoreMobileInput(form),
      multiStep: scoreMultiStep(form),
      validation: scoreValidation(form),
      cta: scoreCTA(form),
      trustSignals: scoreTrustSignals(form, purpose),
      aboveFold: scoreAboveFold(form)
    };

    const accessibility = scoreAccessibility(form);

    const totalScore = Object.values(dimensions).reduce((sum, d) => sum + d.score, 0);
    const maxPossible = 100;
    const percentage = parseFloat((totalScore / maxPossible * 100).toFixed(1));

    let grade;
    if (percentage >= 85) grade = 'A';
    else if (percentage >= 70) grade = 'B';
    else if (percentage >= 55) grade = 'C';
    else if (percentage >= 40) grade = 'D';
    else grade = 'F';

    const fieldRecommendations = generateFieldRecommendations(form, purpose);

    return {
      formId: form.id,
      purpose,
      totalFields: form.totalFields,
      requiredFields: form.requiredFields,
      optionalFields: form.optionalFields,
      ctaText: form.submitButton.text,
      overallScore: totalScore,
      overallPercentage: percentage,
      grade,
      dimensions,
      accessibility,
      fieldRecommendations,
      priorityActions: fieldRecommendations
        .filter(f => f.changes.length > 0)
        .sort((a, b) => {
          const prio = { high: 3, medium: 2, low: 1 };
          return (prio[b.priority] || 0) - (prio[a.priority] || 0);
        })
        .slice(0, 5)
    };
  });

  const output = {
    url: data.url,
    analysisDate: new Date().toISOString().split('T')[0],
    purpose,
    forms: results
  };

  const outputPath = path.resolve(args.output);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));

  results.forEach(r => {
    console.log(`Form "${r.formId}": Score ${r.overallScore}/100 (${r.grade})`);
    console.log(`  ${r.totalFields} fields, CTA: "${r.ctaText}"`);
    if (r.priorityActions.length > 0) {
      console.log(`  Top action: ${r.priorityActions[0].changes[0]} (${r.priorityActions[0].estimatedImpact})`);
    }
  });
}

main();
