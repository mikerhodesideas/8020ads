#!/usr/bin/env node
/**
 * parse-form.cjs
 * Parse form HTML structure from fetched page content into a normalized schema.
 *
 * Usage:
 *   node parse-form.cjs --input=page-content.json --output=form-structure.json
 *
 * Input: JSON file with { html: "...", url: "...", ... } or raw HTML string
 * Output: Structured form analysis JSON
 */

const fs = require('fs');
const path = require('path');

function parseArgs() {
  const args = {};
  process.argv.slice(2).forEach(arg => {
    const [key, ...vals] = arg.replace(/^--/, '').split('=');
    args[key] = vals.join('=');
  });
  return args;
}

// Simple HTML tag parser (no external deps)
function extractTag(html, tag) {
  const regex = new RegExp(`<${tag}([^>]*)>`, 'gi');
  const matches = [];
  let match;
  while ((match = regex.exec(html)) !== null) {
    matches.push({ fullMatch: match[0], attrs: match[1], index: match.index });
  }
  return matches;
}

function parseAttributes(attrString) {
  const attrs = {};
  const regex = /(\w[\w-]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|(\S+)))?/g;
  let m;
  while ((m = regex.exec(attrString)) !== null) {
    attrs[m[1].toLowerCase()] = m[2] || m[3] || m[4] || true;
  }
  return attrs;
}

function extractForms(html) {
  const forms = [];
  const formRegex = /<form([^>]*)>([\s\S]*?)<\/form>/gi;
  let formMatch;

  while ((formMatch = formRegex.exec(html)) !== null) {
    const formAttrs = parseAttributes(formMatch[1]);
    const formHTML = formMatch[2];
    const formIndex = formMatch.index;

    // Extract fields
    const fields = [];
    let position = 0;

    // Input elements
    const inputs = extractTag(formHTML, 'input');
    for (const inp of inputs) {
      const a = parseAttributes(inp.attrs);
      if (a.type === 'hidden' || a.type === 'submit') continue;
      position++;
      fields.push({
        element: 'input',
        type: a.type || 'text',
        name: a.name || '',
        id: a.id || '',
        required: !!a.required,
        placeholder: a.placeholder || '',
        autocomplete: a.autocomplete || '',
        pattern: a.pattern || '',
        minlength: a.minlength || '',
        maxlength: a.maxlength || '',
        inputmode: a.inputmode || '',
        label: null, // filled below
        position
      });
    }

    // Select elements
    const selects = extractTag(formHTML, 'select');
    for (const sel of selects) {
      const a = parseAttributes(sel.attrs);
      position++;
      // Count options
      const optionCount = (formHTML.substring(sel.index).match(/<option/gi) || []).length;
      fields.push({
        element: 'select',
        type: 'select',
        name: a.name || '',
        id: a.id || '',
        required: !!a.required,
        placeholder: '',
        autocomplete: a.autocomplete || '',
        optionCount,
        label: null,
        position
      });
    }

    // Textarea elements
    const textareas = extractTag(formHTML, 'textarea');
    for (const ta of textareas) {
      const a = parseAttributes(ta.attrs);
      position++;
      fields.push({
        element: 'textarea',
        type: 'textarea',
        name: a.name || '',
        id: a.id || '',
        required: !!a.required,
        placeholder: a.placeholder || '',
        maxlength: a.maxlength || '',
        label: null,
        position
      });
    }

    // Match labels to fields
    const labelRegex = /<label([^>]*)>([\s\S]*?)<\/label>/gi;
    let labelMatch;
    while ((labelMatch = labelRegex.exec(formHTML)) !== null) {
      const labelAttrs = parseAttributes(labelMatch[1]);
      const labelText = labelMatch[2].replace(/<[^>]+>/g, '').trim();
      const forId = labelAttrs.for;

      if (forId) {
        const field = fields.find(f => f.id === forId);
        if (field) field.label = labelText;
      } else {
        // Check if label wraps an input
        const wrappedInput = labelMatch[2].match(/<input|<select|<textarea/i);
        if (wrappedInput && fields.length > 0) {
          // Find the field nearest this label's position
          const nearestField = fields.find(f => !f.label);
          if (nearestField) nearestField.label = labelText;
        }
      }
    }

    // Submit button
    let submitButton = { text: 'Submit', type: 'submit' };
    const submitInputs = extractTag(formHTML, 'input').filter(t => {
      const a = parseAttributes(t.attrs);
      return a.type === 'submit';
    });
    if (submitInputs.length > 0) {
      const a = parseAttributes(submitInputs[0].attrs);
      submitButton = { text: a.value || 'Submit', type: 'input-submit' };
    }

    const buttons = extractTag(formHTML, 'button');
    for (const btn of buttons) {
      const a = parseAttributes(btn.attrs);
      if (a.type === 'submit' || !a.type) {
        const btnTextMatch = formHTML.substring(btn.index).match(/<button[^>]*>([\s\S]*?)<\/button>/i);
        if (btnTextMatch) {
          submitButton = {
            text: btnTextMatch[1].replace(/<[^>]+>/g, '').trim() || 'Submit',
            type: 'button-submit'
          };
        }
      }
    }

    // Multi-step detection
    const multiStep = /step|wizard|progress|multi-step|multistep/i.test(formHTML) ||
      (formHTML.match(/class="[^"]*step/gi) || []).length > 1;

    // Trust signals detection
    const trustSignals = [];
    if (/privacy/i.test(html.substring(Math.max(0, formIndex - 2000), formIndex + formHTML.length + 2000))) {
      trustSignals.push('Privacy policy reference');
    }
    if (/secure|ssl|encrypt/i.test(html.substring(Math.max(0, formIndex - 1000), formIndex + formHTML.length + 1000))) {
      trustSignals.push('Security signal');
    }
    if (/testimonial|review|rating|star/i.test(html.substring(Math.max(0, formIndex - 2000), formIndex + formHTML.length + 2000))) {
      trustSignals.push('Social proof near form');
    }
    if (/never.*share|no.*spam|unsubscribe/i.test(html.substring(Math.max(0, formIndex - 500), formIndex + formHTML.length + 500))) {
      trustSignals.push('No-spam promise');
    }

    // Above-fold estimation (rough: if form appears in first 30% of HTML)
    const aboveFold = formIndex < html.length * 0.3;

    forms.push({
      id: formAttrs.id || formAttrs.name || `form-${forms.length + 1}`,
      action: formAttrs.action || '',
      method: (formAttrs.method || 'GET').toUpperCase(),
      fields,
      submitButton,
      multiStep,
      trustSignals,
      aboveFold,
      totalFields: fields.length,
      requiredFields: fields.filter(f => f.required).length,
      optionalFields: fields.filter(f => !f.required).length
    });
  }

  return forms;
}

function main() {
  const args = parseArgs();
  if (!args.input || !args.output) {
    console.error('Usage: node parse-form.cjs --input=page-content.json --output=form-structure.json');
    process.exit(1);
  }

  const inputPath = path.resolve(args.input);
  const outputPath = path.resolve(args.output);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  const content = fs.readFileSync(inputPath, 'utf-8');
  let html;

  try {
    const json = JSON.parse(content);
    html = json.html || json.content || json.text || content;
  } catch {
    html = content; // Treat as raw HTML
  }

  const forms = extractForms(html);

  if (forms.length === 0) {
    console.error('No <form> elements found in the HTML');
    // Still output empty result for the next script
    fs.writeFileSync(outputPath, JSON.stringify({ forms: [], url: args.url || '' }, null, 2));
    process.exit(0);
  }

  const output = { forms, url: args.url || '' };
  fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));

  console.log(`Found ${forms.length} form(s):`);
  forms.forEach(f => {
    console.log(`  ${f.id}: ${f.totalFields} fields (${f.requiredFields} required, ${f.optionalFields} optional), CTA: "${f.submitButton.text}"`);
  });
}

main();
