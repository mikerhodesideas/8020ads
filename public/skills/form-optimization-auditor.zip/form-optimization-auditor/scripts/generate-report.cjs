#!/usr/bin/env node
/**
 * generate-report.cjs
 * Generate HTML report for form optimization audit.
 *
 * Usage:
 *   node generate-report.cjs --input=scores.json --name="Client Name" --output=report.html
 */

const fs = require('fs');
const path = require('path');

function parseArgs() {
  const args = {};
  process.argv.slice(2).forEach(arg => {
    const [key, ...vals] = arg.replace(/^--/, '').split('=');
    args[key] = vals.join('=');
  });
  return args;
}

function gradeColor(grade) {
  const map = { A: '#28a745', B: '#17a2b8', C: '#ffc107', D: '#fd7e14', F: '#dc3545' };
  return map[grade] || '#6c757d';
}

function priorityBadge(priority) {
  const map = { high: '#dc3545', medium: '#ffc107', low: '#6c757d' };
  return `<span style="display:inline-block;padding:2px 8px;background:${map[priority] || '#6c757d'};color:#fff;font-size:11px;font-weight:600;border-radius:2px">${priority.toUpperCase()}</span>`;
}

function actionBadge(action) {
  const map = {
    keep: { bg: '#28a745', text: 'KEEP' },
    remove: { bg: '#dc3545', text: 'REMOVE' },
    make_optional_or_remove: { bg: '#fd7e14', text: 'REMOVE/OPTIONAL' },
    modify: { bg: '#17a2b8', text: 'MODIFY' }
  };
  const d = map[action] || { bg: '#6c757d', text: action };
  return `<span style="display:inline-block;padding:2px 8px;background:${d.bg};color:#fff;font-size:11px;font-weight:600;border-radius:2px">${d.text}</span>`;
}

function dimensionBar(name, score, maxScore) {
  const pct = (score / maxScore * 100).toFixed(0);
  const color = pct >= 80 ? '#28a745' : pct >= 60 ? '#ffc107' : '#dc3545';
  return `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
      <span style="min-width:180px;font-size:13px">${name}</span>
      <div style="flex:1;background:#e9ecef;height:20px;border-radius:2px;overflow:hidden">
        <div style="background:${color};height:100%;width:${pct}%;min-width:2px;border-radius:2px"></div>
      </div>
      <span style="min-width:50px;text-align:right;font-size:13px;font-weight:600">${score}/${maxScore}</span>
    </div>`;
}

function generateHTML(data, clientName) {
  const form = data.forms[0]; // Primary form
  if (!form) return '<html><body><p>No forms found to analyze.</p></body></html>';

  const dimMaxScores = {
    fieldCount: 15, requiredOptional: 10, fieldTypes: 10, labelClarity: 10,
    placeholders: 5, mobileInput: 10, multiStep: 5, validation: 10,
    cta: 10, trustSignals: 10, aboveFold: 5
  };

  const dimNames = {
    fieldCount: 'Field Count', requiredOptional: 'Required/Optional', fieldTypes: 'Field Types',
    labelClarity: 'Label Clarity', placeholders: 'Placeholder Usage', mobileInput: 'Mobile Input',
    multiStep: 'Multi-Step Structure', validation: 'Validation UX', cta: 'CTA Quality',
    trustSignals: 'Trust Signals', aboveFold: 'Above-Fold Placement'
  };

  const dimensionBars = Object.entries(form.dimensions).map(([key, dim]) =>
    dimensionBar(dimNames[key] || key, dim.score, dimMaxScores[key] || 10)
  ).join('');

  // All recommendations from dimensions
  const allRecs = Object.entries(form.dimensions).flatMap(([key, dim]) =>
    dim.recommendations.map(r => ({ category: dimNames[key], recommendation: r }))
  );

  const recList = allRecs.map(r =>
    `<li style="margin-bottom:8px"><strong>${r.category}:</strong> ${r.recommendation}</li>`
  ).join('');

  // Field-by-field table
  const fieldRows = form.fieldRecommendations.map(f => `
    <tr>
      <td style="padding:8px;border-bottom:1px solid #e9ecef">${f.position}</td>
      <td style="padding:8px;border-bottom:1px solid #e9ecef;font-weight:600">${f.field}</td>
      <td style="padding:8px;border-bottom:1px solid #e9ecef">${f.currentType}</td>
      <td style="padding:8px;border-bottom:1px solid #e9ecef">${f.required ? 'Required' : 'Optional'}</td>
      <td style="padding:8px;border-bottom:1px solid #e9ecef">${actionBadge(f.action)}</td>
      <td style="padding:8px;border-bottom:1px solid #e9ecef;font-size:13px">${f.changes.join('; ') || 'No changes needed'}</td>
      <td style="padding:8px;border-bottom:1px solid #e9ecef;font-size:13px;color:#28a745">${f.estimatedImpact}</td>
    </tr>`).join('');

  // Priority actions
  const priorityActions = form.priorityActions.map((a, i) => `
    <div style="display:flex;gap:12px;padding:12px;background:${i % 2 === 0 ? '#f8f9fa' : '#fff'};border-left:4px solid ${i === 0 ? '#dc3545' : i < 3 ? '#ffc107' : '#6c757d'}">
      <div style="font-size:20px;font-weight:700;color:#666;min-width:30px">${i + 1}</div>
      <div>
        <div style="font-weight:600">${a.field}: ${a.changes[0]}</div>
        <div style="font-size:13px;color:#666;margin-top:2px">
          ${priorityBadge(a.priority)} <span style="color:#28a745;font-weight:600;margin-left:8px">${a.estimatedImpact}</span>
        </div>
      </div>
    </div>`).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Form Optimization Audit - ${clientName}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #333; max-width: 960px; margin: 0 auto; padding: 24px; background: #fff; }
    h1 { font-size: 24px; margin-bottom: 4px; }
    h2 { font-size: 18px; margin-bottom: 12px; }
    p { line-height: 1.5; margin-bottom: 8px; }
    ul { padding-left: 20px; margin-bottom: 12px; }
    li { line-height: 1.4; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    @media print { body { max-width: none; padding: 12px; } }
  </style>
</head>
<body>
  <h1>Form Optimization Audit</h1>
  <p style="color:#666;margin-bottom:24px">${clientName} | ${data.analysisDate} | Purpose: ${data.purpose}${data.url ? ' | ' + data.url : ''}</p>

  <div style="display:grid;grid-template-columns:auto 1fr;gap:24px;margin-bottom:32px;align-items:start">
    <div style="text-align:center;padding:24px 32px;border:3px solid ${gradeColor(form.grade)};border-radius:2px">
      <div style="font-size:56px;font-weight:700;color:${gradeColor(form.grade)}">${form.grade}</div>
      <div style="font-size:24px;font-weight:600">${form.overallScore}/100</div>
      <div style="font-size:13px;color:#666;margin-top:4px">${form.totalFields} fields | ${form.requiredFields} required</div>
    </div>
    <div>
      <h2 style="border-bottom:2px solid #333;padding-bottom:6px;margin-bottom:12px">Score Breakdown</h2>
      ${dimensionBars}
    </div>
  </div>

  <h2 style="border-bottom:2px solid #333;padding-bottom:6px">Priority Actions</h2>
  <p style="color:#666;font-size:13px;margin-bottom:12px">Top changes ranked by estimated conversion impact</p>
  <div style="margin-bottom:24px">${priorityActions}</div>

  <h2 style="margin-top:32px;border-bottom:2px solid #333;padding-bottom:6px">Field-by-Field Analysis</h2>
  <table style="margin-bottom:24px">
    <thead><tr style="background:#f8f9fa">
      <th style="padding:8px;text-align:left">#</th>
      <th style="padding:8px;text-align:left">Field</th>
      <th style="padding:8px;text-align:left">Type</th>
      <th style="padding:8px;text-align:left">Required</th>
      <th style="padding:8px;text-align:left">Action</th>
      <th style="padding:8px;text-align:left">Changes</th>
      <th style="padding:8px;text-align:left">Impact</th>
    </tr></thead>
    <tbody>${fieldRows}</tbody>
  </table>

  <h2 style="margin-top:32px;border-bottom:2px solid #333;padding-bottom:6px">All Recommendations</h2>
  <ul style="margin-bottom:24px">${recList}</ul>

  ${form.accessibility.recommendations.length > 0 ? `
  <h2 style="margin-top:32px;border-bottom:2px solid #333;padding-bottom:6px">Accessibility Notes</h2>
  <ul>${form.accessibility.recommendations.map(r => `<li style="margin-bottom:6px">${r}</li>`).join('')}</ul>` : ''}

  <div style="margin-top:32px;padding-top:16px;border-top:1px solid #e9ecef;font-size:12px;color:#999">
    Generated by Form Optimization Auditor | ${data.analysisDate} | Impact estimates are directional ranges based on industry research
  </div>
</body>
</html>`;
}

function main() {
  const args = parseArgs();
  if (!args.input || !args.output) {
    console.error('Usage: node generate-report.cjs --input=scores.json --name="Client Name" --output=report.html');
    process.exit(1);
  }

  const data = JSON.parse(fs.readFileSync(path.resolve(args.input), 'utf-8'));
  const clientName = args.name || 'Client';
  const html = generateHTML(data, clientName);

  const outputPath = path.resolve(args.output);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, html);
  console.log(`Report generated: ${outputPath}`);
}

main();
