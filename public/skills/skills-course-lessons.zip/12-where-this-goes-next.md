# 12 - Where This Goes Next

You've built skills, connected them to real tools, tested them, and made them your own. This final lesson covers the advanced techniques you'll eventually want, and where to find the community of people already doing this at a much deeper level.

---

## Multi-Skill Workflows

So far, each of your skills runs independently. But skills can chain together naturally in a conversation.

Example: you run your client research brief skill. It produces a structured brief. Then you say "now write a proposal based on that brief" and your proposal skill picks up automatically, using the research output as its input.

You don't need to wire these together explicitly. If both skills are active and their descriptions are clear, Cowork will chain them naturally based on the context of the conversation.

For more complex workflows, you can create a "command" file that orchestrates multiple skills in sequence:

```markdown
## Morning Routine

1. Run the daily-briefing skill (pulls Calendar + Gmail)
2. Run the inbox-triage skill (categorizes unread emails)
3. Run the task-planner skill (creates today's priority list from the briefing)
4. Save everything to output/morning-YYYY-MM-DD.md
```

One prompt triggers the full sequence.

---

## Scheduled Tasks

Any skill can run on a schedule without you lifting a finger.

In Cowork, use the schedule feature to set a skill to run hourly, daily, or weekly. The daily briefing skill is the obvious candidate: schedule it for 7am every morning, and your briefing is waiting when you open Cowork.

Two important caveats:
- Your computer needs to be on and Cowork needs to be open for scheduled tasks to run
- Start with read-only or draft-only tasks. Don't schedule a skill that sends emails without your review.

The pattern that works best: schedule skills that gather and organize information (briefings, inbox triage, report summaries). Keep anything that takes action (sending, posting, deleting) as manual tasks where you review the output first.

---

## Progressive Disclosure

As your skills get more sophisticated, the SKILL.md file can get long. The 200-line guideline exists because Cowork performs better with concise instruction files.

The solution is **progressive disclosure**: keep your SKILL.md lean and store the detail in separate reference files.

```
my-skill/
  SKILL.md              (under 200 lines - the table of contents)
  references/
    audit-checklist.md   (loaded only when the audit step runs)
    scoring-rubric.md    (loaded only when the scoring step runs)
    report-template.md   (loaded only when writing the report)
```

The SKILL.md points to each reference file at the right step:

```markdown
3. Read references/audit-checklist.md and evaluate the website against each criterion.
4. Read references/scoring-rubric.md and score each criterion.
```

Cowork loads each file only when it reaches that step, keeping its context window clean and its performance sharp.

---

## Plugins: Packaging Skills for Others

A plugin is a bundle of related skills, context files, and connector configurations packaged as a single installable unit. If you've built a set of skills that work together (say, a client onboarding workflow with research, proposal, and follow-up skills), you can package them as a plugin and share them.

This is where skill-building stops being just personal productivity and starts becoming something you can offer to clients, team members, or a broader audience.

---

## The Ceiling You'll Hit (and What's Beyond It)

Everything in this course works inside Cowork's desktop app. For most people, that's more than enough. But if you keep going, you'll eventually hit some limits:

- **No memory between sessions.** Every time you start Cowork, it forgets everything from last time. Your context files help, but they're static. There's no learning loop.
- **No version control.** When you edit a skill, the old version is gone. There's no history, no rollback, no way to track what changed.
- **No automation beyond the desktop.** Scheduled tasks only run when your computer is on and Cowork is open. There's no server, no cloud, no overnight processing.
- **Limited integrations.** Connectors cover the big tools, but if you need something specific (your CRM, your ad platform, your custom database), you'll need more than connectors can offer.

These aren't dealbreakers. They're the edges of what a desktop app can do. For many people, skills + connectors + scheduling is plenty.

But if you find yourself wanting more, there's a path forward.

---

## The AI Scout Path

There's a community of people who have already pushed past these limits. They call themselves AI Scouts, and they're part of Ads to AI.

Scouts are business owners, marketers, and operators who use AI to run real parts of their business. Not just chat. Not just skills. Full systems that handle research, reporting, client communication, content creation, and automation.

What makes the Scout community different:

- **A shared skill library.** Members build skills and share them. Instead of starting from scratch, you start from something that already works and adapt it.
- **The brain system.** A personal AI infrastructure that goes beyond Cowork. It connects your email, calendar, files, and tools into a single system with memory, version control, and overnight automation. Everything you learned in this course is the foundation; the brain builds on top of it.
- **Monthly Q&A calls.** Live sessions with practitioners working on the same problems. Not theory. Real workflows, real tools, real results.
- **Courses and learning paths.** Structured programs covering automated reporting, AI analysis, and building autonomous systems. Pick up where this course leaves off.
- **A 1:1 strategy call** to help you figure out where to start based on your specific situation.

If you've finished this course and you're thinking "I want to go deeper," that's exactly what the Scout path is for. The link is on the page where you found this course.

---

## What You've Built Across This Course

Look at where you started and where you are now:

- **Lesson 1:** You understood what a skill is
- **Lesson 2:** You built your first one
- **Lesson 3:** You learned to read and edit the file yourself
- **Lesson 4:** You set up a workspace with context files
- **Lesson 5:** You learned the fastest way to create skills (do it first, then package)
- **Lesson 6:** You made skills trigger reliably
- **Lesson 7:** You added your business context so output sounds like you
- **Lesson 8:** You built interactive skills that gather information
- **Lesson 9:** You connected skills to real tools
- **Lesson 10:** You tested and measured skill quality
- **Lesson 11:** You learned to edit and improve any skill
- **Lesson 12:** You've seen where this goes next

You're no longer someone who types prompts into a chat box. You're someone who builds systems that work consistently, every time. That's a fundamentally different relationship with AI.

The question now is: how far do you want to take it?
