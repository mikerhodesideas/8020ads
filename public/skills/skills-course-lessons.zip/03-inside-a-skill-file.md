# 3 - Inside a SKILL.md File

You've built a skill using the Skill Creator. Now let's open the file it generated and understand each part, so you can edit skills yourself.

---

## Why This Matters

The Skill Creator is great for getting started, but you'll eventually want to tweak a skill by hand. Maybe you want to change the output format, add a step, or adjust how a skill handles edge cases. Understanding the file means you're not dependent on the Skill Creator for every change.

---

## The Two Parts of Every Skill File

Every SKILL.md has two sections: the **frontmatter** at the top and the **body** below it.

### Part 1: The Frontmatter

The frontmatter sits between two lines of three dashes (`---`). It contains metadata about the skill:

```yaml
---
name: meeting-summary
description: Processes raw meeting notes into a structured summary with decisions, action items, and open questions.
---
```

Two fields matter here:

**name** (max 64 characters): The skill's label. Must be lowercase with hyphens, no spaces. This is how the skill appears in your library.

**description** (max 200 characters): This is the most important line in the file. Cowork reads this description to decide whether your skill is relevant to what you're asking. If the description is vague, Cowork won't know when to use it. We'll go deep on this in Lesson 6.

There's also an optional `dependencies` field if your skill needs Python or Node.js packages, but most skills won't need it.

### Part 2: The Body

Everything below the frontmatter is the instruction set. This is where you tell Cowork what to do. A good skill body has five sections:

**Goal** - One or two sentences. What does this skill produce, and why does it exist?

```markdown
## Goal

After a meeting, produce a structured summary that captures what was decided,
what needs to happen next, and what's still unresolved. The summary should be
ready to share with attendees without editing.
```

**Steps** - A numbered list of actions. Each step should be a concrete thing to do, not a vague instruction.

```markdown
## Steps

1. Read the meeting notes provided by the user.
2. Identify all decisions (look for "we agreed", "we'll go with", "decided to").
3. Extract action items with the responsible person and any deadline mentioned.
4. List any questions that were raised but not resolved.
5. Write a one-paragraph context summary (who met, when, what the meeting was about).
6. Assemble the final output in the format specified below.
```

**Output Format** - Exactly what the result should look like.

```markdown
## Output Format

Save as a markdown file named `meeting-summary-YYYY-MM-DD.md` with these sections:

### Context
One paragraph: attendees, date, topic.

### Key Decisions
Bullet points. One decision per bullet.

### Action Items
Bullet points. Format: "- [Person]: Task (by [date] if mentioned)"

### Open Questions
Bullet points. Questions raised but not answered.
```

**Tools** (optional) - If the skill uses connectors like Gmail or Calendar, note them here.

**Edge Cases** (optional) - What should the skill do if something unexpected happens?

```markdown
## Edge Cases

- If no decisions were made, write "No decisions recorded" under Key Decisions.
- If notes are very brief (under 50 words), ask the user if they have more context before proceeding.
```

---

## Hands-On: Edit Your Meeting Summary Skill

Open the skill you built in Lesson 2. Find it in Cowork's Customize panel.

Make these three changes:

1. **Add a step:** After the action items step, add: "7. If any action item has a deadline within 48 hours, mark it with [URGENT] at the start."

2. **Change the output format:** Add a "Next Meeting" section at the bottom where the skill notes any suggested follow-up date.

3. **Tighten the goal:** Make sure it mentions that the summary should be concise enough to read in under 2 minutes.

Save your changes and test the skill again with the same meeting notes. Compare the output to what you got before.

---

## What You Built

You now understand the anatomy of a skill file and can edit one yourself. You've made manual changes to your meeting summary skill and confirmed they work.

---

## Common Mistakes

**Writing vague steps.** "Summarize the meeting" is not a step. "Extract all decisions mentioned in the notes, looking for phrases like 'we agreed' or 'let's go with'" is a step. The more specific your steps, the more consistent the output.

**Forgetting the output format.** Without a defined output format, Cowork will improvise. Sometimes that's fine. Usually it's not. Spell out exactly what the result should look like.

**Making the body too long.** Keep your SKILL.md under 200 lines. If you need more detail, you can add reference files in a `references/` folder (covered in Lesson 12). For now, keep it tight.
