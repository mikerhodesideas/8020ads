# 2 - Your First Skill in 5 Minutes

Time to build something. In this lesson you'll use Cowork's built-in Skill Creator to produce a working skill without writing a single line yourself.

---

## Why This Matters

You could write a skill file by hand (and you'll learn how in Lesson 3), but there's a faster way to start. Cowork has a built-in Skill Creator that interviews you about what you want, then generates the skill file for you.

It's the fastest path from "I have no skills" to "I have a working skill."

---

## The Concept

The Skill Creator is itself a skill that comes pre-installed in Cowork. When you activate it and describe what you want to build, it asks a series of questions to narrow down exactly what the skill should do, who it's for, and what the output should look like.

This questioning process matters. A vague request like "help me with emails" could mean a hundred different things. The Skill Creator's questions force you to get specific: What kind of emails? What tone? What information do you need before writing? What does a good result look like?

Once it has enough information, it generates the SKILL.md file and lets you review it before adding it to your library.

---

## Hands-On: Build a Meeting Summary Skill

Let's build a skill that takes messy meeting notes and turns them into a clean summary with action items. This is something most people do manually after every call.

**Step 1: Open the Skill Creator**

In Cowork, click the Customize icon (paintbrush) in the sidebar. Look for the Skill Creator in your skills list. If it's not active, toggle it on.

**Step 2: Tell it what you want**

Type this into Cowork:

```
I want to create a skill that processes meeting notes. I'll paste in raw
notes from a call, and the skill should produce a clean summary with three
sections: Key Decisions, Action Items (with who's responsible), and Open
Questions that still need answers.
```

**Step 3: Answer the questions**

The Skill Creator will ask you several questions. Here's roughly what to expect and how to answer:

- **What domain is this for?** Business meetings, client calls, internal team syncs
- **What's the output format?** A markdown file saved to the current folder
- **How detailed should the summary be?** Concise. One paragraph for context, then bullet points for each section
- **Should it include anything else?** Add a "Follow-up Date" field if any deadlines were mentioned

Answer honestly based on your actual needs. Skip any question that doesn't apply.

**Step 4: Review the skill**

The Skill Creator will show you the generated SKILL.md file. Read through it. Does it capture what you described? If something's off, tell Cowork what to change before finalizing.

**Step 5: Add it to your library**

Once you're happy with it, confirm and the skill gets added to your library. You can now use it by pasting meeting notes into Cowork and the skill will activate automatically based on the context.

**Step 6: Test it**

Paste in some real meeting notes (or make some up) and see what comes out. The output should follow the structure you defined: Key Decisions, Action Items, Open Questions.

---

## What You Built

You now have a working skill that processes meeting notes into a structured summary. It's in your Cowork library and will activate whenever you paste meeting notes.

---

## Common Mistakes

**Answering every question with "I don't know."** The Skill Creator needs specifics to build something useful. If you're genuinely unsure, think about the last time you did this task manually. What did you produce? What format was it in? Use that as your answer.

**Not testing immediately.** Always test a new skill right after creating it. The first version often needs a small tweak, and it's easier to fix while the context is fresh.

**Expecting perfection on the first try.** Your first skill won't be perfect. That's normal. You'll learn to edit and improve skills in later lessons. For now, "working" is the goal, not "flawless."
