# 11 - Editing and Improving Skills

You don't need to build every skill from scratch. Some of the best skills start as someone else's work that you adapt. This lesson covers how to take any skill, understand it, and make it yours.

---

## Why This Matters

The 10-skill pack you received is a starting point, not a final product. Those skills were built for a general audience. They don't know your business, your tone, or your specific workflow. Editing them to fit your needs is often faster and more effective than building from scratch.

The same applies to any skill you find online, get from a community, or build yourself three months ago when your needs were different.

---

## The Editing Workflow

### 1. Read the skill file first

Before changing anything, read the entire SKILL.md. Understand:
- What's the goal?
- What steps does it take?
- What output format does it produce?
- Does it reference any context files or connectors?

### 2. Run it once with real input

See what it produces before you change anything. This gives you a baseline. Sometimes a skill is better (or worse) than you expected from reading the file.

### 3. Identify what to change

Common edits:
- **Output format doesn't match what you need** - Change the output format section
- **Missing a step** - Add the step in the right place in the sequence
- **Too generic** - Add context file references (Lesson 7)
- **Description doesn't trigger properly** - Rewrite using the framework from Lesson 6
- **Too long/verbose** - Trim steps or tighten the goal

### 4. Make targeted changes

Don't rewrite the whole skill. Change the specific parts that need changing. If the steps are good but the output format is wrong, only change the output format.

### 5. Test the edited version

Run it again with the same input you used in step 2. Compare. Is it better? If yes, keep the changes. If not, try a different edit.

---

## Refactoring a Bloated Skill

If you encounter a skill with a SKILL.md over 200 lines, it needs trimming. Long skills cause performance problems: Cowork loads the whole thing into its context and has less room for actual work.

The fix: **extract detail into reference files.**

Before (300+ lines in SKILL.md):
```markdown
## Steps

1. Analyze the website using these 47 criteria:
   - Title tag present and under 60 characters
   - Meta description present and under 160 characters
   - H1 tag present on every page
   [... 44 more criteria ...]

2. Score each criterion on a 1-5 scale using this rubric:
   - 1: Not present
   - 2: Present but incorrect
   [... detailed rubric ...]
```

After (under 200 lines in SKILL.md):
```markdown
## Steps

1. Read references/audit-checklist.md for the full criteria list.
2. Read references/scoring-rubric.md for how to score each criterion.
3. Analyze the website against the checklist.
4. Score each criterion using the rubric.
5. Write the report using the format in references/report-template.md.
```

The detail moved to reference files that Cowork loads only when it reaches that step. The SKILL.md stays lean.

---

## Adapting Skills From Your Skill Pack

Here's how to approach editing one of the skills from your pack:

1. **Install the skill** in Cowork
2. **Run it once** with real data. Note what you like and what doesn't fit.
3. **Open the SKILL.md** and check:
   - Does the description match how you'd describe the task?
   - Do the steps match your actual workflow?
   - Does the output format work for you?
4. **Add your context:** Reference your brand-voice.md or other context files
5. **Adjust the output:** Change formatting, sections, or file naming to match your preferences
6. **Test the edited version**

---

## Hands-On

1. Pick one skill from your pack that's close to what you need but not quite right
2. Run it once with real input (baseline)
3. Make 2-3 targeted edits (add context, change output format, add a step)
4. Run it again with the same input
5. Compare the two outputs

If you have a skill over 200 lines, practice extracting the longest section into a `references/` file.

---

## What You Built

The ability to take any skill and make it work for you. This is arguably more valuable than building skills from scratch, because you're starting from something that already works and making it fit your specific needs.

---

## Common Mistakes

**Changing everything at once.** If you rewrite the entire skill and the output is worse, you won't know which change caused the problem. Edit one thing at a time and test between changes.

**Not keeping a backup.** Before editing a skill, save a copy of the original. If your edits make things worse, you can revert.

**Ignoring the description when editing steps.** If you add significant new functionality to a skill's steps, the description might need updating too. Otherwise Cowork won't know when to trigger the expanded skill.
