# 5 - The "Do It First" Method

This is the most important lesson in the course. The fastest way to create a great skill isn't to sit down and write one from scratch. It's to do the actual work in Cowork first, then tell Cowork to turn what it just did into a reusable skill.

---

## Why This Matters

When you try to write a skill from scratch, you're guessing at what the workflow should be. You think you know the steps, but you inevitably miss things. You forget the edge case where the data is messy, or the step where you need to reformat the output, or the part where you check something before moving on.

But when you do the work first, Cowork captures the real workflow, not the imagined one. It sees every step you took, every correction you made, every decision point. Then when you say "turn this into a skill," it has the full picture.

---

## The Pattern

It's three steps:

1. **Do the work.** Open Cowork with your workspace folder selected. Complete the task you want to automate, start to finish. Don't overthink it. Just do it as you normally would.

2. **Ask for the skill.** Once the work is done and you're happy with the result, type: "Turn what you just did into a reusable skill. Create a SKILL.md file that I can use for this same task next time."

3. **Review and refine.** Cowork will generate a skill file based on the conversation. Read through it. Does it capture the full workflow? Did it miss anything? Tell Cowork to adjust before finalizing.

That's it. The work you already needed to do becomes the blueprint for the skill.

---

## Worked Example: Client Onboarding Brief

Let's say you've just had a call with a new client and you need to organize your notes.

**Step 1: Do the work**

Paste your notes into Cowork:

```
Here are my notes from a call with a potential new client:

- Company: Meridian Pool Supplies
- Contact: James Wu, Marketing Manager
- Monthly ad spend: $35k across Google and Meta
- Main issue: Search campaigns converting but Shopping is eating budget
  with no clear ROAS data
- They use Shopify, about 2,000 products
- Current agency dropped the ball on negative keywords
- James makes day-to-day decisions, but CEO (his boss Dave) approves budget changes
- Want to see a proposal by next Wednesday
- Mentioned competitor "AquaMax" is outranking them on key terms

Please organize this into a structured client brief.
```

Cowork produces a clean brief with sections, formatting, and structure.

**Step 2: Convert to a skill**

Now type:

```
That was exactly what I needed. Turn this process into a reusable skill
so I can run it for every new client call. The skill should:
- Accept raw meeting notes as input
- Produce the same structured brief format
- Ask me for the client name and call date if I don't include them
- Save the output as a markdown file
```

**Step 3: Review**

Cowork generates a SKILL.md file. Check that it captured the sections you care about, the format you liked, and the file naming convention. Tweak anything that's off.

---

## When to Use This Method vs the Skill Creator

Use the **"Do It First" method** when:
- You've already done this task before and know what good output looks like
- The workflow involves judgment calls that are hard to describe in advance
- You want the skill to match your actual process, not a generic template

Use the **Skill Creator** (Lesson 2) when:
- You're starting from scratch and need help scoping the skill
- The task is well-defined and you can describe it clearly upfront
- You want the Socratic questioning to help you think through the requirements

Both approaches produce a SKILL.md file. The "Do It First" method just gives Cowork more context to work with.

---

## Hands-On

Pick a task you've done at least twice in the last month. Something that takes 10-30 minutes. Examples:

- Turning raw notes into a formatted document
- Writing a weekly update email
- Summarizing a report for a colleague
- Processing a data export into something readable

Do the task in Cowork right now. Then convert it to a skill using the pattern above.

---

## What You Built

A skill based on your actual workflow, not a guess at what your workflow might be. This is likely more accurate and useful than anything you could have written from scratch.

---

## Common Mistakes

**Rushing the "do the work" step.** If you cut corners during the initial task, the skill will inherit those shortcuts. Do the task properly. The skill reflects whatever you showed it.

**Not reviewing the generated skill.** Cowork's skill file is a first draft. It captures the gist, but you should always read through it and adjust. Maybe it missed a step. Maybe it added something you don't need.

**Only doing this once.** This method works for every skill you build. Whenever you catch yourself doing the same task a second or third time, that's your signal: do it in Cowork and convert it.
