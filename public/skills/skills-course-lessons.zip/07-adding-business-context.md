# 7 - Adding Your Business Context

A skill without your business context is basically not worth having. This lesson is about the difference between generic output and output that sounds like you and fits your business.

---

## Why This Matters

Every skill you've built so far works. But the output is probably a bit... generic. It uses safe, professional language. It doesn't mention your specific audience. It doesn't know your pricing, your competitors, or the phrases you always use.

That's because the skill knows how to do the task but doesn't know anything about your business. Context is the fix.

---

## The Context Layer

In Lesson 4, you created three context files: about-me.md, brand-voice.md, and working-preferences.md. Those files are your foundation. Now you'll connect them to your skills.

The principle is simple: at the right step in a skill, tell Cowork to read a context file before proceeding.

---

## How to Reference Context Files in a Skill

In your SKILL.md body, add a step that reads the relevant file:

```markdown
## Steps

1. Read context/brand-voice.md to understand the user's tone and style preferences.
2. Read the meeting notes provided by the user.
3. Extract decisions, action items, and open questions.
4. Write the summary using the tone and style from brand-voice.md.
5. Save the output to the output/ folder.
```

Step 1 loads the context. Step 4 applies it. This means the skill produces output that matches your voice every time, without you having to explain your preferences in every conversation.

---

## What Context to Add (and Where)

Not every skill needs every context file. Match the context to the task:

**Writing skills** (emails, posts, summaries): brand-voice.md is essential. Audience/ICP files are useful if you're writing for a specific group.

**Analysis skills** (data processing, audits): working-preferences.md matters most. How detailed should the analysis be? What format?

**Client-facing skills** (proposals, briefs, reports): about-me.md (who you are, what you offer) plus any client-specific context.

---

## Creating Additional Context Files

The three files from Lesson 4 cover the basics. As your skills get more specific, you might want more targeted context files:

**audience.md** - Who you serve. Their problems, their language, what they care about.

```markdown
# Audience

I work with e-commerce business owners doing $500K-$5M in annual revenue.
They're usually running Google Ads themselves or have a small team managing it.

Their main frustrations:
- Wasted ad spend on irrelevant search terms
- No clear picture of which campaigns actually drive profit
- Feeling overwhelmed by Google Ads complexity

They want: more sales, less wasted spend, and someone to tell them
what to focus on. They don't care about technical jargon. They want results.
```

**services.md** - What you offer, your pricing model, your differentiators.

**competitor-notes.md** - What your competitors do, how you're different.

The key: each file should be short (under 500 words), specific, and written in plain language. These aren't formal documents. They're notes that help Cowork understand your world.

---

## Before and After

Here's the same skill output without context and with context:

**Without context:**

> Subject: Follow-Up from Our Meeting
>
> Dear James,
>
> Thank you for taking the time to meet with us today. We enjoyed learning
> about your business and discussing your advertising needs. We believe our
> services would be a strong fit for your organization.

**With brand-voice.md loaded:**

> Subject: Next steps from our call
>
> Hey James,
>
> Good call today. I've pulled together the brief below based on what you
> told me about Meridian's Shopping campaigns and the negative keyword
> situation. Three things stood out as quick wins...

Same skill. Same task. Completely different output. The second one sounds like a real person because it has context about how that person writes.

---

## Hands-On

1. Pick your best skill (the one you use most)
2. Open its SKILL.md and add a step that reads brand-voice.md
3. Run the skill with and without that step, using the same input
4. Compare the two outputs side by side

If the difference is noticeable, add context references to your other skills too.

Then create one new context file that's specific to your business (audience.md, services.md, or something else relevant). Reference it in at least one skill.

---

## What You Built

Skills that produce output matching your voice and business context. Plus at least one new context file tailored to your specific needs.

---

## Common Mistakes

**Loading every context file in every skill.** If your meeting summary skill reads your audience.md and services.md and competitor-notes.md, that's a lot of context that probably isn't relevant. Match the context to the task. More isn't always better.

**Writing context files that are too long.** A 2,000-word brand voice guide is hard for Cowork to apply consistently. Keep each file under 500 words. Be specific and concrete.

**Forgetting to update context files.** Your business changes. Your tone evolves. Your priorities shift. If your about-me.md still says "my priority is launching in Q1" and it's now Q3, that's stale context producing stale output. Review these files every month or two.
