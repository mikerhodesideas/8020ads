# 6 - Descriptions That Trigger

You've built a few skills now. But here's the question: does Cowork actually use them when it should? The answer depends almost entirely on the description in your SKILL.md frontmatter.

---

## Why This Matters

In Cowork, you don't type a slash command to activate a skill (the way you might in other tools). Instead, Cowork reads your message, scans the descriptions of all your active skills, and decides which one fits.

If your description is vague, Cowork might not realize your skill is relevant. If it's too broad, it might fire when you don't want it to. The description is the trigger mechanism, and getting it right is the difference between a skill that works reliably and one that sits unused.

---

## How Cowork Decides

When you send a message, Cowork does something like this:

1. Reads your message
2. Scans the descriptions of all active skills
3. Matches your message against those descriptions
4. If a skill is a strong match, it loads the full SKILL.md and follows the instructions

This means the description needs to contain the words and concepts that someone would naturally use when they need this skill. Not technical jargon about what the skill does internally, but the actual phrases a person would type.

---

## The Three-Part Description Framework

A good description has three elements packed into 200 characters or fewer:

### 1. What it does (the action)

Start with the core action: "Processes meeting notes," "Writes LinkedIn posts," "Analyzes CSV files."

### 2. Trigger keywords (when to fire)

Include the words someone would actually type: "meeting notes," "call summary," "action items." These are the match points Cowork uses.

### 3. What it produces (the output)

End with the result: "into a structured brief," "with scoring and feedback," "as an HTML report."

**Example - Bad:**

```yaml
description: A tool for processing information and creating organized documents.
```

This could match almost anything. It tells Cowork nothing specific about when to activate.

**Example - Good:**

```yaml
description: Processes raw meeting notes or call transcripts into a structured summary with decisions, action items, and open questions.
```

This fires when someone pastes meeting notes. It won't fire when someone asks about email or data analysis.

---

## Testing Your Triggers

The best way to check if a description works is to test it. With your skill active, try sending messages with different phrasings:

- The obvious phrasing: "Here are my meeting notes from today's call"
- A less obvious phrasing: "Can you organize these notes from a conversation I had?"
- An unrelated message: "Write me a LinkedIn post about AI tools"

The skill should activate for the first two and stay quiet for the third. If it doesn't, adjust the description.

---

## Negative Triggers

Sometimes you need to prevent a skill from firing. If you have both a "meeting summary" skill and an "email drafter" skill, and someone says "summarize this email thread," which one fires?

You can add negative context to the description:

```yaml
description: Processes raw meeting notes or call transcripts into a structured summary. Not for email threads or chat logs.
```

The "Not for" line helps Cowork distinguish between similar skills.

---

## The 15,000 Character Ceiling

Here's something most people don't realize: Cowork loads the frontmatter (name + description) of every active skill into its context at the start of a session. All your active skills' descriptions, combined, share a budget of roughly 15,000 characters.

If you have 20 active skills with 200-character descriptions, that's 4,000 characters. Fine. But if you write 500-character descriptions (breaking the 200-character guideline), you'll eat into your budget fast and Cowork's ability to match skills degrades.

Keep descriptions tight. Under 200 characters. Say more in the body, not the description.

---

## Hands-On

1. Open the skills you've built so far (Lessons 2, 3, 5)
2. Read each description. Does it contain the words someone would naturally type?
3. Rewrite any description that's vague or too broad using the three-part framework
4. Test each skill by sending 3 different messages: one that should trigger it, one that's borderline, and one that shouldn't trigger it
5. Adjust until each skill fires reliably for the right messages

---

## What You Built

Descriptions that work as reliable triggers. Your skills now activate when they should and stay quiet when they shouldn't.

---

## Common Mistakes

**Writing descriptions for yourself instead of for Cowork.** You know what your skill does, but Cowork only knows what the description says. Write the description as if Cowork has never seen the skill before (because in a new session, it hasn't).

**Too many active skills.** If you have 15+ skills active, Cowork has more descriptions to scan and more chances for confusion. Keep 5-10 active at a time. Toggle the rest off.

**Descriptions that overlap.** If two skills have similar descriptions, Cowork might pick the wrong one. Differentiate them clearly, or combine them into one skill.
