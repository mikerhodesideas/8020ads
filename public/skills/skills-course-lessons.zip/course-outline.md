# Build Your Own Skills - Course Outline

A short course on creating custom Cowork skills. No coding required.

## Beginner (Lessons 1-4)

1. **What Skills Actually Are** - Why packaging instructions as a skill beats retyping prompts every time
2. **Your First Skill in 5 Minutes** - Use the built-in Skill Creator to build a working skill
3. **Inside a SKILL.md File** - Understand the file you just built so you can edit it yourself
4. **Setting Up Your Workspace** - Folder structure, Global Instructions, and context files

## Intermediate (Lessons 5-11)

5. **The "Do It First" Method** - The fastest way to create great skills: do the work, then package it
6. **Descriptions That Trigger** - How Cowork decides which skill to use (and how to control it)
7. **Adding Your Business Context** - The difference between generic and genuinely useful output
8. **Skills That Ask Questions** - Building interactive skills that gather info before they run
9. **Connecting to Real Tools** - Wire your skills into Gmail, Calendar, Drive, and more
10. **Testing Your Skills** - Run evaluations to measure whether your skill actually works
11. **Editing and Improving Skills** - Take any skill (yours or someone else's) and make it better

## Advanced (Lesson 12)

12. **Where This Goes Next** - Multi-skill workflows, scheduled automation, and the AI Scout path
