# 8 - Skills That Ask Questions

Some skills need information from you before they can run. Rather than guessing or producing something generic, a well-built skill asks the right questions first.

---

## Why This Matters

Not every task can start from a single prompt. A "write a proposal" skill needs to know: for which client? What services? What budget range? What timeline?

You could include all of that in your initial message every time. But you'll forget something, and then the output is wrong, and you have to start over. It's better to build the questions into the skill itself, so it always gathers what it needs before running.

---

## How It Works

In your SKILL.md steps, add questions at the start:

```markdown
## Steps

1. Ask the user for the following information before proceeding:
   - Client name
   - What service or product is this proposal for?
   - Approximate budget range (if known)
   - Deadline for delivering the proposal

2. If the user has already provided some of this information in their
   initial message, skip those questions and only ask for what's missing.

3. Once all information is gathered, proceed to write the proposal...
```

The key detail is step 2: don't ask questions the user already answered. If someone types "Write a proposal for Meridian Pool Supplies for our Google Ads management service, budget around $5k/month," the skill should only ask about the deadline, not re-ask everything.

---

## How Many Questions Is Too Many?

Two to three questions is the sweet spot. More than that feels like an interrogation, and people will stop using the skill.

If your skill needs more than three inputs, consider whether some of them could be:

- **Pulled from context files** (your services, pricing, standard terms)
- **Given sensible defaults** ("If no deadline mentioned, use 5 business days")
- **Asked only when relevant** ("If the budget is over $10k, ask about payment terms")

The goal is to reduce friction while still getting what the skill needs.

---

## Conditional Questions

Sometimes you only need to ask certain questions based on earlier answers:

```markdown
## Steps

1. Ask the user: "Is this for a new client or an existing client?"

2. If new client:
   - Ask for company name, contact person, and what they do
   - Read context/services.md for available offerings

3. If existing client:
   - Ask for the client name only
   - Look for an existing brief in the output/ folder
```

This keeps the interaction short for repeat tasks while still handling new situations properly.

---

## The "Preflight Check" Pattern

Some skills benefit from confirming assumptions before running. Instead of asking open-ended questions, present what the skill plans to do and ask for confirmation:

```markdown
## Steps

1. Read the user's input and the context files.

2. Before producing output, present a brief summary:
   "Here's what I'm planning to create:
   - A proposal for [client name]
   - Covering [service]
   - Budget: [amount]
   - Deadline: [date]
   Does this look right? Anything to change?"

3. Wait for confirmation before proceeding.
```

This catches misunderstandings early. It takes five seconds to confirm, versus five minutes to redo a proposal that got the basics wrong.

---

## Hands-On

1. Pick a skill that currently requires you to include a lot of detail in your initial message
2. Add 2-3 questions to the start of the skill
3. Include the "skip if already provided" instruction
4. Test it three ways:
   - With a vague message ("Write a proposal")
   - With a partial message ("Write a proposal for Meridian, Google Ads management")
   - With a complete message (all details included)

The skill should ask the right number of questions each time: all of them for the vague message, just the missing ones for the partial, and none for the complete message.

---

## What You Built

A skill that gathers the information it needs without making you remember everything upfront. It adapts to how much context you provide.

---

## Common Mistakes

**Asking too many questions.** If your skill asks five questions before doing anything, people will just type the whole thing as a prompt instead. Keep it to 2-3 max.

**Not handling partial information.** If the user already told you the client name in their message and your skill asks again, it feels broken. Always check what's already been provided.

**Asking vague questions.** "What do you need?" is too open. "Which client is this for?" is specific and fast to answer. Make every question easy to respond to.
