# 9 - Connecting to Real Tools

Until now, your skills have worked with text you paste in and files in your folder. This lesson opens the door to live data: your actual emails, calendar, documents, and more.

---

## Why This Matters

A meeting summary skill is useful. A meeting summary skill that pulls today's calendar events, checks the attendees against your contacts, and drafts a follow-up email in Gmail? That's a different category entirely.

Connectors are what turn Cowork from a text-processing tool into something that actually participates in your workflow.

---

## What Connectors Are

Connectors are integrations that give Cowork access to external tools. They're set up through the Cowork interface (Customize > Connectors) and typically require you to log in with your existing account (Google, Slack, etc.).

Each connector comes with two types of permissions:

**Read access:** View your data. See your calendar events, read your emails, view files in Drive.

**Write access:** Take actions. Create calendar events, draft emails, update documents.

You control these separately. You can give a connector read access without write access, so Cowork can see your calendar but can't create events until you explicitly allow it.

---

## Available Connectors

Cowork has native connectors for the most common tools:

- **Gmail** - Read emails, search inbox, create drafts, send (if you allow it)
- **Google Calendar** - View events, check availability, create events
- **Google Drive** - Read documents, create and update files
- **Slack** - Read channels, post messages, search conversations
- **Notion** - Read and update pages and databases
- **Microsoft 365** - Outlook, OneDrive, Teams equivalents

There are others, and more are being added regularly. Check the Connectors panel in Cowork for the current list.

---

## Setting Up Your First Connector

Let's connect Gmail. It's the most universally useful.

1. Open Cowork, go to Customize > Connectors
2. Find Gmail and click Connect
3. Log in with your Google account and approve the permissions
4. Choose your permission level:
   - **Read emails:** Always allow (this is safe, it just views)
   - **Create drafts:** Always allow (drafts aren't sent, you review first)
   - **Send emails:** Needs approval (you'll be asked each time)

The "draft only" pattern is important. Let Cowork create drafts that you review and send yourself. This keeps you in control while still saving time.

---

## Using Connectors in Skills

Once a connector is set up, your skills can reference it:

```markdown
## Steps

1. Use the Gmail connector to find the 5 most recent unread emails.
2. For each email, determine if it's:
   - Urgent (needs a response today)
   - Follow-up (needs a response this week)
   - FYI (read and archive)
   - Junk (archive immediately)
3. For urgent emails, draft a brief response.
4. Save a summary of all emails and their categories to output/inbox-triage.md.

## Connector Requirements

This skill requires the Gmail connector with read and draft-create permissions.
```

The "Connector Requirements" section at the bottom tells anyone using the skill what they need to set up first.

---

## A Practical Example: Daily Briefing

Here's a skill that combines two connectors:

```markdown
## Goal

Produce a morning briefing covering today's calendar and priority emails.

## Steps

1. Read context/about-me.md for priorities and schedule preferences.
2. Use the Google Calendar connector to get today's events.
3. Use the Gmail connector to get unread emails from the last 12 hours.
4. Write a briefing with three sections:
   - Today's Schedule (events with times, attendees, and prep notes)
   - Priority Emails (anything that needs action today)
   - FYI (everything else, one line each)
5. Save to output/briefing-YYYY-MM-DD.md.

## Connector Requirements

- Google Calendar (read access)
- Gmail (read access)
```

This skill turns "check my calendar and email" from a 15-minute morning routine into a 30-second scan.

---

## Hands-On

1. Connect at least one connector (Gmail or Google Calendar are the easiest to start with)
2. Set permissions conservatively: read access on "always allow," write access on "needs approval"
3. Create a skill that uses the connector (use the daily briefing example above, or adapt it)
4. Test it and check that the data it pulls is accurate

---

## What You Built

A skill connected to a live data source. Your skills can now work with real information from your actual tools, not just text you paste in.

---

## Common Mistakes

**Giving full write access immediately.** Start with read-only or draft-only. Once you trust the skill's output, you can open up write access. It's easy to grant more permissions later, hard to undo a sent email.

**Not noting connector requirements.** If you share a skill or come back to it later, you'll forget what connectors it needs. Always include a "Connector Requirements" section.

**Expecting connectors to work offline.** Connectors need an internet connection and an active session in Cowork. If Cowork is closed or your computer is asleep, connector-based skills won't run (relevant for scheduled tasks, covered in Lesson 12).
