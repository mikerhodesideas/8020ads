# 4 - Setting Up Your Workspace

Skills work best when Cowork knows who you are, how you work, and where things go. This lesson sets up the foundation that every future skill will benefit from.

---

## Why This Matters

A skill that writes a client email without knowing your name, your business, or your tone of voice will produce something generic. The same skill, given that context, produces something you'd actually send.

Context is what separates "this is a decent AI draft" from "this sounds like me."

---

## Folder Structure

When you open Cowork, it asks you to select a folder. This folder is your workspace. Everything Cowork reads and creates lives here.

Start with this structure:

```
my-workspace/
  context/
    about-me.md
    brand-voice.md
    working-preferences.md
  output/
  skills/
```

**context/** holds the files that tell Cowork who you are and how to work. Every skill can reference these.

**output/** is where Cowork saves finished work. Keeping output separate from context means your workspace stays clean.

**skills/** is optional. Some people like to keep their skill files here for easy access, but skills installed through the Customize panel don't need to live in your folder.

Create this folder structure now. You can do it in Finder, Explorer, or ask Cowork to create it for you.

---

## The Three Context Files

### about-me.md

This tells Cowork who you are. Include:

- Your name and role
- Your business (what you do, who you serve)
- Your current priorities (what matters right now)
- Your daily schedule and non-negotiables (e.g., "no meetings before 10am")

Example:

```markdown
# About Me

I'm Sarah Chen, founder of Greenline Digital. We manage Google Ads for
e-commerce brands doing $1M-$10M in annual revenue.

Current priorities:
- Onboarding 3 new clients this month
- Building out our reporting process
- Creating content for LinkedIn (posting 3x per week)

Schedule:
- Deep work: 8am-11am (no meetings, no email)
- Client calls: 1pm-4pm
- Admin and planning: 4pm-5pm
```

### brand-voice.md

This tells Cowork how to sound when writing for you:

- Your tone (casual, professional, direct, warm?)
- Words or phrases you use often
- Words or phrases you never use
- Examples of writing you like (paste in a paragraph from something you've written)

Example:

```markdown
# Brand Voice

Tone: Direct, friendly, no jargon. Write like I'm explaining something
to a smart friend over coffee.

Always use:
- "I" not "we" (I'm a solo founder)
- Short paragraphs (3 sentences max)
- Concrete examples over abstract claims

Never use:
- "Leverage", "synergy", "utilize", "cutting-edge"
- Corporate buzzwords
- Emojis (unless explicitly asked)

Example of my writing style:
"Most Google Ads accounts waste 20% of their budget on search terms that
will never convert. The fix takes 15 minutes. Here's exactly what to do."
```

### working-preferences.md

This tells Cowork how you like to work:

- Where to save output
- How to handle uncertainty (ask you, or make a decision and flag it?)
- Your preferences for file naming, formatting, length

Example:

```markdown
# Working Preferences

- Save all output to the output/ folder
- Use markdown format unless I ask for something else
- File names: YYYY-MM-DD-description.md
- If you're unsure about something, ask me before proceeding
- Keep summaries under 500 words
- When writing emails, draft only. Never send.
```

---

## Global Instructions

Global Instructions are separate from your folder files. They follow you across every folder and every session. Set them in Cowork's settings (not in a file).

The most important Global Instruction: tell Cowork to read your context files at the start of every task.

Go to Settings, find Global Instructions, and add something like:

```
At the start of every task, read the files in my context/ folder
(about-me.md, brand-voice.md, working-preferences.md) to understand
who I am and how I work. Apply this context to everything you produce.
```

This single instruction makes Cowork dramatically more consistent, because it stops relying on memory (which resets every session) and starts reading your actual files.

---

## Hands-On

1. Create the folder structure shown above
2. Write your own versions of the three context files (about-me.md, brand-voice.md, working-preferences.md)
3. Set up the Global Instruction to read those files
4. Test it: ask Cowork to write a short email to a client. Does it use your name? Your tone? Your preferred format?

---

## What You Built

You now have a workspace with context files that every skill can reference, and a Global Instruction that ensures Cowork reads them. Every skill you build from here will benefit from this foundation.

---

## Common Mistakes

**Putting everything in Global Instructions.** Global Instructions have limited space and can't be easily referenced by skills. Put the details in files and use Global Instructions to point Cowork to those files.

**Being too vague in your context files.** "I like professional writing" doesn't help. "Short sentences, no jargon, always include a specific example" helps a lot.

**Skipping this lesson.** It's tempting to jump ahead to building more skills. But without context files, every skill you build will produce generic output. Ten minutes here saves hours later.
