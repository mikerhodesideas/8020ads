# 10 - Testing Your Skills

You've been building skills based on feel: run them, look at the output, decide if it's good enough. This lesson introduces a more systematic approach: defining what "good" means, testing against those criteria, and measuring pass rates.

---

## Why This Matters

"It looks about right" is how most people evaluate AI output. The problem is that "about right" shifts depending on your mood, the time of day, and how rushed you are. What felt fine on Monday might look terrible on Thursday.

Testing gives you an objective answer. You define what the output must include, run the skill multiple times, and count how often it hits the mark. Numbers replace vibes.

---

## How Evaluation Works

The evaluation process has three parts:

### 1. Define criteria

Write 3-5 specific, binary (yes/no) tests for your skill's output. Each criterion should be something you can check without subjective judgment.

Good criteria:
- "Output includes a subject line"
- "Summary is under 300 words"
- "Action items include a responsible person for each item"
- "Output is saved as a markdown file, not displayed in chat"
- "Tone matches the brand voice (no jargon, no corporate speak)"

Bad criteria:
- "Output is good" (too vague)
- "Writing is high quality" (subjective)
- "It sounds professional" (means different things to different people)

### 2. Run the skill multiple times

Use the same input (or a set of test inputs) and run the skill 3-5 times. Save each output.

Why multiple times? Because AI output varies. A skill might work perfectly on the first run and miss something on the third. Testing multiple times reveals how consistent the skill is.

### 3. Score against criteria

For each run, check every criterion. Did it pass or fail? Calculate the pass rate.

Example:
- 5 criteria, 3 runs = 15 total checks
- 13 passed = 87% pass rate
- The 2 failures were both on "action items include a responsible person"

Now you know exactly what to fix: the step that extracts action items needs to be more specific about including the responsible person.

---

## Running an Evaluation in Cowork

You can ask Cowork to run an eval for you:

```
I want to test my meeting-summary skill. Here are my criteria:

1. Output has a "Key Decisions" section with at least one bullet point
2. Output has an "Action Items" section with owner names for each item
3. Output has an "Open Questions" section
4. Summary context paragraph is under 100 words
5. Output is saved as a markdown file in the output/ folder

Run the skill 3 times using this test input:
[paste your test meeting notes here]

Score each run against the criteria and give me the pass rates.
```

Cowork will run the skill three times, check each output against your five criteria, and report the results.

---

## What to Do With the Results

**100% pass rate:** Your skill is solid. Move on.

**80-99% pass rate:** Look at which criteria failed. Usually it's one specific step that needs tightening. Edit that step in the SKILL.md and re-run the eval.

**Below 80%:** Something fundamental is off. The steps might be too vague, the output format might not be defined clearly enough, or the skill might need more context. Revisit Lessons 3 and 7.

---

## A/B Testing Context Files

Here's a powerful use of evaluation: test whether a specific context file actually improves output.

Run the same skill, same input, same criteria, but twice: once with brand-voice.md referenced, once without. Compare pass rates.

If the version with context scores higher, the context file is working. If the scores are the same, the context file might not be adding value for this particular skill. Remove it and save the token budget.

---

## Hands-On

1. Pick your most-used skill
2. Write 5 evaluation criteria (specific, binary, checkable)
3. Ask Cowork to run the skill 3 times against a test input and score the results
4. If anything failed, edit the relevant step in the SKILL.md
5. Re-run the eval to confirm the fix worked

---

## What You Built

An evaluation framework for your skills. You can now objectively measure whether a skill works and pinpoint exactly what to fix when it doesn't.

---

## Common Mistakes

**Writing criteria you can't objectively check.** "Does it sound natural?" is subjective. "Does it avoid the words 'utilize', 'leverage', and 'synergy'?" is checkable. Make criteria binary.

**Only testing once.** A single run doesn't tell you if the skill is consistent. Run at least 3 times. If you're building something important, run 5.

**Fixing symptoms instead of causes.** If the skill keeps missing action item owners, don't just re-run until it works. Fix the step that extracts action items. Make the instruction more specific: "For each action item, include the person responsible. If no person was named, write 'Owner: TBD'."
