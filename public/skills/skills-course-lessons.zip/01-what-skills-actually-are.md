# 1 - What Skills Actually Are

You've just seen what Cowork can do with skills installed. Now it's time to understand what a skill actually is, and why it changes everything about how you use AI.

---

## The Problem With Prompting

Most people use AI the same way every time. They open a chat, type a long prompt explaining what they want, get a result, and close the window. Next time they need the same thing, they type it all again. Or they dig through old conversations trying to find that one prompt that worked.

This is like writing the same email from scratch every single day. It works, but it wastes time and the quality varies every time. Some days you remember to include all the details. Other days you forget half of them and get a mediocre result.

---

## What a Skill Is

A skill is a set of instructions saved as a file. That's it.

You write out exactly what you want Cowork to do, step by step, save it once, and Cowork follows those instructions every time. The instructions include what the goal is, what steps to take, what tools to use, and what the output should look like.

The file is written in plain English (technically it's a markdown file, but you don't need to know what that means). There's no code. No programming. Just clear, specific instructions that Cowork reads and follows.

Think of it like a recipe. A good cook can improvise, but a recipe means anyone can produce a consistent result. Skills are recipes for Cowork.

---

## Why This Matters

Here's the stat that convinced me: when you test a skill against a simple prompt for the same task, the skill produces the right output roughly 100% of the time. The raw prompt? About 33%.

That's not because the AI is smarter with a skill. It's because the skill removes ambiguity. Every step is defined. Every expectation is spelled out. There's no room for the AI to guess what you meant, because you've already told it.

This is the difference between asking someone "Can you handle the invoices?" and giving them a checklist: open the folder, check each invoice against the PO number, flag anything over $5,000, and save the summary to this specific sheet. Same person, wildly different results.

---

## What a Skill Looks Like (Don't Worry About the Details Yet)

Here's a simplified version of what a skill file contains:

- **Name:** What the skill is called
- **Description:** When Cowork should use it (this is important, and we'll cover it in Lesson 6)
- **Goal:** What the skill produces and why it exists
- **Steps:** A numbered list of what to do, in order
- **Output format:** What the finished result should look like

You'll build your first one in the next lesson. For now, the point is: it's just a text file with instructions.

---

## Where Skills Live

In Cowork, skills are managed through the Customize panel (the paintbrush icon in the sidebar). You can:

- **Add skills** by installing them from a file or using the built-in Skill Creator
- **Toggle skills on and off** so only the ones you need are active
- **View and edit** the skill files at any time

Each active skill takes up a small amount of Cowork's attention (its "context window"). This means you don't want 50 skills active at once. Keep the ones you're using turned on, and toggle the rest off. Five to ten active skills is a good range.

---

## What You'll Build in This Course

Over the next 11 lessons, you'll go from zero skills to a working collection that handles real tasks in your business. Here's the arc:

- **Lessons 2-4:** Build your first skill, understand the file format, set up your workspace
- **Lessons 5-8:** Create skills the smart way, make them trigger reliably, add your business context, and build interactive skills
- **Lessons 9-11:** Connect skills to real tools (email, calendar), test them properly, and learn to improve any skill
- **Lesson 12:** Where this all leads, including automation, multi-skill workflows, and the community of people building this stuff together

Every lesson ends with something built. No theory-only lessons after this one.

---

## Common Mistakes at This Stage

**"I need to learn to code first."** You don't. Skills are plain English instructions in a text file. If you can write a clear email, you can write a skill.

**"I'll just keep using prompts."** You can. But you'll keep getting inconsistent results and retyping the same context every session. Skills solve both problems.

**"I need the perfect skill before I start."** Your first skill will be rough. That's fine. You'll improve it in Lesson 11. The important thing is to start.
