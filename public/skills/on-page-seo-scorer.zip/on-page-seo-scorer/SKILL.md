---
name: on-page-seo-scorer
description: "Analyze any URL's on-page SEO and score against traditional best practices and AI-readiness criteria. Fetches page, parses HTML, scores 11 categories. Outputs scored report with prioritized recommendations."
version: 1.0
---

# On-Page SEO Scorer

Analyze any URL's on-page SEO and score it against both traditional best practices and 2026 AI-readiness criteria. Produces a detailed scorecard with an overall grade, section scores, and prioritized recommendations.

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

## When to Use

- User provides a URL and asks for SEO analysis
- User wants to check on-page SEO quality
- User asks about AI-readiness of their content
- User says "seo score", "on-page audit", "check my seo"

## Input Requirements

**Required:** A URL to analyze

**Optional:**
- Target keyword (for keyword-specific scoring)
- Competitor URLs for SERP comparison

## Process

### Step 1: Fetch and Parse the Page

Use WebFetch to retrieve the target URL's HTML content. Save the fetched HTML to a temp file, then run the bundled analysis script at `scripts/analyze-page.cjs`:

```bash
node scripts/analyze-page.cjs \
  --url="https://example.com/page" \
  --html="page.html" \
  --output="analysis.json"
```

The script requires `cheerio` (install via `npm install cheerio` if not available). It extracts and scores all on-page elements from the raw HTML.

### Step 2: Review Scores

The script scores 11 categories:

| Category | Max Points | What It Measures |
|----------|-----------|-----------------|
| Title Tag | 10 | Length, keyword, click-worthiness |
| Meta Description | 10 | Length, CTA, keyword |
| Heading Hierarchy | 10 | H1 presence, nesting, descriptiveness |
| Content Quality | 15 | Word count, readability, structure |
| Internal Links | 10 | Count, anchor quality, distribution |
| Image Optimization | 10 | Alt text, formats, lazy loading |
| Schema Markup | 10 | JSON-LD, types, breadcrumbs |
| Page Speed Signals | 5 | HTML size, render-blocking, hints |
| Mobile Experience | 5 | Viewport, touch targets, fonts |
| AI-Readiness | 15 | First 200 words, entities, citations |
| Technical SEO | bonus | Canonical, OG tags, robots |

### Step 3: Competitor Comparison (if keyword provided)

1. Use WebSearch to find the top 3 ranking pages for the target keyword
2. Fetch each competitor page and run the analysis script on each
3. Include side-by-side comparison in the report

### Step 4: Generate HTML Report

Run the bundled report generator at `scripts/generate-report.cjs`:

```bash
node scripts/generate-report.cjs \
  --input="analysis.json" \
  --output="seo-scorecard.html"
```

### Step 5: Present Results

- Open the HTML report in browser
- Present a text summary to the user with the overall grade and top recommendations

## Grading Scale

| Grade | Score | Meaning |
|-------|-------|---------|
| A | 85-100 | Well-optimized |
| B | 70-84 | Good, minor improvements needed |
| C | 55-69 | Significant gaps |
| D | 40-54 | Major issues |
| F | Below 40 | Needs overhaul |

## Key Rules

1. Score what exists, not what you assume - only score elements found in the HTML
2. AI-readiness is 15% of the total - it matters, weight it accordingly
3. Context matters for content length - a product page at 300 words is fine; a guide at 300 words is not
4. Recommendations must be specific - not "improve your title tag" but "shorten title from 78 to 58 characters"
5. No em dashes in any output - use " - " instead
