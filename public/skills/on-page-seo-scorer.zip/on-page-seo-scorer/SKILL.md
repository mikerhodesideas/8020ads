---
name: on-page-seo-scorer
description: |
  Analyze any URL's on-page SEO and score against traditional best practices and 2026 AI-readiness
  criteria. Fetches page, parses HTML, scores title/meta/headings/content/links/images/schema/speed/mobile/AI-readiness.
  Compares against top 3 SERP competitors. Outputs scored report with prioritized recommendations.
  AUTO-ACTIVATE for: "on-page seo", "seo score", "page seo audit", "seo analysis", "check seo",
  "ai readiness", "seo scorecard".
version: 1.0
last_updated: 2026-03-21
members: true
context: fork
hooks:
  PreToolUse:
    - matcher: "WebFetch"
      command: "sleep 2"
---

# On-Page SEO Scorer

Analyze any URL's on-page SEO and score it against both traditional best practices and 2026 AI-readiness criteria. Produces a detailed scorecard with an overall grade, section scores, and prioritized recommendations.

## When to Use

- User provides a URL and asks for SEO analysis
- User wants to check on-page SEO quality
- User asks about AI-readiness of their content
- User says "seo score", "on-page audit", "check my seo"

## Input Requirements

**Required:**
- A URL to analyze

**Optional:**
- Target keyword (for keyword-specific scoring)
- Competitor URLs or target keyword for SERP comparison (top 3)

## Process

### Step 1: Fetch and Parse the Page

Use WebFetch to retrieve the target URL's HTML content.

Then run the analysis script:

```bash
node .claude/skills/on-page-seo-scorer/scripts/analyze-page.cjs \
  --url="https://example.com/page" \
  --html=".claude/skills/on-page-seo-scorer/tmp/page.html" \
  --output=".claude/skills/on-page-seo-scorer/tmp/analysis.json"
```

Save the fetched HTML to `tmp/page.html` first, then run the script. The script extracts and scores all on-page elements from the raw HTML.

### Step 2: Score Each Category

The script scores 11 categories. Claude reviews the raw scores and adjusts based on context.

#### Category 1: Title Tag (10 points)
- Length: 50-60 chars ideal (deduct for <30 or >70)
- Keyword inclusion (if target keyword provided)
- Uniqueness/click-worthiness (no generic "Home" or "Welcome")
- Front-loaded keyword placement

#### Category 2: Meta Description (10 points)
- Length: 120-160 chars ideal
- Contains call-to-action or value proposition
- Keyword presence (natural, not stuffed)
- Unique (not duplicated from title)

#### Category 3: Heading Hierarchy (10 points)
- Single H1 present
- H1 contains primary topic/keyword
- Logical H2-H3-H4 nesting (no skipped levels)
- Keyword distribution across H2s (natural, not forced)
- Descriptive headings (not "Section 1", "Part 2")

#### Category 4: Content Quality (15 points)
- Word count (scored relative to intent: 300+ for product, 1000+ for blog, 2000+ for pillar)
- Reading level (Flesch-Kincaid: 60-70 ideal for most content)
- Paragraph length (short paragraphs score higher)
- Topical depth (number of subtopics/entities covered)
- Originality signals (specific data, examples, unique insights)

#### Category 5: Internal Links (10 points)
- Link count (at least 3 internal links)
- Anchor text relevance (descriptive, not "click here")
- Link distribution throughout content (not all at bottom)
- No broken internal links

#### Category 6: Image Optimization (10 points)
- All images have alt text
- Alt text is descriptive (not "image1.jpg")
- Image file sizes (flag >200KB without lazy loading)
- Next-gen formats used (WebP, AVIF)
- Lazy loading on below-fold images

#### Category 7: Schema Markup (10 points)
- Schema present (JSON-LD preferred)
- Appropriate type for page content (Article, Product, FAQ, HowTo, LocalBusiness)
- Required properties populated
- No validation errors
- Breadcrumb schema present

#### Category 8: Page Speed Signals (5 points)
- Total HTML size (flag >100KB)
- Render-blocking resources count
- Above-the-fold content loaded without JS dependency
- Resource hints present (preconnect, preload)

#### Category 9: Mobile Experience (5 points)
- Viewport meta tag present
- No horizontal scroll indicators (fixed-width elements)
- Touch targets sized appropriately (min 44x44px)
- Font sizes readable without zoom (min 16px body)

#### Category 10: AI-Readiness (15 points)
- **First 200 words** directly answer the primary query (5 pts)
- **Entity clarity** - author/brand/org clearly identified with credentials (3 pts)
- **Citation-worthy content** - original statistics, unique data, quotable definitions (4 pts)
- **Structured answers** - FAQ schema, clear Q&A format, definition patterns (3 pts)

#### Category 11: Technical SEO Signals (bonus, not scored)
- Canonical tag present and correct
- Open Graph / Twitter Card tags
- Robots directives
- Language declaration

### Step 3: Competitor Comparison (Optional)

If a target keyword is provided, fetch the top 3 SERP results and run the same analysis on each. Compare scores across all pages to identify relative strengths and weaknesses.

### Step 4: Generate Scorecard

Present the results as a scored report:

**Overall Grade:** A/B/C/D/F (based on total score out of 100)
- A: 85-100
- B: 70-84
- C: 55-69
- D: 40-54
- F: Below 40

**Per-category scores** with specific findings and fix recommendations.

**Prioritized Recommendations** ordered by:
1. Estimated traffic impact (high/medium/low)
2. Implementation effort (quick win / medium / major project)

Quick wins first, then medium effort, then major projects.

### Step 5: Output

Write the scorecard to an HTML report file:

```bash
node .claude/skills/on-page-seo-scorer/scripts/generate-report.cjs \
  --input=".claude/skills/on-page-seo-scorer/tmp/analysis.json" \
  --output="path/to/seo-scorecard.html"
```

Also present a text summary to the user.

## Output Files

| File | Purpose |
|------|---------|
| `tmp/page.html` | Fetched page HTML (ephemeral) |
| `tmp/analysis.json` | Raw analysis data (ephemeral) |
| User-specified HTML | Formatted scorecard report |

## Example Prompts

> "Score the on-page SEO for https://example.com/services"

> "Check the SEO of this page and compare it to competitors for 'pool cleaning melbourne'"

> "How AI-ready is this page's content? https://example.com/blog/guide"

## Key Rules

1. **Score what exists, not what you assume** - Only score elements actually found in the HTML
2. **AI-readiness is 15% of the total** - It matters in 2026, weight it accordingly
3. **Context matters for content length** - A product page at 300 words is fine; a "complete guide" at 300 words is not
4. **Recommendations must be specific** - Not "improve your title tag" but "shorten title from 78 to 58 characters, move 'Melbourne' to position 1"
5. **Competitor comparison is relative** - A score of 65 that beats all competitors is different from a 65 where competitors score 80+
