#!/usr/bin/env node
/**
 * generate-report.cjs
 * 
 * Generates an HTML scorecard report from the analysis JSON.
 * Light theme, clean design, no rounded corners (border-radius: 2px max).
 * 
 * Usage:
 *   node generate-report.cjs --input=analysis.json --output=seo-scorecard.html
 */

const fs = require('fs');
const path = require('path');

// --- Argument parsing ---
const args = {};
process.argv.slice(2).forEach(arg => {
  const [key, ...rest] = arg.replace(/^--/, '').split('=');
  args[key] = rest.join('=');
});

if (!args.input) {
  console.error('Usage: node generate-report.cjs --input=analysis.json --output=seo-scorecard.html');
  process.exit(1);
}

const inputPath = path.resolve(args.input);
const outputPath = path.resolve(args.output || 'seo-scorecard.html');

function gradeColor(grade) {
  const colors = { A: '#22c55e', B: '#84cc16', C: '#eab308', D: '#f97316', F: '#ef4444' };
  return colors[grade] || '#6b7280';
}

function severityColor(severity) {
  const colors = { critical: '#ef4444', warning: '#f97316', minor: '#eab308', pass: '#22c55e', info: '#6b7280' };
  return colors[severity] || '#6b7280';
}

function severityIcon(severity) {
  const icons = { critical: 'X', warning: '!', minor: '~', pass: '+', info: 'i' };
  return icons[severity] || '?';
}

function categoryLabel(key) {
  const labels = {
    titleTag: 'Title Tag',
    metaDescription: 'Meta Description',
    headingHierarchy: 'Heading Hierarchy',
    contentQuality: 'Content Quality',
    internalLinks: 'Internal Links',
    imageOptimization: 'Image Optimization',
    schemaMarkup: 'Schema Markup',
    pageSpeed: 'Page Speed Signals',
    mobileExperience: 'Mobile Experience',
    aiReadiness: 'AI-Readiness',
    technicalSEO: 'Technical SEO'
  };
  return labels[key] || key;
}

function main() {
  if (!fs.existsSync(inputPath)) {
    console.error(`File not found: ${inputPath}`);
    process.exit(1);
  }

  const data = JSON.parse(fs.readFileSync(inputPath, 'utf-8'));
  const { overall, categories, recommendations, url, targetKeyword, analyzedAt } = data;

  // Build category cards
  let categoryCards = '';
  for (const [key, cat] of Object.entries(categories)) {
    if (key === 'technicalSEO') continue; // Show separately
    
    const pct = cat.max > 0 ? Math.round((cat.score / cat.max) * 100) : 0;
    const barColor = pct >= 70 ? '#22c55e' : pct >= 50 ? '#eab308' : '#ef4444';
    
    let findingsHTML = '';
    for (const f of cat.findings) {
      const color = severityColor(f.severity);
      const icon = severityIcon(f.severity);
      const text = f.issue || f.info;
      findingsHTML += `<div style="display:flex;align-items:flex-start;gap:8px;margin:4px 0;padding:4px 0;border-bottom:1px solid #f3f4f6;">
        <span style="display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;font-size:12px;font-weight:bold;color:white;background:${color};border-radius:2px;flex-shrink:0;">${icon}</span>
        <span style="font-size:14px;color:#374151;">${text}</span>
      </div>`;
    }
    
    categoryCards += `
    <div style="border:1px solid #e5e7eb;border-radius:2px;padding:20px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h3 style="margin:0;font-size:16px;font-weight:600;color:#111827;">${categoryLabel(key)}</h3>
        <span style="font-size:18px;font-weight:700;color:${barColor};">${cat.score}/${cat.max}</span>
      </div>
      <div style="background:#f3f4f6;height:8px;border-radius:2px;margin-bottom:16px;">
        <div style="background:${barColor};height:8px;border-radius:2px;width:${pct}%;"></div>
      </div>
      ${findingsHTML}
    </div>`;
  }

  // Technical SEO section (informational)
  const techCat = categories.technicalSEO;
  let techHTML = '';
  if (techCat) {
    for (const f of techCat.findings) {
      const color = severityColor(f.severity);
      const icon = severityIcon(f.severity);
      const text = f.issue || f.info;
      techHTML += `<div style="display:flex;align-items:flex-start;gap:8px;margin:4px 0;">
        <span style="display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;font-size:12px;font-weight:bold;color:white;background:${color};border-radius:2px;flex-shrink:0;">${icon}</span>
        <span style="font-size:14px;color:#374151;">${text}</span>
      </div>`;
    }
  }

  // Recommendations section
  let recsHTML = '';
  for (const rec of (recommendations || []).slice(0, 15)) {
    const color = severityColor(rec.severity);
    recsHTML += `<tr>
      <td style="padding:8px 12px;border-bottom:1px solid #f3f4f6;"><span style="display:inline-block;padding:2px 8px;font-size:11px;font-weight:600;color:white;background:${color};border-radius:2px;">${rec.severity.toUpperCase()}</span></td>
      <td style="padding:8px 12px;border-bottom:1px solid #f3f4f6;font-size:13px;color:#6b7280;">${categoryLabel(rec.category)}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #f3f4f6;font-size:14px;color:#111827;">${rec.issue}</td>
    </tr>`;
  }

  const dateStr = analyzedAt ? new Date(analyzedAt).toLocaleDateString('en-AU', { year: 'numeric', month: 'long', day: 'numeric' }) : '';

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SEO Scorecard - ${url || 'Page Analysis'}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #ffffff; color: #111827; padding: 40px 20px; max-width: 900px; margin: 0 auto; }
    h1 { font-size: 24px; font-weight: 700; margin-bottom: 4px; }
    h2 { font-size: 20px; font-weight: 600; margin: 32px 0 16px; border-left: 4px solid #111827; padding-left: 12px; }
    .meta { font-size: 14px; color: #6b7280; margin-bottom: 24px; }
    .grade-box { display: inline-flex; align-items: center; gap: 16px; padding: 20px 32px; border: 2px solid ${gradeColor(overall.grade)}; border-radius: 2px; margin: 16px 0 32px; }
    .grade-letter { font-size: 48px; font-weight: 800; color: ${gradeColor(overall.grade)}; }
    .grade-detail { font-size: 14px; color: #6b7280; }
    .grade-score { font-size: 20px; font-weight: 600; color: #111827; }
    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; padding: 8px 12px; font-size: 12px; font-weight: 600; color: #6b7280; text-transform: uppercase; border-bottom: 2px solid #e5e7eb; }
  </style>
</head>
<body>
  <h1>On-Page SEO Scorecard</h1>
  <div class="meta">
    ${url ? `<div>URL: <a href="${url}" style="color:#2563eb;">${url}</a></div>` : ''}
    ${targetKeyword ? `<div>Target keyword: <strong>${targetKeyword}</strong></div>` : ''}
    ${dateStr ? `<div>Analyzed: ${dateStr}</div>` : ''}
  </div>
  
  <div class="grade-box">
    <div class="grade-letter">${overall.grade}</div>
    <div>
      <div class="grade-score">${overall.score} / ${overall.maxScore}</div>
      <div class="grade-detail">${overall.percentage}% overall score</div>
    </div>
  </div>

  <h2>Category Scores</h2>
  ${categoryCards}

  ${techHTML ? `<h2>Technical SEO Signals (Informational)</h2>
  <div style="border:1px solid #e5e7eb;border-radius:2px;padding:20px;">${techHTML}</div>` : ''}

  <h2>Prioritized Recommendations</h2>
  ${recsHTML ? `<table>
    <thead><tr><th>Severity</th><th>Category</th><th>Recommendation</th></tr></thead>
    <tbody>${recsHTML}</tbody>
  </table>` : '<p style="color:#6b7280;">No issues found. Well optimized!</p>'}

  <div style="margin-top:48px;padding-top:16px;border-top:1px solid #e5e7eb;font-size:12px;color:#9ca3af;">
    Generated by On-Page SEO Scorer skill
  </div>
</body>
</html>`;

  const outDir = path.dirname(outputPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  fs.writeFileSync(outputPath, html);
  console.log(`HTML report written to: ${outputPath}`);
}

main();
