#!/usr/bin/env node
/**
 * analyze-page.cjs
 * 
 * Parses an HTML file and scores on-page SEO across 11 categories.
 * Uses cheerio for HTML parsing (available in root package.json).
 * 
 * Usage:
 *   node analyze-page.cjs --url="https://example.com" --html=page.html --output=analysis.json [--keyword="target keyword"]
 */

const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// --- Argument parsing ---
const args = {};
process.argv.slice(2).forEach(arg => {
  const [key, ...rest] = arg.replace(/^--/, '').split('=');
  args[key] = rest.join('=');
});

if (!args.html) {
  console.error('Usage: node analyze-page.cjs --url="URL" --html=page.html --output=analysis.json [--keyword="keyword"]');
  process.exit(1);
}

const htmlPath = path.resolve(args.html);
const outputPath = path.resolve(args.output || 'analysis.json');
const targetUrl = args.url || '';
const targetKeyword = (args.keyword || '').toLowerCase().trim();

// --- Flesch-Kincaid readability calculation ---
function countSyllables(word) {
  word = word.toLowerCase().replace(/[^a-z]/g, '');
  if (word.length <= 3) return 1;
  word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
  word = word.replace(/^y/, '');
  const matches = word.match(/[aeiouy]{1,2}/g);
  return matches ? matches.length : 1;
}

function fleschKincaidScore(text) {
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = text.split(/\s+/).filter(w => w.match(/[a-z]/i));
  if (words.length === 0 || sentences.length === 0) return 0;
  
  const totalSyllables = words.reduce((sum, w) => sum + countSyllables(w), 0);
  const avgWordsPerSentence = words.length / sentences.length;
  const avgSyllablesPerWord = totalSyllables / words.length;
  
  // Flesch Reading Ease
  return 206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord);
}

// --- Extract visible text from HTML ---
function extractText($) {
  // Remove script, style, nav, footer, header elements for content analysis
  const $content = $.root().clone();
  $content.find('script, style, noscript, nav, footer, header, aside').remove();
  return $content.text().replace(/\s+/g, ' ').trim();
}

// --- Extract body text only (for content scoring) ---
function extractBodyText($) {
  const $body = $('main, article, [role="main"], .content, .post-content, .entry-content, #content, body').first();
  if ($body.length === 0) return extractText($);
  const $clone = $body.clone();
  $clone.find('script, style, noscript, nav, footer, aside').remove();
  return $clone.text().replace(/\s+/g, ' ').trim();
}

// --- Score: Title Tag (10 points) ---
function scoreTitle($) {
  const title = $('title').text().trim();
  const findings = [];
  let score = 0;
  
  if (!title) {
    findings.push({ issue: 'Missing title tag', severity: 'critical' });
    return { score: 0, max: 10, title: '', findings };
  }
  
  findings.push({ info: `Title: "${title}"`, severity: 'info' });
  
  // Length scoring
  const len = title.length;
  if (len >= 50 && len <= 60) {
    score += 3;
    findings.push({ info: `Title length ${len} chars (ideal range 50-60)`, severity: 'pass' });
  } else if (len >= 30 && len <= 70) {
    score += 2;
    findings.push({ issue: `Title length ${len} chars (acceptable, ideal is 50-60)`, severity: 'minor' });
  } else if (len < 30) {
    score += 1;
    findings.push({ issue: `Title too short at ${len} chars (aim for 50-60)`, severity: 'warning' });
  } else {
    score += 1;
    findings.push({ issue: `Title too long at ${len} chars (may be truncated in SERPs, aim for 50-60)`, severity: 'warning' });
  }
  
  // Keyword inclusion
  if (targetKeyword) {
    if (title.toLowerCase().includes(targetKeyword)) {
      score += 3;
      const pos = title.toLowerCase().indexOf(targetKeyword);
      if (pos < title.length / 3) {
        score += 1;
        findings.push({ info: `Target keyword front-loaded in title`, severity: 'pass' });
      } else {
        findings.push({ info: `Target keyword present but not front-loaded`, severity: 'minor' });
      }
    } else {
      findings.push({ issue: `Target keyword "${targetKeyword}" not in title`, severity: 'warning' });
    }
  } else {
    score += 3; // No keyword to check, give benefit
  }
  
  // Click-worthiness (not generic)
  const genericTitles = ['home', 'welcome', 'untitled', 'page', 'document'];
  if (genericTitles.some(g => title.toLowerCase() === g || title.toLowerCase().startsWith(g + ' '))) {
    findings.push({ issue: `Generic/non-descriptive title`, severity: 'warning' });
  } else {
    score += 3;
    findings.push({ info: `Title appears descriptive and unique`, severity: 'pass' });
  }
  
  return { score: Math.min(10, score), max: 10, title, findings };
}

// --- Score: Meta Description (10 points) ---
function scoreMetaDescription($) {
  const metaDesc = $('meta[name="description"]').attr('content') || '';
  const findings = [];
  let score = 0;
  
  if (!metaDesc) {
    findings.push({ issue: 'Missing meta description', severity: 'critical' });
    return { score: 0, max: 10, metaDescription: '', findings };
  }
  
  findings.push({ info: `Meta description: "${metaDesc.substring(0, 100)}${metaDesc.length > 100 ? '...' : ''}"`, severity: 'info' });
  
  // Length
  const len = metaDesc.length;
  if (len >= 120 && len <= 160) {
    score += 3;
    findings.push({ info: `Meta description length ${len} chars (ideal range 120-160)`, severity: 'pass' });
  } else if (len >= 70 && len <= 200) {
    score += 2;
    findings.push({ issue: `Meta description length ${len} chars (acceptable, ideal is 120-160)`, severity: 'minor' });
  } else {
    score += 1;
    findings.push({ issue: `Meta description length ${len} chars (outside optimal range)`, severity: 'warning' });
  }
  
  // CTA/value proposition check
  const ctaPatterns = /\b(learn|discover|find|get|start|try|buy|shop|book|call|contact|free|save|explore|read|see|view|download|sign up|subscribe)\b/i;
  if (ctaPatterns.test(metaDesc)) {
    score += 3;
    findings.push({ info: `Contains call-to-action or value proposition`, severity: 'pass' });
  } else {
    score += 1;
    findings.push({ issue: `No clear call-to-action detected`, severity: 'minor' });
  }
  
  // Keyword presence
  if (targetKeyword) {
    if (metaDesc.toLowerCase().includes(targetKeyword)) {
      score += 3;
      findings.push({ info: `Target keyword present in meta description`, severity: 'pass' });
    } else {
      score += 1;
      findings.push({ issue: `Target keyword "${targetKeyword}" not in meta description`, severity: 'minor' });
    }
  } else {
    score += 3;
  }
  
  // Not duplicate of title
  const title = $('title').text().trim();
  if (metaDesc.trim() === title.trim()) {
    findings.push({ issue: `Meta description is identical to title tag`, severity: 'warning' });
  } else {
    score += 1;
  }
  
  return { score: Math.min(10, score), max: 10, metaDescription: metaDesc, findings };
}

// --- Score: Heading Hierarchy (10 points) ---
function scoreHeadings($) {
  const findings = [];
  let score = 0;
  
  const h1s = $('h1');
  const h2s = $('h2');
  const h3s = $('h3');
  const h4s = $('h4');
  
  const headingList = [];
  $('h1, h2, h3, h4, h5, h6').each((i, el) => {
    headingList.push({
      level: parseInt(el.tagName.charAt(1)),
      text: $(el).text().trim().substring(0, 100)
    });
  });
  
  // Single H1
  if (h1s.length === 1) {
    score += 3;
    findings.push({ info: `Single H1 present: "${h1s.first().text().trim().substring(0, 80)}"`, severity: 'pass' });
  } else if (h1s.length === 0) {
    findings.push({ issue: `No H1 tag found`, severity: 'critical' });
  } else {
    score += 1;
    findings.push({ issue: `Multiple H1 tags (${h1s.length}) - should be exactly 1`, severity: 'warning' });
  }
  
  // H1 contains keyword
  if (targetKeyword && h1s.length > 0) {
    if (h1s.first().text().toLowerCase().includes(targetKeyword)) {
      score += 2;
      findings.push({ info: `H1 contains target keyword`, severity: 'pass' });
    } else {
      findings.push({ issue: `H1 does not contain target keyword "${targetKeyword}"`, severity: 'minor' });
    }
  } else if (h1s.length > 0) {
    score += 2;
  }
  
  // Logical nesting (no skipped levels)
  let hasSkippedLevel = false;
  for (let i = 1; i < headingList.length; i++) {
    if (headingList[i].level > headingList[i - 1].level + 1) {
      hasSkippedLevel = true;
      break;
    }
  }
  
  if (!hasSkippedLevel && headingList.length > 1) {
    score += 2;
    findings.push({ info: `Heading hierarchy is properly nested`, severity: 'pass' });
  } else if (hasSkippedLevel) {
    score += 1;
    findings.push({ issue: `Heading levels are skipped (e.g., H2 to H4 without H3)`, severity: 'minor' });
  }
  
  // Descriptive headings (not "Section 1", etc.)
  const genericHeadingPattern = /^(section|part|chapter)\s+\d/i;
  const genericCount = headingList.filter(h => genericHeadingPattern.test(h.text)).length;
  if (genericCount === 0 && headingList.length > 2) {
    score += 2;
    findings.push({ info: `All headings are descriptive`, severity: 'pass' });
  } else if (genericCount > 0) {
    score += 1;
    findings.push({ issue: `${genericCount} generic headings found (e.g., "Section 1")`, severity: 'minor' });
  } else {
    score += 1;
  }
  
  // Keyword distribution in H2s
  if (targetKeyword && h2s.length > 0) {
    let kwInH2 = 0;
    h2s.each((i, el) => {
      if ($(el).text().toLowerCase().includes(targetKeyword)) kwInH2++;
    });
    if (kwInH2 > 0 && kwInH2 <= Math.ceil(h2s.length / 3)) {
      score += 1;
      findings.push({ info: `Target keyword appears in ${kwInH2} of ${h2s.length} H2s (natural distribution)`, severity: 'pass' });
    } else if (kwInH2 > Math.ceil(h2s.length / 3)) {
      findings.push({ issue: `Target keyword in ${kwInH2} of ${h2s.length} H2s (may appear over-optimized)`, severity: 'minor' });
    }
  }
  
  findings.push({ info: `Heading counts: H1:${h1s.length}, H2:${h2s.length}, H3:${h3s.length}, H4:${h4s.length}`, severity: 'info' });
  
  return { score: Math.min(10, score), max: 10, headings: headingList, findings };
}

// --- Score: Content Quality (15 points) ---
function scoreContent($) {
  const findings = [];
  let score = 0;
  
  const bodyText = extractBodyText($);
  const words = bodyText.split(/\s+/).filter(w => w.match(/[a-z]/i));
  const wordCount = words.length;
  
  findings.push({ info: `Word count: ${wordCount}`, severity: 'info' });
  
  // Word count scoring
  if (wordCount >= 1500) {
    score += 4;
    findings.push({ info: `Strong word count for in-depth content`, severity: 'pass' });
  } else if (wordCount >= 800) {
    score += 3;
    findings.push({ info: `Adequate word count`, severity: 'pass' });
  } else if (wordCount >= 300) {
    score += 2;
    findings.push({ issue: `Content is thin at ${wordCount} words (aim for 800+ for most page types)`, severity: 'minor' });
  } else {
    score += 1;
    findings.push({ issue: `Very thin content at ${wordCount} words`, severity: 'warning' });
  }
  
  // Reading level
  const readingScore = fleschKincaidScore(bodyText);
  findings.push({ info: `Flesch Reading Ease: ${readingScore.toFixed(1)}`, severity: 'info' });
  
  if (readingScore >= 50 && readingScore <= 80) {
    score += 3;
    findings.push({ info: `Reading level is appropriate for web content`, severity: 'pass' });
  } else if (readingScore >= 30 && readingScore < 50) {
    score += 2;
    findings.push({ issue: `Content is quite complex (reading score ${readingScore.toFixed(0)}), consider simplifying`, severity: 'minor' });
  } else if (readingScore > 80) {
    score += 2;
    findings.push({ issue: `Content may be too simple (reading score ${readingScore.toFixed(0)})`, severity: 'minor' });
  } else {
    score += 1;
    findings.push({ issue: `Content is very complex (reading score ${readingScore.toFixed(0)})`, severity: 'warning' });
  }
  
  // Paragraph length
  const paragraphs = $('p').map((i, el) => $(el).text().trim()).get().filter(p => p.length > 20);
  const avgParagraphWords = paragraphs.length > 0
    ? paragraphs.reduce((sum, p) => sum + p.split(/\s+/).length, 0) / paragraphs.length
    : 0;
  
  if (avgParagraphWords > 0 && avgParagraphWords <= 80) {
    score += 3;
    findings.push({ info: `Average paragraph length: ${Math.round(avgParagraphWords)} words (good for readability)`, severity: 'pass' });
  } else if (avgParagraphWords > 80 && avgParagraphWords <= 150) {
    score += 2;
    findings.push({ issue: `Average paragraph ${Math.round(avgParagraphWords)} words (consider breaking up long paragraphs)`, severity: 'minor' });
  } else if (avgParagraphWords > 150) {
    score += 1;
    findings.push({ issue: `Very long paragraphs (${Math.round(avgParagraphWords)} words avg) hurt readability`, severity: 'warning' });
  }
  
  // Lists and structured content (topical depth signal)
  const lists = $('ul, ol');
  const tables = $('table');
  if (lists.length > 0 || tables.length > 0) {
    score += 2;
    findings.push({ info: `Uses structured content (${lists.length} lists, ${tables.length} tables)`, severity: 'pass' });
  } else if (wordCount > 500) {
    score += 1;
    findings.push({ issue: `No lists or tables found. Structured content aids readability.`, severity: 'minor' });
  }
  
  // Data/statistics presence (originality signal)
  const hasStats = /\b\d+(\.\d+)?%|\b\d{1,3}(,\d{3})+|\$\d+|\d+x\b/i.test(bodyText);
  if (hasStats) {
    score += 3;
    findings.push({ info: `Contains specific data/statistics (originality signal)`, severity: 'pass' });
  } else {
    score += 1;
    findings.push({ issue: `No specific statistics or data points detected`, severity: 'minor' });
  }
  
  return { score: Math.min(15, score), max: 15, wordCount, readingScore: readingScore.toFixed(1), findings };
}

// --- Score: Internal Links (10 points) ---
function scoreInternalLinks($) {
  const findings = [];
  let score = 0;
  
  let urlDomain = '';
  try {
    if (targetUrl) urlDomain = new URL(targetUrl).hostname;
  } catch(e) {}
  
  const internalLinks = [];
  const externalLinks = [];
  
  $('a[href]').each((i, el) => {
    const href = $(el).attr('href') || '';
    const text = $(el).text().trim();
    
    if (href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) {
      return;
    }
    
    try {
      const linkUrl = href.startsWith('/') || href.startsWith('./') || (!href.startsWith('http'))
        ? 'internal'
        : (urlDomain && new URL(href).hostname === urlDomain) ? 'internal' : 'external';
      
      if (linkUrl === 'internal') {
        internalLinks.push({ href, text });
      } else {
        externalLinks.push({ href, text });
      }
    } catch(e) {
      internalLinks.push({ href, text }); // Assume internal if can't parse
    }
  });
  
  findings.push({ info: `Internal links: ${internalLinks.length}, External links: ${externalLinks.length}`, severity: 'info' });
  
  // Link count
  if (internalLinks.length >= 5) {
    score += 4;
    findings.push({ info: `Good number of internal links (${internalLinks.length})`, severity: 'pass' });
  } else if (internalLinks.length >= 3) {
    score += 3;
    findings.push({ info: `Adequate internal linking (${internalLinks.length})`, severity: 'pass' });
  } else if (internalLinks.length >= 1) {
    score += 2;
    findings.push({ issue: `Only ${internalLinks.length} internal link(s). Aim for 3+.`, severity: 'minor' });
  } else {
    findings.push({ issue: `No internal links found. This is an orphan page risk.`, severity: 'warning' });
  }
  
  // Anchor text quality
  const genericAnchors = ['click here', 'read more', 'learn more', 'here', 'this', 'link', 'more'];
  const genericCount = internalLinks.filter(l => genericAnchors.includes(l.text.toLowerCase())).length;
  
  if (internalLinks.length > 0 && genericCount === 0) {
    score += 3;
    findings.push({ info: `All anchor text is descriptive (not generic)`, severity: 'pass' });
  } else if (genericCount > 0 && genericCount < internalLinks.length / 2) {
    score += 2;
    findings.push({ issue: `${genericCount} links use generic anchor text ("click here", "read more")`, severity: 'minor' });
  } else if (genericCount >= internalLinks.length / 2 && internalLinks.length > 0) {
    score += 1;
    findings.push({ issue: `Most anchor text is generic. Use descriptive anchors.`, severity: 'warning' });
  }
  
  // External links (having some is good for authority)
  if (externalLinks.length >= 1 && externalLinks.length <= 10) {
    score += 3;
    findings.push({ info: `External links present (${externalLinks.length}) - good for credibility`, severity: 'pass' });
  } else if (externalLinks.length === 0) {
    score += 1;
    findings.push({ issue: `No external links. Linking to authoritative sources builds trust.`, severity: 'minor' });
  } else {
    score += 2;
  }
  
  return { score: Math.min(10, score), max: 10, internalLinks: internalLinks.length, externalLinks: externalLinks.length, findings };
}

// --- Score: Image Optimization (10 points) ---
function scoreImages($) {
  const findings = [];
  let score = 0;
  
  const images = $('img');
  const totalImages = images.length;
  
  if (totalImages === 0) {
    score += 5; // Not necessarily bad, depends on page type
    findings.push({ info: `No images found on page`, severity: 'info' });
    return { score, max: 10, totalImages: 0, findings };
  }
  
  findings.push({ info: `Total images: ${totalImages}`, severity: 'info' });
  
  // Alt text presence
  let missingAlt = 0;
  let poorAlt = 0;
  let goodAlt = 0;
  
  images.each((i, el) => {
    const alt = $(el).attr('alt');
    const src = $(el).attr('src') || '';
    
    if (alt === undefined || alt === null) {
      missingAlt++;
    } else if (alt.trim() === '' || /^(image|img|photo|picture)\d*$/i.test(alt.trim()) || /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(alt.trim())) {
      poorAlt++;
    } else {
      goodAlt++;
    }
  });
  
  const altCoverage = (goodAlt + (totalImages - missingAlt - poorAlt)) / totalImages;
  
  if (missingAlt === 0 && poorAlt === 0) {
    score += 4;
    findings.push({ info: `All ${totalImages} images have descriptive alt text`, severity: 'pass' });
  } else if (missingAlt === 0) {
    score += 3;
    findings.push({ issue: `${poorAlt} images have poor alt text (e.g., "image1.jpg")`, severity: 'minor' });
  } else {
    score += 1;
    findings.push({ issue: `${missingAlt} images missing alt text, ${poorAlt} have poor alt text`, severity: 'warning' });
  }
  
  // Next-gen formats
  let modernFormats = 0;
  let legacyFormats = 0;
  
  images.each((i, el) => {
    const src = $(el).attr('src') || '';
    if (/\.(webp|avif)($|\?)/i.test(src)) {
      modernFormats++;
    } else if (/\.(jpg|jpeg|png|gif|bmp)($|\?)/i.test(src)) {
      legacyFormats++;
    }
  });
  
  if (modernFormats > 0 && legacyFormats === 0) {
    score += 3;
    findings.push({ info: `All images use modern formats (WebP/AVIF)`, severity: 'pass' });
  } else if (modernFormats > 0) {
    score += 2;
    findings.push({ issue: `${legacyFormats} images use legacy formats (JPG/PNG). Consider WebP/AVIF.`, severity: 'minor' });
  } else if (legacyFormats > 0) {
    score += 1;
    findings.push({ issue: `No modern image formats. Convert to WebP for 25-35% smaller files.`, severity: 'warning' });
  }
  
  // Lazy loading
  let lazyLoaded = 0;
  images.each((i, el) => {
    if ($(el).attr('loading') === 'lazy' || $(el).attr('data-lazy') || $(el).attr('data-src')) {
      lazyLoaded++;
    }
  });
  
  if (totalImages <= 2 || lazyLoaded > 0) {
    score += 3;
    findings.push({ info: `${lazyLoaded} of ${totalImages} images use lazy loading`, severity: lazyLoaded > 0 ? 'pass' : 'info' });
  } else {
    score += 1;
    findings.push({ issue: `No lazy loading detected on ${totalImages} images`, severity: 'minor' });
  }
  
  return { score: Math.min(10, score), max: 10, totalImages, missingAlt, poorAlt, modernFormats, lazyLoaded, findings };
}

// --- Score: Schema Markup (10 points) ---
function scoreSchema($) {
  const findings = [];
  let score = 0;
  
  // Find JSON-LD schema
  const jsonLdScripts = [];
  $('script[type="application/ld+json"]').each((i, el) => {
    try {
      const data = JSON.parse($(el).html());
      jsonLdScripts.push(data);
    } catch(e) {
      findings.push({ issue: `Invalid JSON-LD schema block #${i + 1}`, severity: 'warning' });
    }
  });
  
  // Check for microdata
  const hasMicrodata = $('[itemscope]').length > 0;
  
  // Check for RDFa
  const hasRDFa = $('[typeof]').length > 0;
  
  if (jsonLdScripts.length === 0 && !hasMicrodata && !hasRDFa) {
    findings.push({ issue: `No structured data (schema markup) found`, severity: 'critical' });
    return { score: 0, max: 10, schemas: [], findings };
  }
  
  // Prefer JSON-LD
  if (jsonLdScripts.length > 0) {
    score += 3;
    findings.push({ info: `JSON-LD schema found (${jsonLdScripts.length} block(s)) - preferred format`, severity: 'pass' });
  } else if (hasMicrodata) {
    score += 2;
    findings.push({ info: `Microdata schema found (JSON-LD preferred)`, severity: 'minor' });
  } else {
    score += 1;
    findings.push({ info: `RDFa schema found (JSON-LD preferred)`, severity: 'minor' });
  }
  
  // Check schema types
  const schemaTypes = [];
  for (const schema of jsonLdScripts) {
    const type = schema['@type'] || (Array.isArray(schema['@graph']) ? schema['@graph'].map(g => g['@type']).join(', ') : 'Unknown');
    schemaTypes.push(type);
  }
  
  if (schemaTypes.length > 0) {
    findings.push({ info: `Schema types: ${schemaTypes.join(', ')}`, severity: 'info' });
    
    // Check for common useful types
    const allTypes = schemaTypes.join(',').toLowerCase();
    
    if (allTypes.includes('article') || allTypes.includes('product') || allTypes.includes('faq') ||
        allTypes.includes('howto') || allTypes.includes('localbusiness') || allTypes.includes('organization') ||
        allTypes.includes('service')) {
      score += 3;
      findings.push({ info: `Appropriate schema type for content`, severity: 'pass' });
    } else if (allTypes.includes('webpage') || allTypes.includes('website')) {
      score += 2;
      findings.push({ issue: `Only basic WebPage/WebSite schema. Consider adding specific type (Article, Product, FAQ, etc.)`, severity: 'minor' });
    }
  }
  
  // Check for breadcrumb schema
  const hasBreadcrumb = jsonLdScripts.some(s => {
    const type = s['@type'] || '';
    const graph = s['@graph'] || [];
    return type === 'BreadcrumbList' || graph.some(g => g['@type'] === 'BreadcrumbList');
  });
  
  if (hasBreadcrumb) {
    score += 2;
    findings.push({ info: `Breadcrumb schema present`, severity: 'pass' });
  } else {
    score += 1;
    findings.push({ issue: `No breadcrumb schema found`, severity: 'minor' });
  }
  
  // Check for FAQ schema
  const hasFAQ = jsonLdScripts.some(s => {
    const type = s['@type'] || '';
    const graph = s['@graph'] || [];
    return type === 'FAQPage' || graph.some(g => g['@type'] === 'FAQPage');
  });
  
  if (hasFAQ) {
    score += 2;
    findings.push({ info: `FAQ schema present (good for featured snippets)`, severity: 'pass' });
  }
  
  return { score: Math.min(10, score), max: 10, schemas: schemaTypes, findings };
}

// --- Score: Page Speed Signals (5 points) ---
function scoreSpeed($, htmlSize) {
  const findings = [];
  let score = 0;
  
  // HTML size
  const sizeKB = Math.round(htmlSize / 1024);
  findings.push({ info: `HTML document size: ${sizeKB}KB`, severity: 'info' });
  
  if (sizeKB <= 50) {
    score += 2;
    findings.push({ info: `HTML size is lean (${sizeKB}KB)`, severity: 'pass' });
  } else if (sizeKB <= 100) {
    score += 1;
    findings.push({ issue: `HTML is ${sizeKB}KB (acceptable, under 100KB)`, severity: 'minor' });
  } else {
    findings.push({ issue: `HTML is ${sizeKB}KB (heavy, consider reducing inline CSS/JS)`, severity: 'warning' });
  }
  
  // Render-blocking resources
  const renderBlocking = $('link[rel="stylesheet"]:not([media="print"]):not([data-async])').length +
    $('script:not([async]):not([defer]):not([type="application/ld+json"])').filter((i, el) => {
      return $(el).attr('src') && !$(el).attr('async') && !$(el).attr('defer');
    }).length;
  
  if (renderBlocking <= 3) {
    score += 1;
    findings.push({ info: `${renderBlocking} potential render-blocking resources`, severity: 'pass' });
  } else {
    findings.push({ issue: `${renderBlocking} render-blocking resources (add async/defer to scripts, media queries to CSS)`, severity: 'minor' });
  }
  
  // Resource hints
  const preconnects = $('link[rel="preconnect"]').length;
  const preloads = $('link[rel="preload"]').length;
  const prefetches = $('link[rel="prefetch"], link[rel="dns-prefetch"]').length;
  
  if (preconnects > 0 || preloads > 0) {
    score += 2;
    findings.push({ info: `Resource hints present: ${preconnects} preconnect, ${preloads} preload, ${prefetches} prefetch`, severity: 'pass' });
  } else {
    score += 1;
    findings.push({ issue: `No resource hints (preconnect, preload). These speed up third-party resources.`, severity: 'minor' });
  }
  
  return { score: Math.min(5, score), max: 5, htmlSizeKB: sizeKB, renderBlocking, findings };
}

// --- Score: Mobile Experience (5 points) ---
function scoreMobile($) {
  const findings = [];
  let score = 0;
  
  // Viewport meta tag
  const viewport = $('meta[name="viewport"]').attr('content') || '';
  if (viewport && viewport.includes('width=device-width')) {
    score += 2;
    findings.push({ info: `Viewport meta tag correctly set`, severity: 'pass' });
  } else if (viewport) {
    score += 1;
    findings.push({ issue: `Viewport meta present but may not include width=device-width`, severity: 'minor' });
  } else {
    findings.push({ issue: `No viewport meta tag found. Page will not render correctly on mobile.`, severity: 'critical' });
  }
  
  // Check for fixed-width elements (horizontal scroll risk)
  const fixedWidthElements = $('[style*="width:"]').filter((i, el) => {
    const style = $(el).attr('style') || '';
    const match = style.match(/width:\s*(\d+)px/);
    return match && parseInt(match[1]) > 500;
  }).length;
  
  if (fixedWidthElements === 0) {
    score += 1;
    findings.push({ info: `No fixed-width elements >500px detected`, severity: 'pass' });
  } else {
    findings.push({ issue: `${fixedWidthElements} elements with fixed width >500px (horizontal scroll risk on mobile)`, severity: 'warning' });
  }
  
  // Font size check (look for body/main font-size)
  const smallFontElements = $('[style*="font-size"]').filter((i, el) => {
    const style = $(el).attr('style') || '';
    const match = style.match(/font-size:\s*(\d+)px/);
    return match && parseInt(match[1]) < 14;
  }).length;
  
  if (smallFontElements === 0) {
    score += 1;
    findings.push({ info: `No inline small font sizes (<14px) detected`, severity: 'pass' });
  } else {
    findings.push({ issue: `${smallFontElements} elements with small inline font-size (<14px)`, severity: 'minor' });
  }
  
  // Touch target check (buttons/links with explicit small sizes)
  score += 1; // Give benefit - proper check requires rendered DOM
  findings.push({ info: `Touch target sizing requires rendered DOM check (not possible from HTML alone)`, severity: 'info' });
  
  return { score: Math.min(5, score), max: 5, findings };
}

// --- Score: AI-Readiness (15 points) ---
function scoreAIReadiness($) {
  const findings = [];
  let score = 0;
  
  const bodyText = extractBodyText($);
  const words = bodyText.split(/\s+/).filter(w => w.match(/[a-z]/i));
  
  // First 200 words - do they directly answer a query?
  const first200 = words.slice(0, 200).join(' ');
  
  // Check if first 200 words contain definition/answer patterns
  const answerPatterns = /\b(is a|is an|refers to|is defined as|means that|involves|is the process of|are used to|helps you|allows you to|provides|enables)\b/i;
  const hasDirectAnswer = answerPatterns.test(first200);
  
  if (hasDirectAnswer) {
    score += 4;
    findings.push({ info: `First 200 words contain direct answer/definition patterns (AI-friendly)`, severity: 'pass' });
  } else {
    score += 1;
    findings.push({ issue: `First 200 words lack clear answer/definition. AI systems prefer content that answers queries immediately.`, severity: 'warning' });
  }
  
  // Entity clarity - author/brand/organization identified
  const hasAuthor = $('meta[name="author"]').length > 0 || $('[rel="author"]').length > 0 ||
    $('[class*="author"]').length > 0 || $('[itemprop="author"]').length > 0;
  const hasOrgSchema = $('script[type="application/ld+json"]').text().includes('"Organization"') ||
    $('script[type="application/ld+json"]').text().includes('"Person"');
  
  if (hasAuthor && hasOrgSchema) {
    score += 3;
    findings.push({ info: `Author and organization entities clearly identified`, severity: 'pass' });
  } else if (hasAuthor || hasOrgSchema) {
    score += 2;
    findings.push({ issue: `Partial entity identification (${hasAuthor ? 'author' : 'organization'} found, ${!hasAuthor ? 'author' : 'organization'} missing)`, severity: 'minor' });
  } else {
    score += 1;
    findings.push({ issue: `No clear author or organization entity. AI systems need to attribute information.`, severity: 'warning' });
  }
  
  // Citation-worthy content - statistics, data, unique definitions
  const statsPattern = /\b\d+(\.\d+)?%|\b\d{1,3}(,\d{3})+\b|\$[\d,.]+|\d+x\s+(more|less|higher|lower|faster|slower)\b/gi;
  const statsMatches = bodyText.match(statsPattern) || [];
  
  if (statsMatches.length >= 3) {
    score += 4;
    findings.push({ info: `${statsMatches.length} citation-worthy statistics/data points found`, severity: 'pass' });
  } else if (statsMatches.length >= 1) {
    score += 2;
    findings.push({ issue: `Only ${statsMatches.length} statistic(s) found. Add more specific data for AI citation.`, severity: 'minor' });
  } else {
    findings.push({ issue: `No statistics or specific data points. Content is unlikely to be cited by AI systems.`, severity: 'warning' });
  }
  
  // Structured answers - FAQ patterns, clear Q&A
  const hasFAQSchema = $('script[type="application/ld+json"]').text().includes('FAQPage');
  const hasQAPattern = $('h2, h3').filter((i, el) => /\?$/.test($(el).text().trim())).length;
  const hasDefList = $('dl, dt, dd').length > 0;
  
  if (hasFAQSchema) {
    score += 3;
    findings.push({ info: `FAQ schema present for structured answers`, severity: 'pass' });
  } else if (hasQAPattern >= 2) {
    score += 2;
    findings.push({ info: `${hasQAPattern} question-headings found (Q&A format aids AI parsing)`, severity: 'pass' });
  } else if (hasDefList) {
    score += 2;
    findings.push({ info: `Definition list markup found (structured content)`, severity: 'pass' });
  } else {
    score += 1;
    findings.push({ issue: `No FAQ schema, question headings, or definition markup. Structure content as Q&A for AI.`, severity: 'minor' });
  }
  
  // Publication date (freshness signal)
  const hasDate = $('time[datetime]').length > 0 || $('meta[property="article:published_time"]').length > 0 ||
    $('meta[name="date"]').length > 0 || $('[class*="date"][class*="publish"]').length > 0;
  
  if (hasDate) {
    score += 1;
    findings.push({ info: `Publication date detected (freshness signal for AI)`, severity: 'pass' });
  } else {
    findings.push({ issue: `No publication date found. AI systems use recency as a ranking signal.`, severity: 'minor' });
  }
  
  return { score: Math.min(15, score), max: 15, findings };
}

// --- Score: Technical SEO Signals (bonus/informational) ---
function scoreTechnical($) {
  const findings = [];
  
  // Canonical
  const canonical = $('link[rel="canonical"]').attr('href') || '';
  if (canonical) {
    findings.push({ info: `Canonical: ${canonical}`, severity: 'pass' });
  } else {
    findings.push({ issue: `No canonical tag found`, severity: 'warning' });
  }
  
  // Open Graph
  const ogTitle = $('meta[property="og:title"]').attr('content') || '';
  const ogDesc = $('meta[property="og:description"]').attr('content') || '';
  const ogImage = $('meta[property="og:image"]').attr('content') || '';
  
  if (ogTitle && ogImage) {
    findings.push({ info: `Open Graph tags present (title + image)`, severity: 'pass' });
  } else if (ogTitle) {
    findings.push({ issue: `Open Graph title present but no og:image`, severity: 'minor' });
  } else {
    findings.push({ issue: `No Open Graph tags found`, severity: 'warning' });
  }
  
  // Twitter Card
  const twitterCard = $('meta[name="twitter:card"]').attr('content') || '';
  if (twitterCard) {
    findings.push({ info: `Twitter Card: ${twitterCard}`, severity: 'pass' });
  }
  
  // Robots
  const robotsMeta = $('meta[name="robots"]').attr('content') || '';
  if (robotsMeta) {
    findings.push({ info: `Robots meta: ${robotsMeta}`, severity: robotsMeta.includes('noindex') ? 'warning' : 'info' });
  }
  
  // Language
  const lang = $('html').attr('lang') || '';
  if (lang) {
    findings.push({ info: `Language declared: ${lang}`, severity: 'pass' });
  } else {
    findings.push({ issue: `No language attribute on <html> tag`, severity: 'minor' });
  }
  
  // Hreflang
  const hreflangs = $('link[rel="alternate"][hreflang]').length;
  if (hreflangs > 0) {
    findings.push({ info: `${hreflangs} hreflang tag(s) found`, severity: 'info' });
  }
  
  return { score: 0, max: 0, findings }; // Informational only
}

// --- Main ---
function main() {
  if (!fs.existsSync(htmlPath)) {
    console.error(`HTML file not found: ${htmlPath}`);
    process.exit(1);
  }

  const html = fs.readFileSync(htmlPath, 'utf-8');
  const $ = cheerio.load(html);
  
  console.log(`Analyzing: ${targetUrl || htmlPath}`);
  if (targetKeyword) console.log(`Target keyword: "${targetKeyword}"`);
  
  // Run all scoring functions
  const results = {
    url: targetUrl,
    targetKeyword: targetKeyword || null,
    analyzedAt: new Date().toISOString(),
    categories: {
      titleTag: scoreTitle($),
      metaDescription: scoreMetaDescription($),
      headingHierarchy: scoreHeadings($),
      contentQuality: scoreContent($),
      internalLinks: scoreInternalLinks($),
      imageOptimization: scoreImages($),
      schemaMarkup: scoreSchema($),
      pageSpeed: scoreSpeed($, Buffer.byteLength(html, 'utf8')),
      mobileExperience: scoreMobile($),
      aiReadiness: scoreAIReadiness($),
      technicalSEO: scoreTechnical($)
    }
  };
  
  // Calculate total score
  let totalScore = 0;
  let totalMax = 0;
  
  for (const [key, cat] of Object.entries(results.categories)) {
    totalScore += cat.score;
    totalMax += cat.max;
  }
  
  // Grade
  const percentage = Math.round((totalScore / totalMax) * 100);
  let grade = 'F';
  if (percentage >= 85) grade = 'A';
  else if (percentage >= 70) grade = 'B';
  else if (percentage >= 55) grade = 'C';
  else if (percentage >= 40) grade = 'D';
  
  results.overall = {
    score: totalScore,
    maxScore: totalMax,
    percentage,
    grade
  };
  
  // Collect all recommendations sorted by severity
  const recommendations = [];
  for (const [catName, cat] of Object.entries(results.categories)) {
    for (const finding of cat.findings) {
      if (finding.issue) {
        recommendations.push({
          category: catName,
          issue: finding.issue,
          severity: finding.severity,
          impact: finding.severity === 'critical' ? 'high' : finding.severity === 'warning' ? 'high' : 'medium'
        });
      }
    }
  }
  
  // Sort: critical first, then warning, then minor
  const severityOrder = { critical: 0, warning: 1, minor: 2 };
  recommendations.sort((a, b) => (severityOrder[a.severity] || 3) - (severityOrder[b.severity] || 3));
  
  results.recommendations = recommendations;
  
  // Write output
  const outDir = path.dirname(outputPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }
  
  fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
  
  // Console summary
  console.log(`\n--- SEO Scorecard ---`);
  console.log(`Overall: ${grade} (${totalScore}/${totalMax} = ${percentage}%)`);
  console.log('');
  
  for (const [key, cat] of Object.entries(results.categories)) {
    if (cat.max > 0) {
      const bar = '='.repeat(Math.round((cat.score / cat.max) * 20));
      const empty = '-'.repeat(20 - bar.length);
      console.log(`  ${key.padEnd(22)} ${cat.score}/${cat.max}  [${bar}${empty}]`);
    }
  }
  
  console.log(`\nTop issues:`);
  recommendations.slice(0, 5).forEach(r => {
    console.log(`  [${r.severity.toUpperCase()}] ${r.category}: ${r.issue}`);
  });
  
  console.log(`\nFull analysis written to: ${outputPath}`);
}

main();
