# GEO Content Auditor - Scoring Rubric

Detailed scoring criteria for each of the 7 dimensions.

## 1. First-200-Words Answer Quality (Weight: 25%)

| Score | Criteria |
|-------|----------|
| 9-10 | Opening directly answers the query with specific data, numbers, or a clear definition. No filler. Concise. |
| 7-8 | Opening addresses the query within first 2 sentences. Some specifics present. |
| 5-6 | Query topic mentioned in first 200 words but answer is indirect or buried. |
| 3-4 | First 200 words are generic intro. Query addressed later in content. |
| 0-2 | Opening is completely unrelated filler ("Welcome to our blog..."). Query barely addressed. |

## 2. Entity Clarity (Weight: 15%)

| Score | Criteria |
|-------|----------|
| 9-10 | Brand/author named in first paragraph with credentials, experience metrics, and Organization schema. |
| 7-8 | Brand identified early with some credentials. Schema present. |
| 5-6 | Brand mentioned but no credentials. Or credentials exist but brand not mentioned early. |
| 3-4 | Vague organizational references. No specific author or brand entity. |
| 0-2 | Anonymous content. No identifiable author, brand, or organization. |

## 3. Structured Data Presence (Weight: 12%)

| Score | Criteria |
|-------|----------|
| 9-10 | Article + FAQ + BreadcrumbList schema present and valid. Additional schemas (HowTo, LocalBusiness). |
| 7-8 | Article schema + one of FAQ/HowTo present. |
| 5-6 | Basic Article or WebPage schema only. |
| 3-4 | Some schema present but incomplete or invalid. |
| 0-2 | No structured data markup at all. |

## 4. Citation-Worthiness (Weight: 20%)

| Score | Criteria |
|-------|----------|
| 9-10 | 5+ original statistics in standalone quotable sentences. Proprietary data. Clear definitions. |
| 7-8 | 3-4 data points, some standalone. Some original data or unique findings. |
| 5-6 | A few statistics but embedded in paragraphs. No original data. |
| 3-4 | One or two vague numbers. Mostly generic claims. |
| 0-2 | No statistics, no data, no quotable definitions. Pure opinion or filler. |

## 5. Content Freshness (Weight: 6%)

| Score | Criteria |
|-------|----------|
| 9-10 | Published/updated within 3 months. Current year referenced. "Last updated" date visible. |
| 7-8 | Updated within 6 months. Recent year references. |
| 5-6 | Updated within 12 months. Some temporal references. |
| 3-4 | Content over a year old. No update date visible. |
| 0-2 | No dates anywhere. Content appears undated and potentially stale. |

## 6. Topical Authority (Weight: 10%)

| Score | Criteria |
|-------|----------|
| 9-10 | 10+ internal links. 2000+ words. Deep heading structure (5+ H2s with H3s). Broad subtopic coverage. |
| 7-8 | 5-9 internal links. 1500+ words. Good heading structure. |
| 5-6 | 3-4 internal links. 1000+ words. Basic heading structure. |
| 3-4 | 1-2 internal links. Under 1000 words. Shallow coverage. |
| 0-2 | No internal links. Thin content. Minimal heading structure. |

## 7. Source Reliability (Weight: 12%)

| Score | Criteria |
|-------|----------|
| 9-10 | Detailed author bio. 3+ external references/citations. Publication date visible. Trust language present. Editorial review mentioned. |
| 7-8 | Author identified with bio. Some references. Publication date visible. |
| 5-6 | Author name present but no bio. One or two external links. |
| 3-4 | No author. No references. But publication date exists. |
| 0-2 | Anonymous, undated, unreferenced content. No trust signals. |
