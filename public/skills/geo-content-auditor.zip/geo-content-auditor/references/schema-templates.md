# JSON-LD Schema Templates for GEO

Ready-to-use schema markup templates. Replace bracketed placeholders with actual values.

## Article Schema

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "[ARTICLE TITLE]",
  "description": "[META DESCRIPTION]",
  "author": {
    "@type": "Person",
    "name": "[AUTHOR NAME]",
    "url": "[AUTHOR URL]",
    "jobTitle": "[JOB TITLE]",
    "worksFor": {
      "@type": "Organization",
      "name": "[ORG NAME]"
    }
  },
  "publisher": {
    "@type": "Organization",
    "name": "[ORG NAME]",
    "url": "[ORG URL]",
    "logo": {
      "@type": "ImageObject",
      "url": "[LOGO URL]"
    }
  },
  "datePublished": "[YYYY-MM-DD]",
  "dateModified": "[YYYY-MM-DD]",
  "mainEntityOfPage": "[PAGE URL]"
}
```

## FAQ Schema

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "[QUESTION 1]",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "[ANSWER 1]"
      }
    },
    {
      "@type": "Question",
      "name": "[QUESTION 2]",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "[ANSWER 2]"
      }
    }
  ]
}
```

## HowTo Schema

```json
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "[TITLE - How to ...]",
  "description": "[BRIEF DESCRIPTION]",
  "totalTime": "PT[X]M",
  "step": [
    {
      "@type": "HowToStep",
      "name": "[STEP 1 TITLE]",
      "text": "[STEP 1 DESCRIPTION]"
    },
    {
      "@type": "HowToStep",
      "name": "[STEP 2 TITLE]",
      "text": "[STEP 2 DESCRIPTION]"
    }
  ]
}
```

## LocalBusiness Schema

```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "[BUSINESS NAME]",
  "url": "[URL]",
  "telephone": "[PHONE]",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "[STREET]",
    "addressLocality": "[CITY]",
    "addressRegion": "[STATE]",
    "postalCode": "[ZIP]",
    "addressCountry": "[COUNTRY CODE]"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "[RATING]",
    "reviewCount": "[COUNT]"
  },
  "openingHours": "[Mo-Fr 09:00-17:00]"
}
```
