---
name: geo-content-auditor
description: "Audit any page's content for AI citation potential across ChatGPT, Perplexity, Google AI Overviews, and Claude. Scores 7 dimensions and outputs a report with rewrite recommendations."
version: 1.0
---

# GEO Content Auditor

Analyze any page's content through the lens of whether AI systems (ChatGPT, Perplexity, Google AI Overviews, Claude) would cite it as a source. Produces a scored HTML report with specific rewrite recommendations.

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

## When to Use

- User mentions GEO, AEO, AI optimization, or AI citation
- User asks "will AI cite this page?" or "how does this page rank in AI?"
- User provides a URL and asks about AI visibility or AI-readiness
- User says "geo audit", "ai audit", "content audit for AI"

## Input Requirements

Gather from the user:
1. **Target URL** - The page to audit
2. **Target query** - What search query should this page answer?
3. **Competitor URLs** (optional) - 1-3 competitor pages being cited for this query
4. **Prepared by name** - Name/brand for the report

## Process

### Step 1: Fetch Page Content

Use WebFetch to retrieve the target page. Extract: all headings, first 200 words, statistics, author info, dates, schema markup, FAQ sections, internal/external links, and meta tags.

Save extracted content as JSON for the audit script.

### Step 2: Run the Audit Script

Run the bundled scoring engine at `scripts/audit.cjs`:

```bash
node scripts/audit.cjs \
  --url "TARGET_URL" \
  --query "TARGET_QUERY" \
  --content content.json \
  --output scores.json
```

The script scores 7 dimensions (0-10 each):

| # | Dimension | Weight | What It Measures |
|---|-----------|--------|-----------------|
| 1 | First-200-Words Answer Quality | 25% | Does the opening directly answer the query? |
| 2 | Entity Clarity | 15% | Brand/author/org clearly identified? |
| 3 | Structured Data Presence | 12% | FAQ, HowTo, Article schema present? |
| 4 | Citation-Worthiness | 20% | Original statistics, unique data, quotable definitions? |
| 5 | Content Freshness | 6% | Publication date, update date, freshness signals? |
| 6 | Topical Authority | 10% | Internal links, depth of coverage? |
| 7 | Source Reliability | 12% | Author bios, references, trust markers? |

### Step 3: Competitor Comparison (if URLs provided)

Run the same scoring on each competitor page and include comparison in the report.

### Step 4: Generate HTML Report

Run the bundled report generator at `scripts/generate-report.cjs`:

```bash
node scripts/generate-report.cjs \
  --scores scores.json \
  --output geo-audit-report.html \
  --prepared-by "Name"
```

After generating, append two additional sections to the HTML before the closing tags:

1. **Schema Recommendations** - Read `references/schema-templates.md` and insert ready-to-paste JSON-LD code blocks relevant to the page type
2. **Before/After Rewrite** - Take the page's current first 200 words as "Before" and write an improved "After" version

### Step 5: Open Report

Open the HTML report in the browser.

## Grading Scale

| Grade | Score | Meaning |
|-------|-------|---------|
| A | 85-100 | AI-optimized, likely being cited |
| B | 70-84 | Good foundation, specific improvements needed |
| C | 55-69 | Significant gaps in AI-readiness |
| D | 40-54 | Major restructuring needed |
| F | 0-39 | Not AI-citation ready |

## Bundled Resources

| File | Purpose |
|------|---------|
| `scripts/audit.cjs` | Core scoring engine (7 dimensions) |
| `scripts/generate-report.cjs` | HTML report generator |
| `references/scoring-rubric.md` | Detailed scoring criteria per dimension |
| `references/schema-templates.md` | Ready-to-use JSON-LD schema templates |
