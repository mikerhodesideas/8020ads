---
name: geo-content-auditor
description: "Audit any page's content for AI citation potential across ChatGPT, Perplexity, Google AI Overviews, and Claude. Scores 7 dimensions (answer quality, entity clarity, structured data, citation-worthiness, freshness, topical authority, source reliability), compares against competitor pages being cited, and outputs a scored report with specific rewrite recommendations."
version: 1.0
last_updated: 2026-03-21
members: true
---

# GEO Content Auditor

Analyze any page's content through the lens of whether AI systems (ChatGPT, Perplexity, Google AI Overviews, Claude) would cite it as a source. Produces a scored HTML report with specific rewrite recommendations.

## Trigger

- User mentions GEO, AEO, AI optimization, or AI citation
- User asks "will AI cite this page?" or "how does this page rank in AI?"
- User provides a URL and asks about AI visibility or AI-readiness
- User says "geo audit", "ai audit", "content audit for AI"

## Step 0: Gather Required Information

Use AskUserQuestion to collect:

1. **Target URL** - The page to audit
2. **Target query** - What search query should this page answer? (e.g., "best pool cleaning service Melbourne")
3. **Competitor URLs** (optional) - 1-3 competitor pages that ARE being cited for this query. If not provided, the skill will attempt to identify them.
4. **Prepared by name** - What name/brand should appear on the report?

## Step 1: Fetch Page Content

Use WebFetch to retrieve the target page:

```
WebFetch URL with prompt: "Extract the complete page content including: all headings (H1-H6), the first 200 words of body content, all statistics and data points, author information, publication/update dates, schema markup (JSON-LD), FAQ sections, internal links, external references, meta tags, and overall content structure."
```

If competitor URLs were provided, fetch those too with the same prompt.

## Step 2: Run the Audit Script

```bash
node /Users/mikerhodes/Projects/brain/.claude/skills/geo-content-auditor/scripts/audit.cjs \
  --url "TARGET_URL" \
  --query "TARGET_QUERY" \
  --content /tmp/geo-audit/content.json \
  --output /tmp/geo-audit/scores.json
```

The script scores 7 dimensions (0-10 each):

| # | Dimension | What It Measures |
|---|-----------|-----------------|
| 1 | First-200-Words Answer Quality | Does the opening directly answer the target query? |
| 2 | Entity Clarity | Is the brand/author/organization clearly identified with credentials? |
| 3 | Structured Data Presence | FAQ schema, HowTo schema, article schema present and valid? |
| 4 | Citation-Worthiness | Original statistics, unique data, quotable definitions? |
| 5 | Content Freshness | Publication date, update date, freshness signals? |
| 6 | Topical Authority | Internal links to related content, depth of coverage? |
| 7 | Source Reliability | Author bios, references, publication date, trust markers? |

## Step 3: Competitor Comparison

If competitor URLs were provided or identified:
- Run the same 7-dimension scoring on each competitor page
- Identify where competitors outscore the target page
- Note specific elements competitors have that the target lacks

If no competitors available, skip this step and note it in the report.

## Step 4: Generate Rewrite Recommendations

For each dimension scoring below 7/10, generate specific recommendations:

- **First-200-Words**: Rewrite the opening paragraph to directly answer the query
- **Entity Clarity**: Add author name, credentials, organization, and expertise signals
- **Structured Data**: Provide exact JSON-LD schema to add (FAQ, HowTo, Article)
- **Citation-Worthiness**: Identify where to add original statistics, quotable definitions
- **Content Freshness**: Add last-updated date, freshness signals
- **Topical Authority**: Suggest internal links, content depth improvements
- **Source Reliability**: Add author bio, references, publication date

## Step 5: Generate HTML Report

```bash
node /Users/mikerhodes/Projects/brain/.claude/skills/geo-content-auditor/scripts/generate-report.cjs \
  --scores /tmp/geo-audit/scores.json \
  --output output/geo-audit-CLIENTNAME.html
```

The report includes:
1. **Cover page** with URL, query, date, prepared by
2. **Overall GEO Score** (weighted average of 7 dimensions, 0-100)
3. **Dimension Scorecard** - Visual bars for each of the 7 dimensions
4. **Competitor Comparison** (if available) - Side-by-side scores
5. **Detailed Analysis** - Per-dimension breakdown with evidence
6. **Priority Fixes** - Ranked by impact, with specific rewrite instructions
7. **Schema Recommendations** - Ready-to-paste JSON-LD markup
8. **Rewritten Sections** - Before/after examples for key paragraphs

Open in browser:
```bash
open output/geo-audit-CLIENTNAME.html
```

## Scoring Methodology

**Overall GEO Score** = Weighted average mapped to 0-100:

| Dimension | Weight | Rationale |
|-----------|--------|-----------|
| First-200-Words | 25% | AI systems heavily weight opening content |
| Citation-Worthiness | 20% | Original data is the #1 driver of AI citations |
| Entity Clarity | 15% | AI systems need to attribute sources clearly |
| Structured Data | 12% | Schema helps AI parse and extract information |
| Source Reliability | 12% | Trust markers affect whether AI cites a source |
| Topical Authority | 10% | Coverage depth signals expertise |
| Content Freshness | 6% | Recent content preferred but not dominant |

**Grade scale:**
- 85-100 (A): AI-optimized, likely being cited
- 70-84 (B): Good foundation, specific improvements needed
- 55-69 (C): Significant gaps in AI-readiness
- 40-54 (D): Major restructuring needed
- 0-39 (F): Not AI-citation ready

## Bundled Resources

| File | Purpose |
|------|---------|
| `scripts/audit.cjs` | Core scoring engine (7 dimensions) |
| `scripts/generate-report.cjs` | HTML report generator |
| `references/scoring-rubric.md` | Detailed scoring criteria per dimension |
| `references/schema-templates.md` | Ready-to-use JSON-LD schema templates |

## Dependencies

- **Playwright** - For fetching page content if WebFetch fails. Uses project root's node_modules.

## Output

- HTML report saved to `output/geo-audit-CLIENTNAME.html` and opened in browser
- JSON scores saved to `/tmp/geo-audit/scores.json` for programmatic use

## Related Skills

- `geo-content-optimizer` - Takes audit output and restructures content for AI citation
- `ai-brand-visibility-monitor` - Tracks brand mentions across AI systems over time
- `sellable-ai-site-audit` - Broader AI site audit (not GEO-specific)
