#!/usr/bin/env node

/**
 * GEO Content Auditor - HTML Report Generator
 *
 * Takes scored audit output and generates a professional HTML report.
 *
 * Usage:
 *   node generate-report.cjs --scores <scores.json> --output <report.html> [--prepared-by <name>]
 */

const fs = require('fs');
const path = require('path');

function parseArgs() {
  const args = process.argv.slice(2);
  const parsed = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--scores' && args[i + 1]) parsed.scoresPath = args[++i];
    else if (args[i] === '--output' && args[i + 1]) parsed.outputPath = args[++i];
    else if (args[i] === '--prepared-by' && args[i + 1]) parsed.preparedBy = args[++i];
    else if (args[i] === '--competitors' && args[i + 1]) parsed.competitorsPath = args[++i];
  }
  return parsed;
}

function getScoreColor(score, max) {
  const pct = score / max;
  if (pct >= 0.7) return '#22c55e';
  if (pct >= 0.5) return '#f59e0b';
  return '#ef4444';
}

function getGradeColor(grade) {
  const colors = { A: '#22c55e', B: '#3b82f6', C: '#f59e0b', D: '#f97316', F: '#ef4444' };
  return colors[grade] || '#6b7280';
}

function generateHTML(scores, preparedBy, competitors) {
  const date = new Date().toLocaleDateString('en-AU', { year: 'numeric', month: 'long', day: 'numeric' });

  const dimensionBars = scores.dimensions.map(d => {
    const pct = (d.score / 10) * 100;
    const color = getScoreColor(d.score, 10);
    const findingsHtml = d.findings.map(f => {
      const isIssue = f.startsWith('ISSUE') || f.startsWith('CRITICAL');
      return '<li style="color: ' + (isIssue ? '#ef4444' : '#374151') + '; margin-bottom: 4px;">' + f + '</li>';
    }).join('\n');

    return `
      <div style="margin-bottom: 24px; padding: 16px; background: #f9fafb; border-left: 3px solid ${color}; border-radius: 2px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <strong style="font-size: 14px;">${d.dimension}</strong>
          <span style="font-size: 18px; font-weight: 700; color: ${color};">${d.score}/10</span>
        </div>
        <div style="background: #e5e7eb; height: 8px; border-radius: 2px; overflow: hidden;">
          <div style="background: ${color}; height: 100%; width: ${pct}%; transition: width 0.3s;"></div>
        </div>
        <ul style="margin-top: 12px; padding-left: 20px; font-size: 13px; line-height: 1.6;">
          ${findingsHtml}
        </ul>
      </div>`;
  }).join('\n');

  const priorityFixesHtml = scores.priorityFixes.map((fix, i) => {
    const issueList = fix.issues.map(iss =>
      '<li style="margin-bottom: 4px;">' + iss + '</li>'
    ).join('\n');

    return `
      <div style="margin-bottom: 16px; padding: 16px; background: #fef2f2; border-left: 3px solid #ef4444; border-radius: 2px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
          <strong>${i + 1}. ${fix.dimension}</strong>
          <span style="color: #ef4444; font-weight: 600;">Score: ${fix.currentScore}/10</span>
        </div>
        <ul style="padding-left: 20px; font-size: 13px; color: #7f1d1d;">
          ${issueList}
        </ul>
      </div>`;
  }).join('\n');

  // Competitor comparison (if available)
  let competitorHtml = '';
  if (competitors && competitors.length > 0) {
    const rows = scores.dimensions.map(d => {
      const cells = competitors.map(c => {
        const compDim = c.dimensions.find(cd => cd.dimension === d.dimension);
        const compScore = compDim ? compDim.score : '-';
        const color = compDim ? getScoreColor(compDim.score, 10) : '#6b7280';
        return '<td style="text-align: center; color: ' + color + '; font-weight: 600;">' + compScore + '</td>';
      }).join('');
      const mainColor = getScoreColor(d.score, 10);
      return '<tr><td style="padding: 8px;">' + d.dimension + '</td><td style="text-align: center; color: ' + mainColor + '; font-weight: 600;">' + d.score + '</td>' + cells + '</tr>';
    }).join('\n');

    const headerCells = competitors.map(c =>
      '<th style="padding: 8px; text-align: center; font-size: 12px;">' + (new URL(c.url)).hostname + '</th>'
    ).join('');

    competitorHtml = `
      <div style="margin-top: 40px;">
        <h2 style="font-size: 20px; margin-bottom: 16px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">Competitor Comparison</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          <thead>
            <tr style="background: #1f2937; color: white;">
              <th style="padding: 8px; text-align: left;">Dimension</th>
              <th style="padding: 8px; text-align: center;">Your Page</th>
              ${headerCells}
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>`;
  }

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GEO Content Audit - ${scores.url}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #1f2937; line-height: 1.6; background: #fff; }
    .container { max-width: 800px; margin: 0 auto; padding: 40px 24px; }
    h1 { font-size: 28px; margin-bottom: 8px; }
    h2 { font-size: 20px; margin-bottom: 16px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px; }
    .meta { color: #6b7280; font-size: 13px; margin-bottom: 32px; }
    .score-hero { text-align: center; padding: 40px; margin-bottom: 40px; background: #f9fafb; border-radius: 2px; }
    .score-number { font-size: 72px; font-weight: 800; line-height: 1; }
    .score-grade { font-size: 24px; font-weight: 600; margin-top: 8px; }
    .score-label { font-size: 14px; color: #6b7280; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 8px 12px; border-bottom: 1px solid #e5e7eb; text-align: left; }
    thead tr { background: #1f2937; color: white; }
    @media print { .container { padding: 20px; } }
  </style>
</head>
<body>
  <div class="container">
    <h1>GEO Content Audit Report</h1>
    <div class="meta">
      <strong>URL:</strong> ${scores.url}<br>
      <strong>Target Query:</strong> ${scores.query}<br>
      <strong>Date:</strong> ${date}<br>
      ${preparedBy ? '<strong>Prepared by:</strong> ' + preparedBy + '<br>' : ''}
    </div>

    <div class="score-hero">
      <div class="score-number" style="color: ${getGradeColor(scores.grade)};">${scores.overallScore}</div>
      <div class="score-grade" style="color: ${getGradeColor(scores.grade)};">Grade: ${scores.grade}</div>
      <div class="score-label">${scores.gradeLabel}</div>
    </div>

    <h2>Dimension Scores</h2>
    ${dimensionBars}

    ${scores.priorityFixes.length > 0 ? `
    <div style="margin-top: 40px;">
      <h2>Priority Fixes</h2>
      <p style="font-size: 14px; color: #6b7280; margin-bottom: 16px;">Dimensions scoring below 7/10, ordered by urgency:</p>
      ${priorityFixesHtml}
    </div>` : ''}

    ${competitorHtml}

    <div style="margin-top: 40px; padding: 20px; background: #f0fdf4; border-left: 3px solid #22c55e; border-radius: 2px;">
      <h3 style="font-size: 16px; margin-bottom: 8px;">Next Steps</h3>
      <ol style="padding-left: 20px; font-size: 14px; line-height: 1.8;">
        <li>Address the priority fixes above, starting from the lowest-scoring dimension</li>
        <li>Run the <strong>geo-content-optimizer</strong> skill to automatically restructure content</li>
        <li>Re-run this audit after changes to measure improvement</li>
        <li>Use the <strong>ai-brand-visibility-monitor</strong> to track whether changes improve AI mentions</li>
      </ol>
    </div>

    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; font-size: 12px; color: #9ca3af;">
      <p>Generated by GEO Content Auditor | Scoring methodology: 7 dimensions weighted by AI citation impact</p>
      <p>Weights: First-200-Words (25%), Citation-Worthiness (20%), Entity Clarity (15%), Structured Data (12%), Source Reliability (12%), Topical Authority (10%), Content Freshness (6%)</p>
    </div>
  </div>
</body>
</html>`;
}

function main() {
  const args = parseArgs();

  if (!args.scoresPath) {
    console.error('Usage: node generate-report.cjs --scores <scores.json> --output <report.html> [--prepared-by <name>]');
    process.exit(1);
  }

  const scores = JSON.parse(fs.readFileSync(args.scoresPath, 'utf-8'));

  let competitors = null;
  if (args.competitorsPath && fs.existsSync(args.competitorsPath)) {
    competitors = JSON.parse(fs.readFileSync(args.competitorsPath, 'utf-8'));
  }

  const html = generateHTML(scores, args.preparedBy || '', competitors);

  const outputPath = args.outputPath || 'output/geo-audit-report.html';
  const outputDir = path.dirname(outputPath);
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  fs.writeFileSync(outputPath, html);
  console.log('Report saved to: ' + outputPath);
}

main();
