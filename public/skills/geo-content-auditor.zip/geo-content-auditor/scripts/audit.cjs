#!/usr/bin/env node

/**
 * GEO Content Auditor - Core Scoring Engine
 *
 * Scores a page's content across 7 dimensions for AI citation potential.
 * Accepts pre-extracted content (JSON) and produces scored output.
 *
 * Usage:
 *   node audit.cjs --url <url> --query <query> --content <content.json> --output <scores.json>
 *
 * Content JSON format:
 * {
 *   "url": "https://example.com/page",
 *   "title": "Page Title",
 *   "metaDescription": "...",
 *   "headings": [{ "level": 1, "text": "..." }, ...],
 *   "bodyText": "Full body text...",
 *   "first200Words": "First 200 words...",
 *   "statistics": ["stat1", "stat2"],
 *   "authorInfo": { "name": "...", "bio": "...", "credentials": "..." },
 *   "publishDate": "2026-01-15",
 *   "updateDate": "2026-03-01",
 *   "schemaMarkup": [{ "type": "FAQPage", ... }],
 *   "internalLinks": [{ "href": "...", "anchor": "..." }],
 *   "externalLinks": [{ "href": "...", "anchor": "..." }],
 *   "faqSections": [{ "question": "...", "answer": "..." }],
 *   "references": ["source1", "source2"]
 * }
 */

const fs = require('fs');
const path = require('path');

// --- Argument Parsing ---

function parseArgs() {
  const args = process.argv.slice(2);
  const parsed = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--url' && args[i + 1]) parsed.url = args[++i];
    else if (args[i] === '--query' && args[i + 1]) parsed.query = args[++i];
    else if (args[i] === '--content' && args[i + 1]) parsed.contentPath = args[++i];
    else if (args[i] === '--output' && args[i + 1]) parsed.outputPath = args[++i];
    else if (args[i] === '--competitor' && args[i + 1]) {
      if (!parsed.competitors) parsed.competitors = [];
      parsed.competitors.push(args[++i]);
    }
  }
  return parsed;
}

// --- Scoring Functions ---

/**
 * Dimension 1: First-200-Words Answer Quality (0-10)
 * Does the opening directly answer the target query?
 */
function scoreFirst200Words(content, query) {
  const first200 = content.first200Words || content.bodyText?.split(/\s+/).slice(0, 200).join(' ') || '';
  const queryTerms = query.toLowerCase().split(/\s+/).filter(w => w.length > 3);
  let score = 0;
  const findings = [];

  // Check if query terms appear in first 200 words
  const first200Lower = first200.toLowerCase();
  const matchedTerms = queryTerms.filter(term => first200Lower.includes(term));
  const termCoverage = queryTerms.length > 0 ? matchedTerms.length / queryTerms.length : 0;

  if (termCoverage >= 0.8) {
    score += 3;
    findings.push('Strong query term coverage in opening (' + Math.round(termCoverage * 100) + '%)');
  } else if (termCoverage >= 0.5) {
    score += 2;
    findings.push('Moderate query term coverage in opening (' + Math.round(termCoverage * 100) + '%)');
  } else {
    score += 1;
    findings.push('Weak query term coverage in opening (' + Math.round(termCoverage * 100) + '%)');
  }

  // Check for a direct answer pattern (contains specific data, numbers, definitions)
  const hasNumbers = /\d+/.test(first200);
  const hasDefinition = /\bis\b|\bare\b|\bmeans\b|\brefers to\b/i.test(first200);
  const hasSpecifics = /\b(steps?|tips?|ways?|methods?|types?)\b/i.test(first200);

  if (hasNumbers) { score += 2; findings.push('Contains specific numbers/data in opening'); }
  else findings.push('No specific numbers or data points in opening');

  if (hasDefinition) { score += 1; findings.push('Contains definitional language'); }
  if (hasSpecifics) { score += 1; findings.push('Contains structured answer signals (steps, tips, etc.)'); }

  // Check word count of first paragraph (concise = better)
  const firstParagraph = first200.split(/\n\n/)[0] || first200;
  const firstParaWords = firstParagraph.split(/\s+/).length;
  if (firstParaWords <= 50) { score += 2; findings.push('Concise opening paragraph (' + firstParaWords + ' words)'); }
  else if (firstParaWords <= 100) { score += 1; findings.push('Moderate opening paragraph length (' + firstParaWords + ' words)'); }
  else findings.push('Long opening paragraph (' + firstParaWords + ' words) - may bury the answer');

  // Check for fluff/filler opening
  const fluffPatterns = /^(welcome to|in this (article|guide|post)|today we|have you ever wondered)/i;
  if (fluffPatterns.test(first200.trim())) {
    score -= 2;
    findings.push('ISSUE: Opening starts with filler text instead of a direct answer');
  } else {
    score += 1;
    findings.push('Opening avoids common filler patterns');
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'First-200-Words Answer Quality' };
}

/**
 * Dimension 2: Entity Clarity (0-10)
 * Is the brand/author/organization clearly identified with credentials?
 */
function scoreEntityClarity(content) {
  let score = 0;
  const findings = [];

  // Check for author info
  if (content.authorInfo?.name) {
    score += 2;
    findings.push('Author name identified: ' + content.authorInfo.name);
  } else {
    findings.push('ISSUE: No author name found on page');
  }

  if (content.authorInfo?.bio && content.authorInfo.bio.length > 30) {
    score += 2;
    findings.push('Author bio present (' + content.authorInfo.bio.length + ' chars)');
  } else {
    findings.push('ISSUE: No author bio or bio too brief');
  }

  if (content.authorInfo?.credentials) {
    score += 2;
    findings.push('Author credentials present');
  } else {
    findings.push('ISSUE: No explicit credentials or qualifications listed');
  }

  // Check for organization/brand in early content
  const bodyLower = (content.bodyText || '').toLowerCase();
  const first500 = bodyLower.split(/\s+/).slice(0, 500).join(' ');

  // Check schema for organization
  const hasOrgSchema = (content.schemaMarkup || []).some(
    s => s['@type'] === 'Organization' || s['@type'] === 'LocalBusiness' || s['@type'] === 'Person'
  );
  if (hasOrgSchema) {
    score += 2;
    findings.push('Organization/Person schema markup present');
  } else {
    findings.push('ISSUE: No Organization or Person schema markup');
  }

  // Check for credentials patterns in content
  const credentialPatterns = /\b(\d+ years?|certified|licensed|founded|established|experience|expert|specialist)\b/i;
  if (credentialPatterns.test(first500)) {
    score += 2;
    findings.push('Credential/expertise signals found in early content');
  } else {
    findings.push('ISSUE: No expertise signals in first 500 words');
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'Entity Clarity' };
}

/**
 * Dimension 3: Structured Data Presence (0-10)
 * FAQ schema, HowTo schema, article schema present and valid?
 */
function scoreStructuredData(content) {
  let score = 0;
  const findings = [];
  const schemas = content.schemaMarkup || [];
  const schemaTypes = schemas.map(s => s['@type']).filter(Boolean);

  // Check for Article/BlogPosting schema
  if (schemaTypes.some(t => ['Article', 'BlogPosting', 'NewsArticle', 'WebPage'].includes(t))) {
    score += 3;
    findings.push('Article/content schema markup present');
  } else {
    findings.push('ISSUE: No Article or content-type schema markup');
  }

  // Check for FAQ schema
  if (schemaTypes.includes('FAQPage')) {
    score += 3;
    findings.push('FAQ schema markup present');
  } else if (content.faqSections && content.faqSections.length > 0) {
    score += 1;
    findings.push('FAQ content exists but no FAQ schema markup');
  } else {
    findings.push('ISSUE: No FAQ schema or FAQ content');
  }

  // Check for HowTo schema
  if (schemaTypes.includes('HowTo')) {
    score += 2;
    findings.push('HowTo schema markup present');
  } else {
    findings.push('No HowTo schema (may not be applicable)');
  }

  // Check for breadcrumb schema
  if (schemaTypes.includes('BreadcrumbList')) {
    score += 1;
    findings.push('Breadcrumb schema present');
  }

  // Check for any schema at all
  if (schemas.length === 0) {
    score = 0;
    findings.unshift('CRITICAL: No structured data markup found on page');
  } else {
    score += 1;
    findings.push('Total schema types found: ' + schemaTypes.join(', '));
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'Structured Data Presence' };
}

/**
 * Dimension 4: Citation-Worthiness (0-10)
 * Original statistics, unique data, quotable definitions?
 */
function scoreCitationWorthiness(content) {
  let score = 0;
  const findings = [];
  const body = content.bodyText || '';

  // Count statistics and data points
  const stats = content.statistics || [];
  const numberPatterns = body.match(/\b\d+(\.\d+)?(%|\s*(percent|million|billion|thousand|times|x))\b/gi) || [];

  if (stats.length >= 5 || numberPatterns.length >= 10) {
    score += 3;
    findings.push('Rich in data points: ' + (stats.length || numberPatterns.length) + ' statistics found');
  } else if (stats.length >= 2 || numberPatterns.length >= 4) {
    score += 2;
    findings.push('Moderate data points: ' + (stats.length || numberPatterns.length) + ' statistics found');
  } else {
    score += 1;
    findings.push('ISSUE: Few data points or statistics (' + (stats.length || numberPatterns.length) + ' found)');
  }

  // Check for quotable definitions (standalone sentences with "is", "refers to", "defined as")
  const definitionPatterns = body.match(/[A-Z][^.]*\b(is defined as|refers to|is a|is the|means)\b[^.]+\./g) || [];
  if (definitionPatterns.length >= 3) {
    score += 2;
    findings.push('Contains ' + definitionPatterns.length + ' quotable definitions');
  } else if (definitionPatterns.length >= 1) {
    score += 1;
    findings.push('Contains ' + definitionPatterns.length + ' quotable definition(s)');
  } else {
    findings.push('ISSUE: No clear quotable definitions found');
  }

  // Check for original research signals
  const originalPatterns = /\b(our (data|research|study|analysis|findings)|we (found|discovered|analyzed|surveyed)|based on .* (clients?|customers?|campaigns?|accounts?))\b/i;
  if (originalPatterns.test(body)) {
    score += 3;
    findings.push('Contains original research/data signals');
  } else {
    findings.push('ISSUE: No original research or proprietary data signals');
  }

  // Check for standalone stat sentences (AI-citable format)
  const standalonStats = body.match(/^[A-Z][^.]*\d+(\.\d+)?%[^.]*\./gm) || [];
  if (standalonStats.length >= 3) {
    score += 2;
    findings.push(standalonStats.length + ' statistics formatted as standalone quotable sentences');
  } else if (standalonStats.length >= 1) {
    score += 1;
    findings.push(standalonStats.length + ' statistic(s) in standalone quotable format');
  } else {
    findings.push('ISSUE: Statistics are embedded in paragraphs, not formatted as standalone citable sentences');
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'Citation-Worthiness' };
}

/**
 * Dimension 5: Content Freshness (0-10)
 * Publication date, update date, freshness signals?
 */
function scoreContentFreshness(content) {
  let score = 0;
  const findings = [];
  const now = new Date();

  // Check publication date
  if (content.publishDate) {
    const pubDate = new Date(content.publishDate);
    const monthsOld = (now - pubDate) / (1000 * 60 * 60 * 24 * 30);
    if (monthsOld <= 3) {
      score += 3;
      findings.push('Published recently: ' + content.publishDate);
    } else if (monthsOld <= 12) {
      score += 2;
      findings.push('Published within last year: ' + content.publishDate);
    } else {
      score += 1;
      findings.push('Published over a year ago: ' + content.publishDate);
    }
  } else {
    findings.push('ISSUE: No publication date visible on page');
  }

  // Check update date
  if (content.updateDate) {
    const updDate = new Date(content.updateDate);
    const monthsOld = (now - updDate) / (1000 * 60 * 60 * 24 * 30);
    if (monthsOld <= 3) {
      score += 3;
      findings.push('Updated recently: ' + content.updateDate);
    } else if (monthsOld <= 6) {
      score += 2;
      findings.push('Updated within 6 months: ' + content.updateDate);
    } else {
      score += 1;
      findings.push('Last update over 6 months ago: ' + content.updateDate);
    }
  } else {
    findings.push('ISSUE: No "last updated" date visible');
  }

  // Check for freshness signals in content
  const body = content.bodyText || '';
  const currentYear = now.getFullYear().toString();
  const lastYear = (now.getFullYear() - 1).toString();

  if (body.includes(currentYear)) {
    score += 2;
    findings.push('Content references current year (' + currentYear + ')');
  } else if (body.includes(lastYear)) {
    score += 1;
    findings.push('Content references last year (' + lastYear + ')');
  } else {
    findings.push('ISSUE: No recent year references in content');
  }

  // Check for temporal language
  const temporalPatterns = /\b(latest|updated|current|recent|new|2026|2025)\b/i;
  if (temporalPatterns.test(body)) {
    score += 2;
    findings.push('Contains freshness language (latest, updated, current, etc.)');
  } else {
    findings.push('No freshness language detected');
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'Content Freshness' };
}

/**
 * Dimension 6: Topical Authority (0-10)
 * Internal links to related content, depth of coverage?
 */
function scoreTopicalAuthority(content) {
  let score = 0;
  const findings = [];
  const body = content.bodyText || '';
  const internalLinks = content.internalLinks || [];
  const headings = content.headings || [];

  // Check internal link count
  if (internalLinks.length >= 10) {
    score += 3;
    findings.push('Strong internal linking: ' + internalLinks.length + ' internal links');
  } else if (internalLinks.length >= 5) {
    score += 2;
    findings.push('Moderate internal linking: ' + internalLinks.length + ' internal links');
  } else if (internalLinks.length >= 1) {
    score += 1;
    findings.push('Weak internal linking: ' + internalLinks.length + ' internal link(s)');
  } else {
    findings.push('ISSUE: No internal links found');
  }

  // Check content depth (word count)
  const wordCount = body.split(/\s+/).length;
  if (wordCount >= 2000) {
    score += 3;
    findings.push('Comprehensive content depth: ' + wordCount + ' words');
  } else if (wordCount >= 1000) {
    score += 2;
    findings.push('Moderate content depth: ' + wordCount + ' words');
  } else {
    score += 1;
    findings.push('Thin content: ' + wordCount + ' words');
  }

  // Check heading structure depth
  const h2Count = headings.filter(h => h.level === 2).length;
  const h3Count = headings.filter(h => h.level === 3).length;

  if (h2Count >= 5 && h3Count >= 3) {
    score += 2;
    findings.push('Rich heading structure: ' + h2Count + ' H2s, ' + h3Count + ' H3s');
  } else if (h2Count >= 3) {
    score += 1;
    findings.push('Adequate heading structure: ' + h2Count + ' H2s, ' + h3Count + ' H3s');
  } else {
    findings.push('ISSUE: Shallow heading structure: ' + h2Count + ' H2(s)');
  }

  // Check for subtopic coverage breadth
  const topicIndicators = body.match(/\b(what|how|why|when|where|who|which|cost|price|best|top|vs|versus|comparison|guide|tips|steps)\b/gi) || [];
  const uniqueIndicators = [...new Set(topicIndicators.map(t => t.toLowerCase()))];
  if (uniqueIndicators.length >= 6) {
    score += 2;
    findings.push('Broad subtopic coverage (' + uniqueIndicators.length + ' question/topic indicators)');
  } else if (uniqueIndicators.length >= 3) {
    score += 1;
    findings.push('Moderate subtopic coverage (' + uniqueIndicators.length + ' question/topic indicators)');
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'Topical Authority' };
}

/**
 * Dimension 7: Source Reliability (0-10)
 * Author bios, references, publication date, trust markers?
 */
function scoreSourceReliability(content) {
  let score = 0;
  const findings = [];

  // Check for author bio
  if (content.authorInfo?.bio && content.authorInfo.bio.length > 50) {
    score += 2;
    findings.push('Detailed author bio present');
  } else if (content.authorInfo?.name) {
    score += 1;
    findings.push('Author name present but no detailed bio');
  } else {
    findings.push('ISSUE: No author attribution');
  }

  // Check for references/citations
  const refs = content.references || [];
  const externalLinks = content.externalLinks || [];
  const citationLinks = externalLinks.filter(l =>
    !l.href?.includes('facebook.com') &&
    !l.href?.includes('twitter.com') &&
    !l.href?.includes('instagram.com') &&
    !l.href?.includes('linkedin.com')
  );

  if (refs.length >= 3 || citationLinks.length >= 5) {
    score += 3;
    findings.push('Strong sourcing: ' + (refs.length || citationLinks.length) + ' references/citation links');
  } else if (refs.length >= 1 || citationLinks.length >= 2) {
    score += 1;
    findings.push('Some sourcing: ' + (refs.length || citationLinks.length) + ' reference(s)');
  } else {
    findings.push('ISSUE: No external references or citations');
  }

  // Check for publication date visibility
  if (content.publishDate) {
    score += 2;
    findings.push('Publication date visible');
  } else {
    findings.push('ISSUE: No visible publication date');
  }

  // Check for trust signals in content
  const body = content.bodyText || '';
  const trustPatterns = /\b(according to|research (shows|indicates|suggests)|study (by|from)|data (from|shows)|source:|cited|peer.reviewed)\b/i;
  if (trustPatterns.test(body)) {
    score += 2;
    findings.push('Contains trust/citation language in content');
  } else {
    findings.push('ISSUE: No trust language (according to, research shows, etc.)');
  }

  // Check for disclaimers or editorial standards
  const editorialPatterns = /\b(editorial|reviewed by|fact.check|medically reviewed|last verified)\b/i;
  if (editorialPatterns.test(body)) {
    score += 1;
    findings.push('Editorial/review standards mentioned');
  }

  return { score: Math.max(0, Math.min(10, score)), findings, dimension: 'Source Reliability' };
}

// --- Main ---

function calculateOverallScore(dimensions) {
  const weights = {
    'First-200-Words Answer Quality': 0.25,
    'Entity Clarity': 0.15,
    'Structured Data Presence': 0.12,
    'Citation-Worthiness': 0.20,
    'Content Freshness': 0.06,
    'Topical Authority': 0.10,
    'Source Reliability': 0.12
  };

  let weightedSum = 0;
  let totalWeight = 0;

  for (const dim of dimensions) {
    const weight = weights[dim.dimension] || 0;
    weightedSum += (dim.score / 10) * weight;
    totalWeight += weight;
  }

  return Math.round((weightedSum / totalWeight) * 100);
}

function getGrade(score) {
  if (score >= 85) return { grade: 'A', label: 'AI-optimized, likely being cited' };
  if (score >= 70) return { grade: 'B', label: 'Good foundation, specific improvements needed' };
  if (score >= 55) return { grade: 'C', label: 'Significant gaps in AI-readiness' };
  if (score >= 40) return { grade: 'D', label: 'Major restructuring needed' };
  return { grade: 'F', label: 'Not AI-citation ready' };
}

function main() {
  const args = parseArgs();

  if (!args.contentPath) {
    console.error('Usage: node audit.cjs --url <url> --query <query> --content <content.json> --output <scores.json>');
    process.exit(1);
  }

  // Read content
  let content;
  try {
    content = JSON.parse(fs.readFileSync(args.contentPath, 'utf-8'));
  } catch (e) {
    console.error('Error reading content file:', e.message);
    process.exit(1);
  }

  const query = args.query || '';
  const url = args.url || content.url || '';

  console.log('GEO Content Audit');
  console.log('URL: ' + url);
  console.log('Query: ' + query);
  console.log('---');

  // Run all 7 dimension scores
  const dimensions = [
    scoreFirst200Words(content, query),
    scoreEntityClarity(content),
    scoreStructuredData(content),
    scoreCitationWorthiness(content),
    scoreContentFreshness(content),
    scoreTopicalAuthority(content),
    scoreSourceReliability(content)
  ];

  // Calculate overall
  const overallScore = calculateOverallScore(dimensions);
  const gradeInfo = getGrade(overallScore);

  // Print summary
  console.log('\nOverall GEO Score: ' + overallScore + '/100 (' + gradeInfo.grade + ')');
  console.log(gradeInfo.label);
  console.log('');

  for (const dim of dimensions) {
    console.log(dim.dimension + ': ' + dim.score + '/10');
    for (const f of dim.findings) {
      console.log('  ' + (f.startsWith('ISSUE') || f.startsWith('CRITICAL') ? '!' : '-') + ' ' + f);
    }
    console.log('');
  }

  // Build output
  const output = {
    url,
    query,
    timestamp: new Date().toISOString(),
    overallScore,
    grade: gradeInfo.grade,
    gradeLabel: gradeInfo.label,
    dimensions: dimensions.map(d => ({
      dimension: d.dimension,
      score: d.score,
      findings: d.findings
    })),
    priorityFixes: dimensions
      .filter(d => d.score < 7)
      .sort((a, b) => a.score - b.score)
      .map(d => ({
        dimension: d.dimension,
        currentScore: d.score,
        issues: d.findings.filter(f => f.startsWith('ISSUE') || f.startsWith('CRITICAL'))
      }))
  };

  // Write output
  const outputPath = args.outputPath || '/tmp/geo-audit/scores.json';
  const outputDir = path.dirname(outputPath);
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));
  console.log('Scores saved to: ' + outputPath);
}

main();
