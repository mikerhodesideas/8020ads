#!/usr/bin/env node

/**
 * Search Term Analyzer - SOP 1 Data Processor
 *
 * Compresses search-terms.csv (100k+ rows) into a compact JSON summary
 * that Claude can analyze without overflowing the context window.
 *
 * Buckets:
 *   - promotion_candidates: Converting terms not yet in keywords
 *   - irrelevant_candidates: Non-converting, high-cost (date range pre-shifted by conversionLagDays at query time)
 *   - manual_review_unknown_status: Terms requiring status resolution (no negatives source)
 *   - monitor: Low-volume terms worth watching
 *   - pmax_shopping_summary: PMax/Shopping terms (SOP 3 only, not SOP 1/2)
 *
 * Output caps: top 150 irrelevants by cost, all promotions, top 30 monitor
 *
 * Usage:
 *   node analyze-terms.js [--campaign="Campaign Name"] [--output=<path>]
 */

import { readFileSync, existsSync, statSync, mkdirSync } from 'fs';
import { writeFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import { config } from 'dotenv';
import { parse } from 'csv-parse/sync';

// Find project root by walking up from script location
const __dirname = dirname(fileURLToPath(import.meta.url));
let _projectRoot = __dirname;
while (_projectRoot !== '/' && !existsSync(resolve(_projectRoot, 'config'))) {
    _projectRoot = resolve(_projectRoot, '..');
}

// Load environment variables from config/.env
config({ path: resolve(_projectRoot, 'config/.env') });

// --- Parse CLI args ---
const args = process.argv.slice(2).reduce((acc, arg) => {
    if (arg.startsWith('--')) {
        const eq = arg.indexOf('=');
        if (eq > -1) {
            acc[arg.slice(2, eq)] = arg.slice(eq + 1);
        } else {
            acc[arg.slice(2)] = true;
        }
    }
    return acc;
}, {});

const campaignFilter = args['campaign'] || null;
const exportFlag = true; // Always export CSVs on every run
const defaultOutput = resolve(_projectRoot, '.claude/skills/search-term-analyzer/tmp/analysis-summary.json');
const outputPath = args['output'] || defaultOutput;

// --- Load config ---
let appConfig = {};
const configPath = resolve(_projectRoot, 'config/ads-context.config.json');
if (existsSync(configPath)) {
    appConfig = JSON.parse(readFileSync(configPath, 'utf8'));
}
const sta = appConfig.searchTermAnalysis || {};
const minCostForNeg = parseFloat(sta.minSpendToFlag ?? 20);
const conversionLagDays = parseInt(sta.conversionLagDays ?? 14, 10);
const excludeBranded = sta.excludeBrandedCampaigns ?? true;
// Explicit branded campaign list (failsafe). Falls back to name-pattern detection if empty.
const brandedCampaignNames = new Set(
    (sta.brandedCampaigns || []).map(n => n.toLowerCase().trim())
);
const biddingStrategyType = (sta.biddingStrategy || 'cpa').toLowerCase();
const inefficientCPAMultiplier = parseFloat(sta.inefficientCPAMultiplier ?? 1.5);
const inefficientROASMultiplier = parseFloat(sta.inefficientROASMultiplier ?? 0.7);
const minCostForInefficient = parseFloat(sta.minSpendForInefficient ?? 50);
const minClicksForInefficient = parseInt(sta.minClicksForInefficient ?? 3, 10);
const negativesExportConfigPath = null;
const neverExcludeTerms = new Set((sta.protectedTerms?.neverExclude || []).map(t => norm(t)));
const alwaysIncludeTerms = new Set((sta.protectedTerms?.alwaysInclude || []).map(t => norm(t)));

// Currency symbol resolution
const CURRENCY_SYMBOLS = { USD: '$', EUR: '€', GBP: '£', CAD: 'CA$', AUD: 'A$', JPY: '¥', CHF: 'CHF', NZD: 'NZ$', SEK: 'kr', NOK: 'kr', DKK: 'kr', PLN: 'zł', BRL: 'R$', MXN: 'MX$', INR: '₹', ZAR: 'R' };
const currency = (appConfig.googleAds?.currency || 'USD').toUpperCase();
const currencySymbol = CURRENCY_SYMBOLS[currency] || currency;

// --- Parse business.md for CPA/ROAS targets ---
function parseBusinessContext() {
    const businessPath = resolve(_projectRoot, 'context/business.md');
    if (!existsSync(businessPath)) return { targetCPA: null, maxCPA: null, targetROAS: null };
    const content = readFileSync(businessPath, 'utf8');

    let targetCPA = null, maxCPA = null, targetROAS = null;

    // Match patterns like "Target CPA: $85", "Max CPA: $120", "CPA target: 85"
    const lines = content.split('\n');
    for (const line of lines) {
        const lower = line.toLowerCase();
        const dollarMatch = line.match(/\$\s*([\d,]+(?:\.\d+)?)/);
        const numMatch = line.match(/([\d,]+(?:\.\d+)?)/);
        const val = dollarMatch ? parseFloat(dollarMatch[1].replace(/,/g, '')) :
                    numMatch ? parseFloat(numMatch[1].replace(/,/g, '')) : null;
        if (val === null) continue;

        if (lower.includes('max cpa') || lower.includes('maximum cpa') || lower.includes('cpa limit')) {
            maxCPA = val;
        } else if (lower.includes('target cpa') || lower.includes('cpa target') || lower.includes('goal cpa')) {
            targetCPA = val;
        } else if (lower.includes('target roas') || lower.includes('roas target') || lower.includes('goal roas')) {
            targetROAS = val;
        }
    }

    return { targetCPA: targetCPA || maxCPA, maxCPA, targetROAS };
}

// --- Load CSV helper ---
function loadCSV(filePath) {
    if (!existsSync(filePath)) return [];
    try {
        const content = readFileSync(filePath, 'utf8');
        return parse(content, { columns: true, skip_empty_lines: true, trim: true });
    } catch (e) {
        console.error(`Warning: Could not parse ${filePath}: ${e.message}`);
        return [];
    }
}

// --- Get field with multiple possible column name formats ---
function f(row, ...names) {
    for (const name of names) {
        if (row[name] !== undefined && row[name] !== '') return row[name];
    }
    return '';
}

// --- Parse numeric ---
function num(val) {
    if (val === null || val === undefined || val === '') return 0;
    const n = parseFloat(String(val).replace(/,/g, ''));
    return isNaN(n) ? 0 : n;
}

function norm(val) {
    return String(val || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function key3(campaign, adGroup, term) {
    return `${norm(campaign)}|||${norm(adGroup)}|||${norm(term)}`;
}

function key2(campaign, term) {
    return `${norm(campaign)}|||${norm(term)}`;
}

function loadNegativeStatus(configPath) {
    const empty = {
        available: false,
        source: null,
        accountTerms: new Set(),
        campaignTerms: new Set(),
        adGroupTerms: new Set(),
        linkAwareShared: false,
        warnings: []
    };

    function buildFromRows(rows, sourceLabel) {
        const accountTerms = new Set();
        const campaignTerms = new Set();
        const adGroupTerms = new Set();
        for (const row of rows) {
            const term = norm(f(
                row,
                'Keyword', 'keyword', 'criteria', 'negative_keyword',
                'campaign_negative_keyword.keyword.text', 'ad_group_criterion.keyword.text',
                'campaign_criterion.keyword.text', 'shared_criterion.keyword.text'
            ));
            if (!term) continue;

            const campaign = norm(f(row, 'Campaign', 'campaign', 'campaign.name'));
            const adGroup = norm(f(row, 'Ad Group', 'ad_group', 'ad_group.name'));
            if (campaign && adGroup) {
                adGroupTerms.add(`${campaign}|||${adGroup}|||${term}`);
            } else if (campaign) {
                campaignTerms.add(`${campaign}|||${term}`);
            } else {
                accountTerms.add(term);
            }
        }
        return {
            available: true,
            source: sourceLabel,
            accountTerms,
            campaignTerms,
            adGroupTerms,
            linkAwareShared: false,
            warnings: []
        };
    }

    // Priority 1: explicit/legacy single-file exports
    const singleCandidates = [];
    if (configPath) singleCandidates.push(resolve(_projectRoot, configPath));
    singleCandidates.push(resolve(_projectRoot, 'context/google-ads/data/negative-keywords.csv'));
    singleCandidates.push(resolve(_projectRoot, 'context/google-ads/data/negatives.csv'));
    for (const p of singleCandidates) {
        if (existsSync(p)) {
            return buildFromRows(loadCSV(p), p);
        }
    }

    // Priority 2: split files auto-pulled by /gads-context
    const campaignNegPath = resolve(_projectRoot, 'context/google-ads/data/negative-keywords-campaign.csv');
    const adGroupNegPath = resolve(_projectRoot, 'context/google-ads/data/negative-keywords-adgroup.csv');
    const sharedNegPath = resolve(_projectRoot, 'context/google-ads/data/negative-keywords-shared.csv');
    const sharedLinksPath = resolve(_projectRoot, 'context/google-ads/data/negative-keywords-shared-links.csv');

    const hasCampaignNegs = existsSync(campaignNegPath);
    const hasAdGroupNegs = existsSync(adGroupNegPath);
    const hasSharedNegs = existsSync(sharedNegPath);
    const hasSharedLinks = existsSync(sharedLinksPath);

    if (!hasCampaignNegs && !hasAdGroupNegs && !hasSharedNegs) {
        return empty;
    }

    const accountTerms = new Set();
    const campaignTerms = new Set();
    const adGroupTerms = new Set();
    const warnings = [];
    const sources = [];

    if (hasCampaignNegs) {
        sources.push(campaignNegPath);
        const rows = loadCSV(campaignNegPath);
        for (const row of rows) {
            const term = norm(f(row, 'campaign_criterion.keyword.text', 'Keyword', 'keyword', 'criteria'));
            const campaign = norm(f(row, 'campaign.name', 'Campaign', 'campaign'));
            if (!term) continue;
            if (campaign) campaignTerms.add(`${campaign}|||${term}`);
            else accountTerms.add(term);
        }
    }

    if (hasAdGroupNegs) {
        sources.push(adGroupNegPath);
        const rows = loadCSV(adGroupNegPath);
        for (const row of rows) {
            const term = norm(f(row, 'ad_group_criterion.keyword.text', 'Keyword', 'keyword', 'criteria'));
            const campaign = norm(f(row, 'campaign.name', 'Campaign', 'campaign'));
            const adGroup = norm(f(row, 'ad_group.name', 'Ad Group', 'ad_group'));
            if (!term) continue;
            if (campaign && adGroup) adGroupTerms.add(`${campaign}|||${adGroup}|||${term}`);
            else if (campaign) campaignTerms.add(`${campaign}|||${term}`);
            else accountTerms.add(term);
        }
    }

    // Shared list terms are only active where list links exist; resolve via shared-links file.
    let linkAwareShared = false;
    if (hasSharedNegs) {
        sources.push(sharedNegPath);

        // Collect terms by shared set key
        const sharedTermsBySet = new Map();
        const looseSharedTerms = new Set();
        const sharedRows = loadCSV(sharedNegPath);
        for (const row of sharedRows) {
            const term = norm(f(row, 'shared_criterion.keyword.text', 'Keyword', 'keyword', 'criteria'));
            if (!term) continue;
            const setRes = norm(f(row, 'shared_set.resource_name'));
            const setName = norm(f(row, 'shared_set.name', 'Shared Set', 'shared_set'));
            const setKey = setRes || setName;
            if (!setKey) {
                looseSharedTerms.add(term);
                continue;
            }
            if (!sharedTermsBySet.has(setKey)) sharedTermsBySet.set(setKey, new Set());
            sharedTermsBySet.get(setKey).add(term);
        }

        if (hasSharedLinks) {
            sources.push(sharedLinksPath);
            linkAwareShared = true;
            const campaignBySet = new Map();
            const linkRows = loadCSV(sharedLinksPath);
            for (const row of linkRows) {
                const campaign = norm(f(row, 'campaign.name', 'Campaign', 'campaign'));
                const setRes = norm(f(row, 'shared_set.resource_name'));
                const setName = norm(f(row, 'shared_set.name', 'Shared Set', 'shared_set'));
                const setKey = setRes || setName;
                if (!campaign || !setKey) continue;
                if (!campaignBySet.has(setKey)) campaignBySet.set(setKey, new Set());
                campaignBySet.get(setKey).add(campaign);
            }

            for (const [setKey, terms] of sharedTermsBySet.entries()) {
                const campaignsForSet = campaignBySet.get(setKey);
                if (!campaignsForSet || campaignsForSet.size === 0) {
                    warnings.push(`Shared set has no campaign links: ${setKey}`);
                    for (const term of terms) accountTerms.add(term);
                    continue;
                }
                for (const campaign of campaignsForSet) {
                    for (const term of terms) {
                        campaignTerms.add(`${campaign}|||${term}`);
                    }
                }
            }
        } else {
            warnings.push('Shared negative links file missing; shared terms treated as account-level.');
            for (const terms of sharedTermsBySet.values()) {
                for (const term of terms) accountTerms.add(term);
            }
        }

        for (const term of looseSharedTerms) accountTerms.add(term);
    }

    return {
        available: true,
        source: sources.join(', '),
        accountTerms,
        campaignTerms,
        adGroupTerms,
        linkAwareShared,
        warnings
    };
}

function isTermExcluded(negatives, campaign, adGroup, term) {
    const t = norm(term);
    const c = norm(campaign);
    const a = norm(adGroup);
    if (!t) return false;
    if (negatives.adGroupTerms.has(`${c}|||${a}|||${t}`)) return true;
    if (negatives.campaignTerms.has(`${c}|||${t}`)) return true;
    if (negatives.accountTerms.has(t)) return true;
    return false;
}

// --- Campaign type routing ---
// Google Ads API returns numeric codes for advertising_channel_type
const CHANNEL_TYPE_CODES = {
    '2': 'SEARCH',
    '3': 'DISPLAY',
    '4': 'SHOPPING',
    '6': 'VIDEO',
    '9': 'SMART',
    '10': 'MULTI_CHANNEL'  // Performance Max
};
const SKIP_TYPES = new Set(['DISPLAY', 'VIDEO', 'HOTEL', 'LOCAL', 'SMART']);
const PMAX_TYPES = new Set(['MULTI_CHANNEL', 'PERFORMANCE_MAX']);
const SHOPPING_TYPES = new Set(['SHOPPING']);

function getCampaignType(row, campaignTypeMap) {
    const direct = f(row, 'campaign.advertising_channel_type', 'campaign_advertising_channel_type');
    if (direct) {
        const code = String(direct).trim();
        return (CHANNEL_TYPE_CODES[code] || direct).toUpperCase();
    }
    const campName = f(row, 'campaign.name', 'campaign_name');
    const fromMap = campaignTypeMap[campName] || 'SEARCH';
    return (CHANNEL_TYPE_CODES[String(fromMap).trim()] || fromMap).toUpperCase();
}

// --- Main ---
const { targetCPA, maxCPA, targetROAS } = parseBusinessContext();
const effectiveCPA = maxCPA || targetCPA;

// Load data
const searchTermsPath = resolve(_projectRoot, 'context/google-ads/data/search-terms.csv');
const searchTerms = loadCSV(searchTermsPath);
const keywords = loadCSV(resolve(_projectRoot, 'context/google-ads/data/keywords.csv'));
const campaigns = loadCSV(resolve(_projectRoot, 'context/google-ads/data/campaigns.csv'));
const negatives = loadNegativeStatus(negativesExportConfigPath);

// Load self-learning decisions file (terms user marked as relevant / n-grams rejected)
const decisionsPath = resolve(_projectRoot, 'context/analysis/search-term-decisions.json');
let decisions = { relevantTerms: [], rejectedNgrams: [] };
if (existsSync(decisionsPath)) {
    try {
        decisions = JSON.parse(readFileSync(decisionsPath, 'utf8'));
    } catch (e) {
        console.warn(`WARNING: Could not parse search-term-decisions.json: ${e.message}`);
    }
}
const knownRelevantSet = new Set((decisions.relevantTerms || []).map(t => t.toLowerCase().trim()));

if (searchTerms.length === 0) {
    console.error('ERROR: search-terms.csv not found or empty. Run /gads-context first.');
    process.exit(1);
}

// Data age (days since file was last modified)
let dataAgeDays = 0;
if (existsSync(searchTermsPath)) {
    const mtimeMs = statSync(searchTermsPath).mtimeMs;
    dataAgeDays = Math.round((Date.now() - mtimeMs) / (1000 * 60 * 60 * 24));
}

// Build campaign type map from campaigns.csv (fallback if not in search-terms.csv)
// Map numeric codes to string names at build time
const campaignTypeMap = {};
// Build campaign bidding strategy map: campaign name → { strategy: 'cpa'|'roas', target: number|null }
const BIDDING_STRATEGY_CODES = {
    '2': 'MANUAL_CPC', '3': 'MANUAL_CPM', '6': 'TARGET_CPA', '7': 'PAGE_ONE_PROMOTED',
    '9': 'TARGET_SPEND', '10': 'TARGET_ROAS', '11': 'MAXIMIZE_CONVERSIONS',
    '12': 'MAXIMIZE_CONVERSION_VALUE', '13': 'TARGET_IMPRESSION_SHARE', '14': 'MANUAL_CPV'
};
const CPA_STRATEGIES = new Set(['TARGET_CPA', 'MAXIMIZE_CONVERSIONS', 'MANUAL_CPC', 'TARGET_SPEND']);
const ROAS_STRATEGIES = new Set(['TARGET_ROAS', 'MAXIMIZE_CONVERSION_VALUE']);
const campaignBiddingMap = {};
for (const c of campaigns) {
    const name = f(c, 'campaign.name', 'campaign_name', 'name');
    const rawType = f(c, 'campaign.advertising_channel_type', 'campaign_advertising_channel_type', 'advertising_channel_type');
    if (name) campaignTypeMap[name] = CHANNEL_TYPE_CODES[String(rawType).trim()] || rawType || 'SEARCH';

    const rawStrategy = f(c, 'campaign.bidding_strategy_type', 'campaign_bidding_strategy_type', 'bidding_strategy_type');
    const strategyName = (BIDDING_STRATEGY_CODES[String(rawStrategy).trim()] || String(rawStrategy)).toUpperCase();
    const targetCpaDirect = num(f(c, 'campaign.target_cpa.target_cpa_micros', 'campaign_target_cpa_target_cpa_micros', 'campaign.target_cpa.target_cpa', 'campaign_target_cpa_target_cpa'));
    const targetCpaMaxConv = num(f(c, 'campaign.maximize_conversions.target_cpa_micros', 'campaign_maximize_conversions_target_cpa_micros', 'campaign.maximize_conversions.target_cpa', 'campaign_maximize_conversions_target_cpa'));
    const targetCpaMicros = targetCpaDirect || targetCpaMaxConv;
    const targetRoasMaxConvValue = num(f(c, 'campaign.maximize_conversion_value.target_roas', 'campaign_maximize_conversion_value_target_roas'));
    const targetRoasDirect = num(f(c, 'campaign.target_roas.target_roas', 'campaign_target_roas_target_roas'));
    const targetRoas = targetRoasMaxConvValue || targetRoasDirect;

    if (name) {
        let strategy = biddingStrategyType; // fallback to global config
        let target = null;
        if (ROAS_STRATEGIES.has(strategyName)) {
            strategy = 'roas';
            target = targetRoas > 0 ? targetRoas : (targetROAS || null);
        } else if (CPA_STRATEGIES.has(strategyName)) {
            strategy = 'cpa';
            target = targetCpaMicros > 0 ? targetCpaMicros : (effectiveCPA || null);
        }
        campaignBiddingMap[name] = { strategy, target, strategyName };
    }
}

// Build existing keywords set for duplicate detection (lowercased)
const existingKeywords = new Set();
const existingKeywordsByAdGroup = new Set();
for (const kw of keywords) {
    const campaign = f(kw, 'campaign.name', 'campaign_name');
    const adGroup = f(kw, 'ad_group.name', 'ad_group_name');
    const text = f(kw,
        'ad_group_criterion.keyword.text',
        'keyword.text', 'keyword_text',
        'criteria', 'keyword'
    ).toLowerCase().trim();
    if (!text) continue;
    existingKeywords.add(text);
    if (campaign && adGroup) {
        existingKeywordsByAdGroup.add(key3(campaign, adGroup, text));
    }
}

// Campaign type breakdown counters
const typeBreakdown = { SEARCH: 0, MULTI_CHANNEL: 0, SHOPPING: 0, skipped: 0 };

// Buckets
const promotionCandidates = [];
const irrelevantCandidates = [];
const manualReviewUnknownStatus = [];
const inefficientCandidates = [];
const monitor = [];
const pmaxShoppingCampaigns = new Set();
let pmaxShoppingCount = 0;
let pmaxShoppingCost = 0;
const pmaxMonitor = [];  // PMax 0-conv terms for review/export

const filteredSearchRows = [];

for (const row of searchTerms) {
    const campName = f(row, 'campaign.name', 'campaign_name');

    // Campaign filter
    if (campaignFilter && !campName.toLowerCase().includes(campaignFilter.toLowerCase())) continue;

    // Exclude BRANDED campaigns.
    // Priority: explicit brandedCampaigns list in config → fallback to name-pattern detection.
    // Name-pattern fallback: "Branded" but NOT "Non-Branded" (guards against substring match).
    const isBrandedCampaign = brandedCampaignNames.size > 0
        ? brandedCampaignNames.has(campName.toLowerCase().trim())
        : /branded/i.test(campName) && !/non.?branded/i.test(campName);
    if (excludeBranded && isBrandedCampaign) continue;

    const campType = getCampaignType(row, campaignTypeMap);
    const networkType = f(row, 'segments.ad_network_type', 'ad_network_type') || 'SEARCH';

    // Skip display/video entirely
    if (SKIP_TYPES.has(campType)) {
        typeBreakdown.skipped = (typeBreakdown.skipped || 0) + 1;
        continue;
    }

    // PMax and Shopping: count for N-gram, not for SOP 1/2
    if (PMAX_TYPES.has(campType) || SHOPPING_TYPES.has(campType)) {
        const key = PMAX_TYPES.has(campType) ? 'MULTI_CHANNEL' : 'SHOPPING';
        typeBreakdown[key] = (typeBreakdown[key] || 0) + 1;
        const cost = num(f(row, 'metrics.cost', 'cost'));
        const conversions = num(f(row, 'metrics.conversions', 'conversions'));
        pmaxShoppingCount++;
        pmaxShoppingCost += cost;
        if (campName) pmaxShoppingCampaigns.add(campName);
        // Track PMax 0-conversion terms with impressions for monitor/export
        if (PMAX_TYPES.has(campType) && conversions === 0) {
            const term = f(row, 'campaign_search_term_view.search_term', 'search_term');
            const impressions = num(f(row, 'metrics.impressions', 'impressions'));
            if (term && impressions >= 50) {
                pmaxMonitor.push({
                    term,
                    campaign: campName,
                    cost: Math.round(cost * 100) / 100,
                    impressions,
                    clicks: num(f(row, 'metrics.clicks', 'clicks'))
                });
            }
        }
        continue;
    }

    // Search campaign
    typeBreakdown.SEARCH = (typeBreakdown.SEARCH || 0) + 1;

    const term = f(row, 'campaign_search_term_view.search_term', 'search_term');
    if (!term) continue;

    const adGroup = f(row, 'ad_group.name', 'ad_group_name');

    filteredSearchRows.push({
        row,
        campName,
        adGroup,
        term,
        campType,
        networkType
    });
}

// --- Aggregate metrics by term+campaign+adGroup across all date rows ---
const aggregated = new Map();
for (const item of filteredSearchRows) {
    const row = item.row;
    const aKey = key3(item.campName, item.adGroup, item.term);

    const clicks = num(f(row, 'clicks', 'metrics.clicks'));
    const impressions = num(f(row, 'impressions', 'metrics.impressions'));
    const cost = num(f(row, 'cost', 'metrics.cost'));
    const conversions = num(f(row, 'conversions', 'metrics.conversions'));
    const convValue = num(f(row, 'conversions_value', 'metrics.conversions_value'));

    if (aggregated.has(aKey)) {
        const agg = aggregated.get(aKey);
        agg.clicks += clicks;
        agg.impressions += impressions;
        agg.cost += cost;
        agg.conversions += conversions;
        agg.convValue += convValue;
    } else {
        aggregated.set(aKey, {
            term: item.term,
            campName: item.campName,
            adGroup: item.adGroup,
            campType: item.campType,
            networkType: item.networkType,
            clicks,
            impressions,
            cost,
            conversions,
            convValue
        });
    }
}

// --- Bucket aggregated terms ---
for (const [aKey, agg] of aggregated.entries()) {
    const { term, campName, adGroup, campType, networkType } = agg;
    const { clicks, impressions, conversions, convValue } = agg;
    const cost = agg.cost;
    const cpa = conversions > 0 ? cost / conversions : null;
    const roas = cost > 0 && convValue > 0 ? convValue / cost : null;

    const statusKey = key3(campName, adGroup, term);
    const alreadyKeyword = existingKeywords.has(norm(term));
    const addedInAdGroup = existingKeywordsByAdGroup.has(statusKey);
    const excluded = negatives.available ? isTermExcluded(negatives, campName, adGroup, term) : null;

    let status = 'unknown';
    let statusResolution = 'no_negative_data';
    if (addedInAdGroup) {
        status = 'added_in_ad_group';
        statusResolution = 'added_by_keyword_lookup';
    } else if (negatives.available) {
        status = excluded ? 'excluded' : 'none';
        statusResolution = 'negative_lookup';
    }

    // Resolve per-campaign bidding strategy + target (fallback to global config → business.md)
    const campBidding = campaignBiddingMap[campName] || { strategy: biddingStrategyType, target: null };
    const termStrategy = campBidding.strategy;
    const termTarget = campBidding.target ||
        (termStrategy === 'roas' ? targetROAS : effectiveCPA);

    const termData = {
        term,
        campaign: campName,
        adGroup,
        campaignType: campType,
        networkType,
        conversions: Math.round(conversions * 100) / 100,
        cost: Math.round(cost * 100) / 100,
        cpa: cpa !== null ? Math.round(cpa * 100) / 100 : null,
        roas: roas !== null ? Math.round(roas * 100) / 100 : null,
        clicks,
        impressions,
        alreadyKeyword,
        status,
        status_resolution: statusResolution,
        biddingStrategy: termStrategy,
        campaignTarget: termTarget !== null ? Math.round(termTarget * 100) / 100 : null
    };

    // Unknown status is never auto-classified (conservative fallback)
    if (status === 'unknown') {
        if (!neverExcludeTerms.has(norm(term)) && (conversions > 0 || cost >= minCostForNeg || impressions >= 50)) {
            manualReviewUnknownStatus.push({
                ...termData,
                note: 'manual_status_resolution_required'
            });
        }
        continue;
    }

    // Only status=none is eligible for auto actions in SOP 1
    if (status !== 'none') continue;

    // alwaysInclude: force promotion regardless of metrics (if not already a keyword in this ad group)
    if (alwaysIncludeTerms.has(norm(term)) && !addedInAdGroup) {
        promotionCandidates.push({ ...termData, note: 'always_include_protected' });
        continue;
    }

    if (conversions > 0) {
        // Potential promotion candidate OR inefficient term
        // Use per-campaign strategy + target for classification
        let isInefficient = false;
        let inefficientNote = '';
        const meetsMinimums = cost >= minCostForInefficient && clicks >= minClicksForInefficient;

        if (termStrategy === 'roas' && termTarget) {
            const roasCutoff = termTarget * inefficientROASMultiplier;
            isInefficient = meetsMinimums && roas !== null && roas < roasCutoff;
            inefficientNote = `inefficient_roas_${roas !== null ? roas.toFixed(2) : '?'}_below_${roasCutoff.toFixed(2)}`;
        } else if (termStrategy === 'cpa' && termTarget) {
            const cpaCutoff = termTarget * inefficientCPAMultiplier;
            isInefficient = meetsMinimums && cpa > cpaCutoff;
            inefficientNote = `inefficient_cpa_above_${inefficientCPAMultiplier}x_target`;
        }

        const withinTarget = termStrategy === 'roas'
            ? (termTarget === null || (roas !== null && roas >= termTarget))
            : (termTarget === null || cpa <= termTarget);

        if (!addedInAdGroup && isInefficient) {
            inefficientCandidates.push({ ...termData, note: inefficientNote });
        } else if (!addedInAdGroup && (withinTarget || termTarget === null)) {
            promotionCandidates.push(termData);
        } else if (!addedInAdGroup) {
            // Converting above target but below inefficiency threshold, or not enough data
            monitor.push({ ...termData, note: 'converting_above_target' });
        }
    } else if (cost >= minCostForNeg) {
        // Non-converting high-cost — date range already pre-shifted by conversionLagDays
        if (neverExcludeTerms.has(norm(term))) {
            // Protected term — never classify as a negative
        } else {
            irrelevantCandidates.push(termData);
        }
    } else if (impressions >= 50) {
        // Low spend, some volume — monitor
        monitor.push(termData);
    }
}

// Filter out known-relevant terms from irrelevant candidates (self-learning)
const preFilterIrrelevantCount = irrelevantCandidates.length;
const filteredIrrelevants = knownRelevantSet.size > 0
    ? irrelevantCandidates.filter(t => !knownRelevantSet.has(t.term.toLowerCase()))
    : irrelevantCandidates;
const knownRelevantFiltered = preFilterIrrelevantCount - filteredIrrelevants.length;

// Sort and cap buckets
filteredIrrelevants.sort((a, b) => b.cost - a.cost);
const cappedIrrelevants = filteredIrrelevants.slice(0, 150);

inefficientCandidates.sort((a, b) => b.cost - a.cost);
const cappedInefficient = inefficientCandidates.slice(0, 100);

promotionCandidates.sort((a, b) => b.conversions - a.conversions);

monitor.sort((a, b) => b.impressions - a.impressions);
const cappedMonitor = monitor.slice(0, 30);

manualReviewUnknownStatus.sort((a, b) => b.cost - a.cost);
const cappedManualReviewUnknownStatus = manualReviewUnknownStatus.slice(0, 100);

// Build output
const summary = {
    meta: {
        generatedAt: new Date().toISOString(),
        totalInputTerms: searchTerms.length,
        campaignFilter: campaignFilter || null,
        dataAgeDays,
        conversionLagDays,
        currency,
        currencySymbol,
        targetCPA,
        maxCPA,
        targetROAS,
        thresholds: {
            minCostForNeg,
            conversionLagDays,
            excludeBranded,
            biddingStrategyType,
            inefficientCPAMultiplier,
            inefficientCPACutoff: biddingStrategyType === 'cpa' && effectiveCPA ? effectiveCPA * inefficientCPAMultiplier : null,
            inefficientROASMultiplier,
            inefficientROASCutoff: biddingStrategyType === 'roas' && targetROAS ? targetROAS * inefficientROASMultiplier : null,
            minCostForInefficient,
            minClicksForInefficient
        },
        negativeStatus: {
            available: negatives.available,
            source: negatives.source,
            linkAwareShared: negatives.linkAwareShared || false,
            warnings: negatives.warnings || []
        },
        campaignTypeBreakdown: typeBreakdown,
        counts: {
            promotionCandidates: promotionCandidates.length,
            irrelevantCandidates: filteredIrrelevants.length,
            irrelevantCapped: cappedIrrelevants.length,
            knownRelevantFiltered,
            manualReviewUnknownStatus: manualReviewUnknownStatus.length,
            manualReviewUnknownStatusCapped: cappedManualReviewUnknownStatus.length,
            inefficientCandidates: inefficientCandidates.length,
            inefficientCapped: cappedInefficient.length,
            monitor: monitor.length,
            monitorCapped: cappedMonitor.length,
            pmaxShopping: pmaxShoppingCount
        }
    },
    promotion_candidates: promotionCandidates,
    inefficient_candidates: cappedInefficient,
    irrelevant_candidates: cappedIrrelevants,
    manual_review_unknown_status: cappedManualReviewUnknownStatus,
    monitor: cappedMonitor,
    pmax_shopping_summary: {
        termCount: pmaxShoppingCount,
        totalCost: Math.round(pmaxShoppingCost * 100) / 100,
        campaigns: Array.from(pmaxShoppingCampaigns)
    },
    pmax_monitor: pmaxMonitor.sort((a, b) => b.impressions - a.impressions).slice(0, 50)
};

// Ensure output directory exists
const outputDir = dirname(outputPath);
if (!existsSync(outputDir)) {
    mkdirSync(outputDir, { recursive: true });
}

writeFileSync(outputPath, JSON.stringify(summary, null, 2), 'utf8');

console.log(`✓ Analysis summary written to: ${outputPath}`);
console.log(`  Terms processed: ${searchTerms.length}`);
console.log(`  Promotion candidates: ${promotionCandidates.length}`);
const ineffLabel = biddingStrategyType === 'roas'
    ? `ROAS < ${targetROAS ? (targetROAS * inefficientROASMultiplier).toFixed(2) : '?'}`
    : `CPA > ${currencySymbol}${effectiveCPA ? effectiveCPA * inefficientCPAMultiplier : '?'}`;
console.log(`  Inefficient candidates: ${cappedInefficient.length} (of ${inefficientCandidates.length} total, ${ineffLabel}, cost >= ${currencySymbol}${minCostForInefficient}, clicks >= ${minClicksForInefficient})`);
console.log(`  Irrelevant candidates: ${cappedIrrelevants.length} (of ${filteredIrrelevants.length} total, capped at 150)${knownRelevantFiltered > 0 ? ` [${knownRelevantFiltered} filtered by decisions file]` : ''}`);
console.log(`  Unknown status (manual review): ${cappedManualReviewUnknownStatus.length} (of ${manualReviewUnknownStatus.length} total)`);
console.log(`  Monitor: ${cappedMonitor.length} (of ${monitor.length} total, capped at 30)`);
console.log(`  PMax/Shopping terms: ${pmaxShoppingCount} (excluded from SOP 1/2)`);
console.log(`  PMax monitor (0-conv, 50+ impr): ${pmaxMonitor.length}`);

// --- Export CSVs (--export flag) ---
if (exportFlag) {
    const exportDir = resolve(_projectRoot, 'created/search-terms');
    if (!existsSync(exportDir)) mkdirSync(exportDir, { recursive: true });

    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    const ts = `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}_${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}${pad(now.getUTCSeconds())}`;

    // Support array or string for primary shared list (backward-compatible)
    const rawPrimary = sta.sharedNegativeLists?.primary || 'Search Term Exclusions';
    const primaryLists = Array.isArray(rawPrimary) ? rawPrimary : [rawPrimary];
    const sharedListName = primaryLists[0]; // Default export target is first list
    const matchType = sta.negativeMatchType || 'Phrase';

    // File 1: Account-level negatives (irr_candidates → shared list)
    if (cappedIrrelevants.length > 0) {
        const rows = cappedIrrelevants.map(t => `"${sharedListName}","${t.term}","${matchType}"`);
        const csv = ['Shared Set,Keyword,Match Type', ...rows].join('\n');
        const file = resolve(exportDir, `${ts}_account_negatives.csv`);
        writeFileSync(file, csv, 'utf8');
        console.log(`  ✓ Account negatives: created/search-terms/${ts}_account_negatives.csv (${cappedIrrelevants.length} terms)`);
    } else {
        console.log(`  — Account negatives: skipped (0 confirmed irrelevant terms)`);
    }

    // File 2: PMax monitor negatives (0-conv, 50+ impr — for human review before import)
    if (pmaxMonitor.length > 0) {
        const pmaxCampName = Array.from(pmaxShoppingCampaigns).find(n => /performance max/i.test(n)) || Array.from(pmaxShoppingCampaigns)[0] || 'Performance Max';
        const rows = pmaxMonitor.map(t => `"${pmaxCampName}","${t.term}","${matchType}"`);
        const csv = ['Campaign,Keyword,Match Type', ...rows].join('\n');
        const file = resolve(exportDir, `${ts}_pmax_monitor_negatives.csv`);
        writeFileSync(file, csv, 'utf8');
        console.log(`  ✓ PMax monitor negatives: created/search-terms/${ts}_pmax_monitor_negatives.csv (${pmaxMonitor.length} terms — review before importing)`);
    }
}
