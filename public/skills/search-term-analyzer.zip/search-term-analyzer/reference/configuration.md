# Configuration Reference

Full configuration options for the Search Term Analyzer skill. Add to `config/ads-context.config.json`.

> **Note:** Target CPA and ROAS live in `context/business.md`, not here. This file is for thresholds and operational settings only.
>
> **Currency:** Set `googleAds.currency` in the config (e.g., `"EUR"`, `"GBP"`, `"USD"`). Scripts use it for display formatting. Defaults to `"USD"` if not set.

---

## Full Configuration Example

```json
"searchTermAnalysis": {
  "minCostForNegativeConsideration": 20,
  "conversionLagDays": 14,
  "excludeBrandedCampaigns": true,
  "brandedCampaigns": ["1.0 Plus AI | Search | Branded"],
  "existingNegativesExport": null,
  "defaultMatchTypeForNegatives": "Phrase",
  "sharedNegativeLists": {
    "primary": "Search Term Exclusions",
    "ngramNonConverting": "Non-Converting N-grams",
    "ngramInefficient": "Inefficient N-grams"
  },
  "protectedTerms": {
    "alwaysInclude": [],
    "neverExclude": []
  }
},

"ngramAnalysis": {
  "minImpressions": 100,
  "minClicks": 25,
  "minDistinctTerms": 3,
  "biddingStrategyType": "cpa",
  "defaultAOV": 200,
  "nonConvertingCostMultiplier": 2.0,
  "inefficientCPAMultiplier": 1.75,
  "inefficientROASMultiplier": 0.7,
  "additionalStopwords": []
}
```

---

## Configuration Settings Reference

### searchTermAnalysis

| Setting | Default | Description |
|---------|---------|-------------|
| `minCostForNegativeConsideration` | 20 | Minimum $ spend for a zero-conv term to be flagged as negative candidate |
| `conversionLagDays` | 14 | Days to shift query date range back (applied at query time via `--lag-offset`) |
| `excludeBrandedCampaigns` | true | Skip campaigns with "Branded" in the name |
| `brandedCampaigns` | [] | Campaign names treated as branded (**case-insensitive exact match** — each full campaign name must be listed). When empty, falls back to regex: matches "Branded" in name but excludes "Non-Branded". |
| `existingNegativesExport` | null | Optional path to negative export CSV for status resolution (`none` vs `excluded`) |
| `defaultMatchTypeForNegatives` | "Phrase" | Default match type for individual negative exports |
| `sharedNegativeLists.primary` | "Search Term Exclusions" | Name of the main shared negative list. Supports an array of list names (e.g., `["List A", "List B"]`) — the first list is used as the default export target; all lists are checked for exclusion status. |
| `sharedNegativeLists.brand` | null | Optional shared list for brand/navigation negatives. When set, Claude routes brand-related irrelevant categories here instead of the primary list. |
| `sharedNegativeLists.ngramNonConverting` | "Non-Converting N-grams" | Shared list for SOP 3 non-converting n-grams |
| `sharedNegativeLists.ngramInefficient` | "Inefficient N-grams" | Shared list for SOP 3 inefficient n-grams (time-boxed experiment) |
| `protectedTerms.alwaysInclude` | [] | Terms that should always be added as keywords regardless of metrics |
| `protectedTerms.neverExclude` | [] | Terms that should never be added as negatives (brand terms, partner names) |

### ngramAnalysis

| Setting | Default | Description |
|---------|---------|-------------|
| `minImpressions` | 100 | Minimum impressions for an n-gram to be considered |
| `minClicks` | 25 | Minimum clicks for an n-gram to be considered |
| `minDistinctTerms` | 3 | N-gram must appear in at least N distinct search terms |
| `biddingStrategyType` | "cpa" | Classification mode: `"cpa"` or `"roas"` |
| `defaultAOV` | 0 | Fallback AOV for ROAS mode non-converting threshold when AOV can't be inferred |
| `nonConvertingCostMultiplier` | 2.0 | Cost must exceed targetCPA × this in `cpa` mode, or AOV × this in `roas` mode |
| `inefficientCPAMultiplier` | 1.75 | N-gram CPA must exceed targetCPA × this to qualify as inefficient |
| `inefficientROASMultiplier` | 0.7 | N-gram ROAS must be below targetROAS × this to qualify as inefficient |
| `additionalStopwords` | [] | Extra words to ignore during n-gram extraction (add industry terms here) |

---

## Notes

### Target CPA / ROAS

Do **not** put CPA or ROAS targets here. They belong in `context/business.md` under Performance Targets. Scripts read business.md directly to extract these values.

### Conversion Lag

With `conversionLagDays: 14`, the search terms query date range is shifted back by 14 days at query time (via `--lag-offset`). This means all returned data is already outside the conversion lag window — no per-term lag checking is needed in the analysis script. The `segments.date` column is not included in the query output.

### Status Resolution

SOP 1 uses derived status:
- `added_in_ad_group` from `(campaign, ad_group, term)` vs `keywords.csv`
- `excluded`/`none` from `existingNegativesExport` if provided
- `unknown` when no negative export source exists (goes to manual review bucket)

Only `status = none` terms are auto-classified into promotion/irrelevance outputs.

### Bidding Strategy Mode

Both `searchTermAnalysis.biddingStrategy` and `ngramAnalysis.biddingStrategy` serve as **fallback** values. The scripts first check `campaigns.csv` for each campaign's actual `campaign.bidding_strategy_type`, `campaign.target_cpa.target_cpa_micros`, and `campaign.maximize_conversion_value.target_roas`. When these fields are available (pulled by `/gads-context`), the per-campaign strategy and target are used automatically. The config value only applies when a campaign has no explicit target in the CSV.

For SOP 3 n-grams (which aggregate across campaigns), classification uses the **dominant campaign** (the campaign contributing the most cost to the n-gram) to determine which strategy and target to apply. Per-campaign breakdowns are included in the JSON output so Claude can review nuance during SOP 3.

`ngramAnalysis.biddingStrategyType` controls the fallback classification mode:
- `"cpa"`: uses CPA thresholds only
- `"roas"`: uses ROAS thresholds only; non-converting threshold uses inferred AOV or `defaultAOV`

### N-gram Stopwords

The script removes common English stop words by default. Use `additionalStopwords` to add industry-specific terms that commonly appear in both good and bad search terms and shouldn't seed n-gram clusters.

```json
"ngramAnalysis": {
  "additionalStopwords": ["presentation", "slide", "slides", "deck"]
}
```

### Shared Negative Lists

The three shared lists map to Google Ads Shared Negative Keyword Lists:
1. **Primary** — For individual irrelevant search terms (SOP 1)
2. **Non-Converting N-grams** — Annual review cycle
3. **Inefficient N-grams** — 6-12 month experiment, then reassess

---

## Example: Custom Stopwords for a SaaS Presentation Tool

```json
"ngramAnalysis": {
  "additionalStopwords": [
    "presentation", "slide", "slides", "deck", "powerpoint", "keynote"
  ]
}
```

This prevents product category terms from being treated as meaningful n-gram signals.

---

## Self-Learning Decisions File

**File:** `context/analysis/search-term-decisions.json`

This file stores user decisions from previous analysis runs. It is **not** part of `ads-context.config.json` to avoid bloating the config with potentially 100+ terms over time.

```json
{
  "relevantTerms": ["term1", "term2"],
  "rejectedNgrams": ["ngram1", "ngram2"],
  "updatedAt": "2026-02-20"
}
```

| Field | Used By | Effect |
|-------|---------|--------|
| `relevantTerms` | `analyze-terms.js` | Filtered from `irrelevant_candidates` before output (case-insensitive match) |
| `rejectedNgrams` | `ngram-analysis.js` | Filtered from non-converting and inefficient n-gram candidates (case-insensitive match) |

The file is created/updated by Claude during Phase 6 when the user marks terms as relevant or rejects proposed n-grams. Counts of filtered items appear in the JSON meta output (`knownRelevantFiltered`, `rejectedNgramsFiltered`).
