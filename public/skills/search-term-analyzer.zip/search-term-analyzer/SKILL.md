---
name: search-term-analyzer
description: "Analyze Google Ads search terms and categorize them into actionable recommendations: add as keywords, exclude as negatives, or flag for review. Three-SOP workflow covering irrelevance scan, promotion evaluation, and n-gram analysis."
version: 1.0
---

# Search Term Analyzer

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

Three-SOP workflow for turning search term data into action:

1. **SOP 1 (analyze)** - Irrelevance scan: discovers irrelevant categories, surfaces promotion candidates
2. **SOP 2 (promote)** - Promotion evaluation: applies 3-step decision tree per candidate
3. **SOP 3 (ngrams)** - N-gram analysis: finds shared word patterns for Phrase match exclusions

Heavy data processing is handled by Node.js scripts. The AI receives compact JSON summaries (~50-200 items), never raw CSV rows.

## Command Format

```
/search-terms                          # Default: runs SOP 1 (analyze)
/search-terms analyze [--campaign X]   # SOP 1: irrelevance scan
/search-terms promote [--campaign X]   # SOP 2: evaluate promotion candidates from log
/search-terms ngrams  [--campaign X]   # SOP 3: n-gram analysis
```

## Required Data Files

The user must provide these CSV files in their project:

| File | Required | Purpose |
|------|----------|---------|
| `data/search-terms.csv` | Yes | Primary analysis data |
| `data/keywords.csv` | Yes (SOP 1+2) | Duplicate detection, protected terms |
| `data/campaigns.csv` | Recommended | Campaign type routing |
| `data/ads.csv` | SOP 2 | Ad fit check |
| `data/negative-keywords-campaign.csv` | Recommended | Campaign-level negatives for status resolution |
| `data/negative-keywords-adgroup.csv` | Recommended | Ad group-level negatives |
| `data/negative-keywords-shared.csv` | Recommended | Shared list negatives |
| `context/business.md` | Recommended | CPA/ROAS targets |
| `context/analysis/search-term-log.md` | SOP 2 | Pending promotion candidates |
| `config/ads-context.config.json` | Recommended | Thresholds and shared list names |

## Process

### Phase 0: Prerequisites & Route

1. Parse subcommand and flags
2. Load config from `config/ads-context.config.json`
3. Load `context/business.md` for CPA/ROAS targets
4. Load `context/analysis/search-term-log.md` if exists

### Phase 1: Run Data Script

**[analyze]:**
```bash
node scripts/analyze-terms.js [--campaign="X"] --output=tmp/analysis-summary.json
```

**[ngrams]:**
```bash
node scripts/ngram-analysis.js [--campaign="X"] --output=tmp/ngram-summary.json
```

**[promote]:** No script needed. Read `context/analysis/search-term-log.md` directly.

### Phase 2: SOP Execution

**[analyze]** - Read `reference/sop1-irrelevance-criteria.md`, then:
1. Scan irrelevant_candidates, discover categories dynamically
2. Verify each category against business context
3. Run protected terms safeguard
4. Surface promotion_candidates for SOP 2 queue

**[promote]** - Read `reference/sop2-promotion-decision-tree.md`, then evaluate each candidate:
1. Close variant check -> SKIP if covered
2. Ad fit check -> SPLIT-AND-ROUTE if wrong ad group
3. Promotion value check -> PROMOTE (Exact) if value confirmed

**[ngrams]** - Read `reference/sop3-ngram-methodology.md`, then:
1. Review safe_list_conflicts
2. Validate non_converting n-grams
3. Validate inefficient n-grams
4. Assign accepted n-grams to appropriate shared list

### Phase 3: Update Analysis Log

Append timestamped run entry to `context/analysis/search-term-log.md`.

### Phase 4: Generate Report

Write `context/analysis/search-term-analysis.md`. See `reference/report-templates.md` for template.

### Phase 5: Export CSV

Generate all CSV outputs. See `reference/export-formats.md` for format specs. Write to `created/search-terms/`.

### Phase 6: Summary

Present key findings, decisions made, output files, and recommended next action.

## Key Rules (Never Break)

1. **NEVER negate a converting search term** - metrics override intent
2. **Close variants = skip** - don't promote if already covered
3. **N-gram exclusions use Phrase match only**
4. **Negatives don't match close variants** - add singular/plural manually
5. **Dynamic categories only** - no hardcoded irrelevant word lists
6. **Two separate N-gram lists** - non-converting (annual) vs inefficient (6-12 month experiment)

## Campaign Type Treatment

| Type | SOP 1 | SOP 2 | SOP 3 |
|------|-------|-------|-------|
| SEARCH | Full | Full | Full |
| PMAX (MULTI_CHANNEL) | Skip* | Skip* | Full |
| SHOPPING | Skip | Skip | Full |
| DISPLAY / VIDEO | Skip | Skip | Skip |

*PMax terms with 0 conversions and 50+ impressions captured for campaign-level negative review.
