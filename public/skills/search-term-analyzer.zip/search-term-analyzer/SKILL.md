---
name: search-term-analyzer
description: |
  Analyze search terms and categorize them into actionable recommendations: add as keywords, exclude as negatives, or flag for review.
  AUTO-ACTIVATE for: "analyze search terms", "search term analysis", "find negative keywords",
  "find new keywords", "keyword opportunities", "wasted spend", "search term recommendations".
  Also triggered by /search-terms command.
---

# Search Term Analyzer Skill

Three-SOP workflow for turning search term data into action:

1. **SOP 1 (analyze)** — Irrelevance scan: discovers irrelevant categories, surfaces promotion candidates
2. **SOP 2 (promote)** — Promotion evaluation: applies 3-step decision tree per candidate
3. **SOP 3 (ngrams)** — N-gram analysis: finds shared word patterns for Phrase match exclusions

**Scale:** Heavy data processing handled by Node.js scripts. Claude receives compact JSON summaries (~50-200 items), never raw CSV rows.

## Command Format

```
/search-terms                          # Default: runs SOP 1 (analyze), asks for lookback period
/search-terms analyze [--campaign X]   # SOP 1: asks lookback, pulls data, irrelevance scan
/search-terms promote [--campaign X]   # SOP 2: evaluate promotion candidates from log (no data pull)
/search-terms ngrams  [--campaign X]   # SOP 3: asks lookback (longer), pulls data, n-gram analysis
```

**Examples:**
- `/search-terms` — Full SOP 1 analysis
- `/search-terms analyze --campaign "Non-Branded - US"` — Specific campaign
- `/search-terms promote` — Evaluate all pending promotion candidates from log
- `/search-terms ngrams` — N-gram analysis + CSV exports

---

## Data Sources

| File | Required | Purpose |
|------|----------|---------|
| `ppcos/client-example/context/google-ads/data/search-terms.csv` | Yes | Primary analysis data (date range pre-shifted by conversionLagDays at query time) |
| `ppcos/client-example/context/google-ads/data/keywords.csv` | Yes (SOP 1+2) | Duplicate detection, protected terms |
| `ppcos/client-example/context/google-ads/data/campaigns.csv` | Recommended | Campaign type routing |
| `ppcos/client-example/context/google-ads/data/ads.csv` | SOP 2 | Ad fit check |
| `ppcos/client-example/context/google-ads/data/negative-keywords-campaign.csv` | Recommended | Campaign-level negatives for status resolution (auto-pulled by `/gads-context`) |
| `ppcos/client-example/context/google-ads/data/negative-keywords-adgroup.csv` | Recommended | Ad group-level negatives for status resolution (auto-pulled by `/gads-context`) |
| `ppcos/client-example/context/google-ads/data/negative-keywords-shared.csv` | Recommended | Shared list negatives for status resolution (auto-pulled by `/gads-context`) |
| `ppcos/client-example/context/google-ads/data/negative-keywords-shared-links.csv` | Recommended | Shared list campaign linkage for scope-aware exclusion checks |
| `ppcos/client-example/context/business.md` | Recommended | CPA/ROAS targets |
| `ppcos/client-example/context/analysis/search-term-log.md` | SOP 2 | Pending promotion candidates |
| `ppcos/client-example/config/ads-context.config.json` | Recommended | Thresholds and shared list names |

**Inline data pulling:** SOP 1 and SOP 3 pull search term data directly using `query.js` — no need to run `/gads-context` first. The user chooses a lookback period before pulling. SOP 2 reads from the log only.

---

## Campaign Type Treatment

Scripts route terms by `campaign.advertising_channel_type`. The API returns **numeric codes** (mapped to names internally):

| API Code | Name | SOP 1 | SOP 2 | SOP 3 |
|----------|------|-------|-------|-------|
| 2 | SEARCH | ✓ Full | ✓ Full | ✓ |
| 10 | MULTI_CHANNEL (PMax) | Skip* | Skip* | ✓ |
| 4 | SHOPPING | Skip | Skip | ✓ |
| 3/6 | DISPLAY / VIDEO | Skip | Skip | Skip |

*PMax terms with 0 conversions and 50+ impressions are captured in `pmax_monitor` for campaign-level negative review.

## Branded vs Non-Branded

Set `excludeBrandedCampaigns: true` in config to skip branded campaigns from SOP 1/2 analysis.

**Always use the explicit list (failsafe):** Add the full campaign names to `brandedCampaigns` in config (not substrings — each entry must be the complete campaign name):

```json
"searchTermAnalysis": {
  "excludeBrandedCampaigns": true,
  "brandedCampaigns": [
    "1.0 Plus AI | Search | Branded"
  ]
}
```

The script matches on exact name (case-insensitive). If `brandedCampaigns` is empty, it falls back to a name-pattern check (`/branded/i` but NOT `/non-branded/i`), but the explicit list is always preferred.

**When onboarding a new account:** run `/gads-context` first, check `ppcos/client-example/context/google-ads/campaigns.md` for branded campaign names, then add them to `brandedCampaigns`.

---

## Process

---

### Phase 0: Prerequisites & Route

1. **Parse subcommand and flags** — determine which SOP to run
2. **Load config** — read `ppcos/client-example/config/ads-context.config.json`, extract:
   - `googleAds.customerId` and `googleAds.loginCustomerId` (required for data pull)
   - `searchTermAnalysis.conversionLagDays` (for `--lag-offset`)
   - Display active thresholds table:

```
Active Thresholds:
  Min cost for negative consideration: $X
  Conversion lag offset: X days (applied at query time)
  Exclude branded campaigns: Yes/No
  SOP 3 bidding strategy: cpa/roas
  N-gram min impressions: X
  N-gram min clicks: X
  N-gram min distinct terms: X
```

3. **Load business.md** — extract CPA target, ROAS target
4. **Load search-term-log.md** if exists (prior run context for known categories)

---

### Phase 0.5: Lookback Period & Data Pull [SOP 1 + SOP 3 only]

**Skip this phase entirely for SOP 2 (promote)** — SOP 2 reads from `ppcos/client-example/context/analysis/search-term-log.md` only and does not need fresh CSV data.

#### Step 1: Ask Lookback Period

**[analyze / default]:**

**Question:** "What lookback period should I use for search term data?"

| Option | Description |
|--------|-------------|
| 30 days | Short window. Good for frequent reviews or low-volume accounts |
| 60 days (Recommended) | Standard analysis window. Enough data for pattern detection |
| 90 days | Extended window. Better for lower-volume campaigns |

Use AskUserQuestion with these 3 options. multiSelect: false.

If the user selects "Other", ask for a number of days (minimum 7, maximum 365).

**[ngrams]:**

**Question:** "What lookback period should I use for n-gram analysis? (Longer periods give more reliable pattern data)"

| Option | Description |
|--------|-------------|
| 90 days | Minimum recommended for n-grams. Use for high-volume accounts |
| 120 days (Recommended) | Standard n-gram window. Good balance of data volume and recency |
| 180 days | Extended window. Better for medium-volume accounts |

Use AskUserQuestion with these 3 options. multiSelect: false.

If the user selects "Other", ask for a number of days (minimum 30, maximum 730).

**Note:** 30 days is intentionally not offered for n-grams because n-gram analysis requires sufficient volume to detect meaningful word-level patterns. Short windows produce noisy, unreliable n-gram candidates.

#### Step 2: Pull Data

After the user selects a lookback period, pull the required data files. Use `query.js` from the gads-context skill.

Read the config values:
- `customerId` from `config.googleAds.customerId`
- `loginCustomerId` from `config.googleAds.loginCustomerId`
- `conversionLagDays` from `config.searchTermAnalysis.conversionLagDays` (default: 14)

**Create data directory if needed:**

```bash
mkdir -p ppcos/client-example/context/google-ads/data
```

**Pull search-terms.csv** (required for both SOP 1 and SOP 3):

```bash
node .claude/skills/gads-context/scripts/query.js \
  --customer-id={customerId} \
  --login-customer-id={loginCustomerId} \
  --query="$(cat .claude/skills/gads-context/references/search-terms.gaql)" \
  --days={userSelectedDays} \
  --lag-offset={conversionLagDays} \
  --output=ppcos/client-example/context/google-ads/data/search-terms.csv
```

**Pull keywords.csv** (required for SOP 1 duplicate detection):

```bash
node .claude/skills/gads-context/scripts/query.js \
  --customer-id={customerId} \
  --login-customer-id={loginCustomerId} \
  --query="$(cat .claude/skills/gads-context/references/keywords.gaql)" \
  --days={userSelectedDays} \
  --output=ppcos/client-example/context/google-ads/data/keywords.csv
```

**Pull campaigns.csv** (needed for campaign type routing and bidding strategy):

```bash
node .claude/skills/gads-context/scripts/query.js \
  --customer-id={customerId} \
  --login-customer-id={loginCustomerId} \
  --query="$(cat .claude/skills/gads-context/references/campaigns.gaql)" \
  --days={userSelectedDays} \
  --output=ppcos/client-example/context/google-ads/data/campaigns.csv
```

**Note:** `--lag-offset` is only applied to search-terms.csv (not keywords or campaigns). Negative keyword files are NOT re-pulled here — they are current-state snapshots pulled by `/gads-context`. If negative keyword CSVs are missing, log a warning but continue (the analyze script handles this gracefully via the `manual_review_unknown_status` bucket).

#### Step 3: Confirm Data Pull

After all queries complete, display a summary:

```
Data Pulled:
| File             | Rows | Lookback | Lag Offset |
|------------------|------|----------|------------|
| search-terms.csv | {n}  | {days}d  | {lag}d     |
| keywords.csv     | {n}  | {days}d  | —          |
| campaigns.csv    | {n}  | {days}d  | —          |

Proceeding to analysis...
```

If any query fails, show the error and suggest checking `ppcos/client-example/config/.env` credentials or running `npm install` in `.claude/skills/gads-context/scripts/`. If packages are missing just install them. 

---

### Phase 1: Run Data Script

**[analyze / default]:**

```bash
node .claude/skills/search-term-analyzer/scripts/analyze-terms.js \
  [--campaign="X"] \
  --output=.claude/skills/search-term-analyzer/tmp/analysis-summary.json
```

CSVs are always generated on every run.

Read `tmp/analysis-summary.json` — confirm counts look reasonable before proceeding:
- `campaignTypeBreakdown` should show SEARCH terms from Non-Branded campaigns + MULTI_CHANNEL from PMax
- If MULTI_CHANNEL shows 0 and all candidates are from PMax campaign names → channel type mapping bug
- If SEARCH shows 0 and only PMax/Branded data → branded regex bug (see "Branded vs Non-Branded" section)
- Review `manual_review_unknown_status` bucket. Only `status = none` terms are auto-classified.

**[ngrams]:**

```bash
node .claude/skills/search-term-analyzer/scripts/ngram-analysis.js \
  [--campaign="X"] \
  --output=.claude/skills/search-term-analyzer/tmp/ngram-summary.json
```

Read `tmp/ngram-summary.json`
- Verify `meta.activeBiddingStrategy` matches config (`cpa` or `roas`)
- Use `meta.warnings` to catch missing threshold inputs (e.g., missing targetROAS/defaultAOV)

**[promote]:**

No script needed. Read `ppcos/client-example/context/analysis/search-term-log.md` directly to find pending SOP 2 candidates.

Also read:
- `ppcos/client-example/context/google-ads/data/keywords.csv` (close variant check)
- `ppcos/client-example/context/google-ads/data/ads.csv` (ad fit check)

---

### Phase 2: SOP Execution

**[analyze] → Read `reference/sop1-irrelevance-criteria.md`**

1. Scan `irrelevant_candidates` in JSON — discover categories dynamically
2. Verify each category against business context (business.md)
3. Run protected terms safeguard — flag conflicts
4. Surface `promotion_candidates` for SOP 2 queue
5. Handle `manual_review_unknown_status` separately (do not auto-apply)

**[promote] → Read `reference/sop2-promotion-decision-tree.md`**

For each pending candidate from the log:
1. Step 1: Close variant check → SKIP if covered
2. Step 2: Ad fit check → SPLIT-AND-ROUTE if wrong ad group
3. Step 3: Promotion value check → PROMOTE (Exact) if value confirmed

**[ngrams] → Read `reference/sop3-ngram-methodology.md`**

1. Review `safe_list_conflicts` — decide accept/reject for each
2. Validate `non_converting` n-grams — confirm each makes sense as an exclusion
3. Validate `inefficient` n-grams — note review date (6-12 months)
4. Assign accepted n-grams to the appropriate shared list

---

### Phase 3: Update Analysis Log

Append a timestamped run entry to `ppcos/client-example/context/analysis/search-term-log.md`.

Create the file if it doesn't exist with this header:
```markdown
# Search Term Analysis Log

Append-only log of all search term analysis runs.
Each run section records decisions made for audit and cross-run context.

---
```

Then append the run entry following the format in `reference/sop1-irrelevance-criteria.md` (SOP 1), `reference/sop2-promotion-decision-tree.md` (SOP 2), or `reference/sop3-ngram-methodology.md` (SOP 3).

---

### Phase 4: Generate Report

Write `ppcos/client-example/context/analysis/search-term-analysis.md`.

**For full template:** Read `reference/report-templates.md`

---

### Phase 5: Export CSV

Always generate all CSV outputs after every SOP run. Read `reference/export-formats.md` for all format specs.

| Subcommand | Script generates | Claude generates |
|------------|-----------------|-----------------|
| analyze | `{ts}_account_negatives.csv` (irr_candidates ≥ $20), `{ts}_pmax_monitor_negatives.csv` (PMax 0-conv 50+ impr) | `{ts}_campaign_negatives.csv` (campaign-level from Claude's category decisions), `{ts}_brand_negatives.csv` (brand/nav categories, if `sharedNegativeLists.brand` is configured) |
| promote | — | `{ts}_keyword_additions.csv` (Exact only, PROMOTE decisions) |
| ngrams | — | `{ts}_ngram_non_converting.csv`, `{ts}_ngram_inefficient.csv` |

**For Claude-generated CSVs:** write directly to `ppcos/client-example/created/search-terms/` using the format from `reference/export-formats.md`. Use timestamp format `YYYYMMDD_HHMMSS`.

Create `ppcos/client-example/created/search-terms/` directory if it doesn't exist.

---

### Phase 6: Summary

Present to user:
- Key findings from the SOP run
- Decisions made (counts by type)
- Output files created
- **Next recommended action:**
  - After analyze: "Run `/search-terms promote` to evaluate N promotion candidates"
  - After promote: "Run `/search-terms ngrams` to find phrase-level exclusion patterns"
  - After ngrams: "Schedule next N-gram run: [frequency recommendation]"

**Self-learning update:** After the user reviews the analysis and marks any terms as relevant (not irrelevant) or rejects proposed n-grams, offer to update `ppcos/client-example/context/analysis/search-term-decisions.json`. This file stores:
- `relevantTerms`: Search terms the user confirmed as relevant — these will be filtered from `irrelevant_candidates` in future runs
- `rejectedNgrams`: N-grams the user rejected — these will be filtered from n-gram candidates in future runs
- `updatedAt`: Timestamp of last update

If the file doesn't exist yet, create it. If it exists, merge new entries (don't overwrite existing ones).

---

## Error Handling

| Error | Message |
|-------|---------|
| Missing Google Ads config | "Account configuration not found. Add `googleAds.customerId` and `googleAds.loginCustomerId` to `ppcos/client-example/config/ads-context.config.json`." |
| Data pull fails | Show query.js error output. "Check credentials in `ppcos/client-example/config/.env` and run `npm install` in `.claude/skills/gads-context/scripts/`." |
| Missing negative keyword CSVs | Warning only, not blocking. "Negative keyword data not found. Status resolution will use `manual_review_unknown_status` bucket. Run `/gads-context` once to pull negative keyword data for full status resolution." |
| Script not found | "Script not found. Run `npm install` in `.claude/skills/search-term-analyzer/scripts/`" |
| Script exits with error | Show script error output. Check node/npm are installed. |
| No log entries (promote) | "No pending promotion candidates found in search-term-log.md. Run `/search-terms analyze` first." |
| Campaign not found | "Campaign '[name]' not found. Available campaigns: [list from CSV]" |

---

## Integration Points

### Uses (reads from):
- `ppcos/client-example/context/google-ads/data/search-terms.csv`
- `ppcos/client-example/context/google-ads/data/keywords.csv`
- `ppcos/client-example/context/google-ads/data/campaigns.csv`
- `ppcos/client-example/context/google-ads/data/ads.csv`
- `ppcos/client-example/context/business.md`
- `ppcos/client-example/context/analysis/search-term-log.md`
- `ppcos/client-example/context/analysis/search-term-decisions.json` (self-learning: terms/n-grams to skip)
- `ppcos/client-example/config/ads-context.config.json`
- `.claude/skills/gads-context/scripts/query.js` (data pulling)
- `.claude/skills/gads-context/references/search-terms.gaql`
- `.claude/skills/gads-context/references/keywords.gaql`
- `.claude/skills/gads-context/references/campaigns.gaql`

### Produces (writes to):
- `ppcos/client-example/context/analysis/search-term-analysis.md` — Full analysis report
- `ppcos/client-example/context/analysis/search-term-log.md` — Persistent analysis log (append-only)
- `.claude/skills/search-term-analyzer/tmp/analysis-summary.json` — Script output (ephemeral)
- `.claude/skills/search-term-analyzer/tmp/ngram-summary.json` — Script output (ephemeral)
- `ppcos/client-example/created/search-terms/*.csv` — Export files (if --export)

### Related Skills:
- `/gads-context` — Pull full account data including negative keywords, ads, and conversions (search terms, keywords, and campaigns are now pulled inline)
- `/qs-ad-relevance` — Investigate ad relevance issues surfaced in report
- `/qs-landing-page` — Investigate conversion issues for terms above CPA target
- `/offer-angles` — Review message angle coverage for misaligned terms

---

## Key Rules (Never Break)

1. **NEVER negate a converting search term** — metrics override intent, always
2. **Close variants = skip** — don't promote if already covered by an existing keyword
3. **N-gram exclusions use Phrase match only** — avoids over-exclusion
4. **Negatives don't match close variants** — add singular/plural manually in exports
5. **Dynamic categories only** — no hardcoded irrelevant word lists; discover from data and business context
6. **Two separate N-gram lists** — non-converting (annual) vs inefficient (6-12 month experiment)
7. **Lag protection** — handled at query time by shifting the date range back by `conversionLagDays` via `--lag-offset`; all returned data is already outside the lag window
