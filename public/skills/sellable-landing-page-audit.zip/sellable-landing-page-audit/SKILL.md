---
name: landing-page-audit
description: "Audit a client's landing page against CRO best practices. Produces a scored evaluation report with prioritized fixes, friction analysis, and optional blueprint. Use when user mentions auditing a landing page, user asks to review a page, or user says check conversion issues."
version: 1.0
last_updated: 2026-02-28
members: true
---

# Landing Page Audit Skill

Systematic, research-backed audit of landing pages receiving paid traffic. Produces a professional report with scoring, prioritized fixes, and actionable recommendations.

## Trigger

- User mentions auditing a landing page, reviewing conversion, or checking a page
- User provides a URL and asks for feedback on a landing page
- User says "landing page audit" or "audit this page"

## Step 0: Gather Required Information

**IMPORTANT:** Before starting, use AskUserQuestion to collect:

### 0a: Get the URL

First, ask how the user wants to provide a URL:

**Use AskUserQuestion with these options:**
- **"Enter my own URL"** - User has a specific page to audit
- **"Use a demonstration URL"** - Show 5 random example URLs from the test set

**If user chooses "Use a demonstration URL":**
1. Read `references/demo-urls.md` in this skill folder
2. Show all 5 demo URLs using AskUserQuestion with the industry as the label and the URL as the description
3. Let the user pick one
4. **Set `DEMO_MODE = true`** - This enables use of pre-cached data (see below)

### 0b: Collect remaining info

After the URL is determined, collect:
1. **Prepared by name** - What name/brand should appear on the report? (e.g., "Your Agency Name" or your personal name)
2. **What action should visitors take?** - Form submission, phone call, purchase, etc.
3. **Any ad copy running to this page?** - For message match analysis (optional, can skip)

These are the minimum required inputs. Do NOT assume or skip these questions.

## Step 1: Capture Screenshots

### Demo Mode (if DEMO_MODE = true)

If using a demonstration URL, screenshots are **pre-cached** in `cache/`. Use AskUserQuestion to confirm:

> "This is a demo URL, so I have pre-captured screenshots ready. Do you want me to use these cached screenshots, or capture fresh ones?"

Options:
- **"Use cached screenshots (Recommended)"** - Use files from `cache/[name]-desktop.png` and `cache/[name]-mobile.png`
- **"Capture fresh screenshots"** - Run the normal screenshot process

If using cached screenshots, copy them to `/tmp/audit/screenshots/` before proceeding:
```bash
cp cache/[name]-desktop.png /tmp/audit/screenshots/desktop-fold.png
cp cache/[name]-mobile.png /tmp/audit/screenshots/mobile-fold.png
```

### Normal Mode

Use the screenshot script to capture desktop and mobile views:

```bash
node .claude/skills/landing-page-audit/scripts/screenshot.cjs [URL] --output /tmp/audit/screenshots
```

This captures:
- `desktop-fold.png` - Above-fold desktop (1440x900)
- `desktop-full.png` - Full page desktop (max 4000px height)
- `mobile-fold.png` - Above-fold mobile (375x812)
- `mobile-top.png` - Mobile top section (0-3000px)
- `mobile-bottom.png` - Mobile bottom section (3000-6000px)

**If the script fails**, use manual Playwright commands:
```bash
npx playwright screenshot [URL] /tmp/audit/screenshots/desktop-fold.png --viewport-size=1440,900
npx playwright screenshot [URL] /tmp/audit/screenshots/desktop-full.png --viewport-size=1440,4000
npx playwright screenshot [URL] /tmp/audit/screenshots/mobile-fold.png --viewport-size=375,812
```

After capturing, READ the screenshots to visually analyze the page.

**If the page is behind authentication or blocks bots:** Ask the user to provide screenshots manually (desktop and mobile). Use AskUserQuestion to request them. Skip the screenshot script and proceed with user-provided images.

## Step 2: Fetch and Analyze the Page

Use WebFetch to retrieve the actual page content:

```
WebFetch URL with prompt: "Extract all visible text content, headings, CTAs, form fields, trust signals, testimonials, and navigation structure from this page."
```

This gives you the content to score against the checklist.

**If WebFetch fails** (page blocks bots, requires auth, or returns incomplete content): Ask the user to paste the page text content, or provide a PDF/screenshot of the full page. Score based on whatever content is available and note any gaps in the report.

## Step 3: PageSpeed Insights

### Demo Mode (if DEMO_MODE = true)

If using a demonstration URL, PageSpeed data is **pre-cached** in `cache/demo-data.json`. Use AskUserQuestion to confirm:

> "Normally I'd ask you to run PageSpeed and give me these metrics, but since this is a demo, we've already fetched the performance data for this page. Would you like me to continue with the cached data?"

Options:
- **"Use cached PageSpeed data (Recommended)"** - Read metrics from `cache/demo-data.json` for this URL
- **"I'll provide fresh data"** - Run the normal PageSpeed process

If using cached data, read `cache/demo-data.json` and extract the `pagespeed` object for the selected URL.

### Normal Mode

**ALWAYS ask the user first.** Use AskUserQuestion with these options:

1. **"I'll paste the metrics"** - User will manually run PageSpeed and paste results
2. **"I'll paste a screenshot"** - User will share a screenshot of the results
3. **"Use the PageSpeed API"** - Auto-fetch (only works if API key is configured)
4. **"Skip PageSpeed"** - Continue without performance data

### If user chooses to paste metrics:

Tell them exactly what to do:
> Go to https://pagespeed.web.dev/ and enter the URL. Select **Mobile** view (top toggle).
>
> From the results, I need these **5 metrics** (all shown in the top section):
> - **Performance Score** (0-100, shown as a big number)
> - **FCP** (First Contentful Paint) - e.g., "1.8 s"
> - **LCP** (Largest Contentful Paint) - e.g., "2.5 s"
> - **TBT** (Total Blocking Time) - e.g., "200 ms"
> - **CLS** (Cumulative Layout Shift) - e.g., "0.1"
>
> You can also paste a screenshot of the results page instead.

### If user chooses to paste a screenshot:

Accept a screenshot of the PageSpeed results page. Read the image to extract the metrics.

### If user chooses to use the API:

Check if `PAGESPEED_API_KEY` is set in `.env`:

```bash
source .env 2>/dev/null
if [ -n "$PAGESPEED_API_KEY" ]; then
    curl -s "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=[URL]&strategy=mobile&category=performance&key=$PAGESPEED_API_KEY" | jq '{
      performance: (.lighthouseResult.categories.performance.score * 100 | floor),
      lcp: .lighthouseResult.audits["largest-contentful-paint"].displayValue,
      cls: .lighthouseResult.audits["cumulative-layout-shift"].displayValue,
      tbt: .lighthouseResult.audits["total-blocking-time"].displayValue,
      fcp: .lighthouseResult.audits["first-contentful-paint"].displayValue,
      si: .lighthouseResult.audits["speed-index"].displayValue
    }'
else
    echo "No PAGESPEED_API_KEY found in .env - ask user to paste metrics instead"
fi
```

### If user skips:

Note "PageSpeed data not provided" in the technical section and score conservatively (assume poor performance).

### PageSpeed Scoring Thresholds

| Metric | Good | Needs Improvement | Poor |
|--------|------|-------------------|------|
| LCP | ≤2.5s | 2.5-4s | >4s |
| CLS | ≤0.1 | 0.1-0.25 | >0.25 |
| TBT | ≤200ms | 200-600ms | >600ms |
| FCP | ≤1.8s | 1.8-3s | >3s |

## Step 4: Run the Audit

Score the page against the 4 categories defined in `references/scoring-criteria.md`:

| Category | Weight | Key Focus |
|----------|--------|-----------|
| 1. Message & Value Clarity | 30% | Headlines, value prop, ad match |
| 2. Call-to-Action & Forms | 20% | CTA clarity, form friction |
| 3. Technical Performance | 15% | Speed, Core Web Vitals, mobile |
| 4. Visual Design & UX | 10% | Hierarchy, whitespace, images |

**Scoring:** Each criterion scores 0-2:
- 0 = Missing or critically flawed
- 1 = Present but suboptimal
- 2 = Optimized / best practice

**Overall Score:** Weighted percentage mapped to 0-75:
- 85-100 (A): Excellent
- 70-84 (B): Good
- 55-69 (C): Fair
- 40-54 (D): Poor
- 0-39 (F): Critical

Use the detailed checklist in `references/audit-checklist.md` for the evaluation.

Run friction analysis using the framework in `references/friction-analysis.md` (visual, cognitive, emotional, technical friction).

Run mobile-specific checks using `references/mobile-audit.md`.

## Step 5: Prioritize Findings

Rank all issues by:
- **Impact** (1-5): How much does this hurt conversions?
- **Effort** (1-5): How easy is this to fix? (5 = easiest)
- **Priority = Impact x Effort** (highest number = fix first)

Create a prioritized list:
1. **Fix Now** (Priority 15-25)
2. **Fix Soon** (Priority 8-14)
3. **Fix Later** (Priority 3-7)
4. **Consider** (Priority 1-2)

## Step 6: Generate the Report

Generate a single HTML report using the design system in `template.css` and structure from `report-template.html`.

### 6a: Embed Screenshots

Convert the captured screenshots to base64 and embed them in the HTML:

```bash
# Convert screenshots to base64
DESKTOP_B64=$(base64 -i /tmp/audit/screenshots/desktop-fold.png)
MOBILE_B64=$(base64 -i /tmp/audit/screenshots/mobile-fold.png)
```

In the HTML, replace the screenshot placeholders:
- `[DESKTOP_SCREENSHOT_BASE64]` → `data:image/png;base64,{DESKTOP_B64}`
- `[MOBILE_SCREENSHOT_BASE64]` → `data:image/png;base64,{MOBILE_B64}`

### 6b: Generate the Blueprint Wireframe

Read `page-structure.md` for the recommended section template. Based on the audit findings:

1. **Customize the wireframe** - Fill in the placeholders with specific recommendations:
   - `[BLUEPRINT_HEADLINE]` → A better headline based on audit findings
   - `[BLUEPRINT_SUBHEADLINE]` → Supporting value prop
   - `[BLUEPRINT_PRIMARY_CTA]` → Recommended CTA text
   - etc.

2. **Section-by-section recommendations** - For each section in the blueprint:
   - What specifically to include
   - Copy suggestions
   - Visual/design guidance
   - Why this matters (tie back to audit findings)

3. **Developer handoff** - Practical build notes:
   - Build order (priority)
   - Technical requirements
   - Assets needed

### 6c: Report Structure

**IMPORTANT: ALL sections below are REQUIRED. Do not skip any section regardless of demo mode or data availability.**

The complete report includes these sections IN THIS ORDER:

**AUDIT SECTION:**
1. **Cover page** - Client name, URL, date, prepared by
2. **Executive Summary** - Score circle, grade, 2-3 sentence summary, critical issues vs strengths boxes
3. **Score Breakdown** - Table with all 4 category scores and visual bars
4. **Top 3 Priority Fixes** - Numbered list with problem/fix/effort/impact for each
5. **Detailed Category Scores** - All 4 categories with individual criterion scores (1.1, 1.2, etc.) and analysis paragraph for each
6. **Screenshots** - Desktop and mobile views side by side (base64 embedded)

**BLUEPRINT SECTION (ALL REQUIRED):**
7. **Wireframe Visual** - Visual mockup showing recommended page structure with labeled sections
8. **Section-by-Section Recommendations** - REQUIRED: Detailed guidance for EACH section (Hero, Problem/Pain, Solution, Benefits, How It Works, Social Proof, FAQ, Final CTA). Include specific copy suggestions.
9. **Developer Handoff** - REQUIRED: Build order (priority list), technical requirements, assets needed

**SUMMARY SECTION:**
10. **Recommendations Summary** - 3-column grid: Quick Wins, Medium Term, Consider Later
11. **Bottom Line** - Use `callout` class with summary assessment
12. **Next Steps** - Use `callout` class with numbered action items (make this stand out!)

**Formatting requirements:**
- Use `callout` class for Bottom Line and Next Steps to make them visually prominent
- All Blueprint sections must have specific, actionable recommendations (not generic placeholders)
- Developer Handoff must include actual build priorities and asset requirements

Save the HTML report to: `output/landing-page-audit-[client-name].html`

### 6d: Open in Browser

After saving the HTML report, open it in the user's default browser:

```bash
open output/landing-page-audit-[client-name].html
```

Tell the user the report is ready and has been opened in their browser.

**This completes the default audit workflow.** The HTML report is the primary deliverable - it's easy to view, share, and customize.

---

## Step 7: Generate PDF (Optional)

**Only run this step if the user explicitly requests a PDF.** By default, the HTML report is sufficient.

To convert the HTML report to PDF:

### 7a: Ensure PDF skill is installed

Check if the PDF generation skill exists:

```bash
ls .claude/skills/pdf/scripts/generate.cjs
```

**If the file does NOT exist**, copy it from the sellable services tools folder:

```bash
mkdir -p .claude/skills/pdf/scripts .claude/skills/pdf/assets
cp projects/sellable-services/tools/pdf/SKILL.md .claude/skills/pdf/SKILL.md
cp projects/sellable-services/tools/pdf/scripts/generate.cjs .claude/skills/pdf/scripts/generate.cjs
cp projects/sellable-services/tools/pdf/assets/* .claude/skills/pdf/assets/
```

The PDF skill requires the `ws` npm package. Check it's installed:
```bash
ls node_modules/ws/index.js || npm install ws
```

### 7b: Ask where to save the PDF

Use AskUserQuestion to ask:
- "Where would you like the PDF saved? Enter a folder path (e.g., ~/Desktop, ~/Documents, or any folder)."

Provide these options:
- `~/Desktop` (common on Mac)
- `~/Documents`
- Same folder as HTML (`output/`)

### 7c: Generate the PDF

```bash
node .claude/skills/pdf/scripts/generate.cjs output/landing-page-audit-[client-name].html [user-chosen-path]/landing-page-audit-[client-name].pdf
```

Confirm the PDF was saved successfully and tell the user the full file path.

---

## Step 8: Optional Video Walkthrough Script

If requested, generate a 10-15 minute video walkthrough script covering:
- Score overview (1 min)
- Top issues with screen references (5-8 min)
- Mobile review (2 min)
- Recommendations (2 min)
- Next steps (1 min)

## Key Statistics (for justifying recommendations)

- Headlines can impact conversions by up to 307%
- Pages loading in 1s convert 3x higher than 5s pages
- Reducing form fields from 11 to 4 = 120% more conversions
- Displaying reviews increases conversions up to 270%
- Personalized CTAs convert 202% better than generic
- 82.9% of landing page traffic is mobile
- Median conversion rate across industries: 6.6%

## Bundled Resources

| File | Purpose |
|------|---------|
| **`page-structure.md`** | **Editable page section template for blueprints** |
| `references/demo-urls.md` | 5 curated demo URLs (verified screenshot-compatible) |
| `cache/demo-data.json` | Pre-cached PageSpeed metrics and metadata for demo URLs |
| `cache/*.png` | Pre-captured screenshots for demo URLs (desktop + mobile) |
| `references/scoring-criteria.md` | Complete evaluation criteria with scoring guidance |
| `references/priorities.md` | Priority matrix and conversion killers |
| `references/industry-variations.md` | Industry-specific adaptations |
| `references/report-template.md` | Professional audit report structure |
| `references/research-sources.md` | Source citations for all statistics |
| `references/audit-checklist.md` | Full 50-point checklist |
| `references/discovery-questions.md` | Client intake questions |
| `references/friction-analysis.md` | Friction analysis framework |
| `references/mobile-audit.md` | Mobile-specific checks |
| `scripts/screenshot.cjs` | Automated screenshot capture |
| `template.css` | Report design system (includes wireframe styles) |
| `report-template.html` | Report HTML template (audit + blueprint + wireframe) |

## Output

**Default:**
- HTML audit report saved to `output/` folder and **opened in browser**
- Screenshots saved to `/tmp/audit/screenshots/`

**Optional (on request):**
- PDF audit report saved to user's chosen location
- Video walkthrough script (markdown)

## Dependencies

- **Playwright** - Required by `scripts/screenshot.cjs`. Installed at root `node_modules/`. If missing: `npm install playwright` from brain root.
- **ws** - Required by the PDF skill (Step 7). If missing: `npm install ws` from brain root.

## Notes

- PageSpeed Insights: Always ask user first - they can paste metrics, paste a screenshot, use the API (if configured), or skip
- Always check mobile - 83% of traffic is mobile
- Context matters for scoring - 3.8% conversion is good for SaaS, 8%+ expected for financial services
- Use industry-specific guidance from `references/industry-variations.md`
- Report should be written for non-technical clients

## Delivery

### Generate PDF
```bash
node sellable-services/11-services/tools/pdf/generate.cjs [input.html] [output.pdf]
```

### Delivery Process
See `sellable-services/11-services/tools/templates/client-delivery-guide.md` for:
- Pre-delivery quality checklist
- Email sending template
- Walkthrough call script
- Follow-up sequence

### HTML Template Reference
See `sellable-services/11-services/tools/templates/report-template.md` for the shared design system.
