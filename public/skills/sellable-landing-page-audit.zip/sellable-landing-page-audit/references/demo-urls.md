# Landing Page Audit Demo URLs

5 curated URLs verified to work with the screenshot tool. Diverse industries and geographies.

| # | URL | Industry | Geography |
|---|-----|----------|-----------|
| 1 | https://conqa.com/trial | Construction SaaS | Australia |
| 2 | https://lp.yellowfinrobotics.com/ | Drone cleaning/inspection | Australia |
| 3 | https://lp.otb.legal/schedule-your-appointment/ | Immigration law | UK |
| 4 | https://mhiroofing.com.au/get-a-quote-lp/ | Roofing | Australia |
| 5 | https://readingdermatology.co.uk/lp-book-a-consultation-skin-cancer-lm/ | Dermatology | UK |

*All URLs tested 2026-02-04 - screenshots work without bot protection issues.*
