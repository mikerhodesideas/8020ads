# Landing Page Audit Discovery Questions

Use these questions to gather everything needed before auditing. Can be sent as a form, asked on a call, or collected via email.

---

## Essential Questions (Must Have)

### 1. The Page

**What's the URL of the page you want audited?**
[Full URL]

**Are there additional pages you want reviewed?**
- [ ] Just this one page
- [ ] 2 pages (provide URLs)
- [ ] 3 pages (provide URLs)

**When was this page last updated?**
- [ ] Within the last month
- [ ] 1-6 months ago
- [ ] 6-12 months ago
- [ ] Over a year ago
- [ ] Not sure

---

### 2. Current Performance

**What's your current conversion rate on this page?**
- [X]% (if you know it)
- [ ] Don't know

**What's your current bounce rate?**
- [X]% (if you know it)
- [ ] Don't know

**How much traffic does this page get?**
- [ ] Under 100 visitors/month
- [ ] 100-500 visitors/month
- [ ] 500-2,000 visitors/month
- [ ] 2,000-10,000 visitors/month
- [ ] Over 10,000 visitors/month
- [ ] Not sure

---

### 3. The Goal

**What's the ONE action you want visitors to take on this page?**
- [ ] Fill out a form (contact, quote, signup)
- [ ] Call a phone number
- [ ] Purchase something
- [ ] Book an appointment
- [ ] Download something
- [ ] Start a free trial
- [ ] Other: ___________

**What happens after they convert?**
[Describe your follow-up process - who calls them, when, etc.]

---

### 4. Traffic Source

**Where does traffic to this page come from?**
- [ ] Google Ads (Search)
- [ ] Google Ads (Display/YouTube)
- [ ] Facebook/Instagram Ads
- [ ] LinkedIn Ads
- [ ] Organic search (SEO)
- [ ] Email campaigns
- [ ] Direct traffic
- [ ] Other: ___________

**If you're running ads, can you share the ad copy?**
[Paste ad copy or attach screenshot - helps us check message match]

**What keywords/audiences are you targeting?**
[Brief description]

---

### 5. Your Concerns

**What do YOU think is wrong with this page?**
[Your gut feeling - we'll validate or challenge this]

**Has this page ever worked better than it does now?**
- [ ] Yes, it used to convert better
- [ ] No, it's always been like this
- [ ] Not sure / new page

**What have you already tried to fix it?**
[List any changes you've made]

---

## Context Questions (Helpful)

### 6. Target Audience

**Who is the ideal person landing on this page?**
[Be specific: job title, situation, problem they have]

**What alternatives are they likely comparing you to?**
[Competitors or alternative solutions]

**What objections might stop them from converting?**
[Common concerns or hesitations]

---

### 7. Competitive Landscape

**Who are your main competitors?**
[List 2-3 with URLs if possible]

**Would you like competitor pages included in this audit?**
- [ ] Yes, compare my page to competitors (+$150-$200)
- [ ] No, just audit my page

---

### 8. Technical Context

**Who built this page?**
- [ ] I did it myself
- [ ] In-house team
- [ ] Agency/freelancer
- [ ] Website builder (Wix, Squarespace, etc.)
- [ ] Not sure

**Can you make changes to this page?**
- [ ] Yes, I can edit it myself
- [ ] Yes, but I need a developer
- [ ] No, I'd need to rebuild it
- [ ] Not sure

**What platform is the page on?**
- [ ] WordPress
- [ ] Webflow
- [ ] Unbounce/Instapage/Leadpages
- [ ] Wix/Squarespace
- [ ] Custom built
- [ ] Other: ___________
- [ ] Not sure

---

### 9. Business Context

**What's a lead/conversion worth to you?**
[Average customer value or lead value - helps prioritize fixes]

**What's your monthly ad spend driving traffic here?**
- [ ] Under $1,000
- [ ] $1,000-$5,000
- [ ] $5,000-$20,000
- [ ] Over $20,000
- [ ] No paid traffic

---

## Quick Version (5 Minutes)

If client is short on time, these are the bare minimum:

1. What's the URL?
2. What action should visitors take?
3. What's your current conversion rate (if known)?
4. Where does traffic come from? Can you share the ad copy?
5. What do you think is wrong?

---

## Sending This as a Form

You can copy these questions into:
- Google Forms
- Typeform
- Notion form
- Tally

Send link to client with: "Fill this out before we start the audit. Takes 5-10 minutes. The more context you give, the more actionable my recommendations will be."

---

## Red Flags to Watch For

During discovery, note if client:
- **Has no tracking** - They won't know if fixes work
- **Can't make changes** - Audit is useless if they can't implement
- **Has unrealistic expectations** - "Make it convert 50%"
- **Doesn't know their audience** - Bigger problem than the page

Address these before starting the audit.

---

## What Good Responses Look Like

**Vague (need to probe):**
"The page isn't working well."

**Good (actionable):**
"We're getting 200 visitors/day from Google Ads but only 3-4 form submissions. Our bounce rate is 75%. The ad promises a free quote but I don't think the page delivers on that promise fast enough."

The more specific the input, the more specific your audit can be.
