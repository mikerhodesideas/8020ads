# Mobile-Specific Audit Checklist

Over 60% of traffic is mobile. A page that works on desktop but fails on mobile is leaving money on the table. This checklist catches mobile-specific issues.

---

## How to Test

1. **Real device** - Test on actual iPhone and Android if possible
2. **Chrome DevTools** - Toggle device toolbar (Cmd+Shift+M)
3. **Standard widths** - Test at 375px (iPhone) and 390px (newer iPhones)
4. **Google's Mobile Test** - search.google.com/test/mobile-friendly

---

## Critical Mobile Issues (Must Pass)

### 1. Above-the-Fold Content

| Check | Status | Notes |
|-------|--------|-------|
| Primary headline visible without scroll | [ ] Pass [ ] Fail | |
| Value proposition clear in first viewport | [ ] Pass [ ] Fail | |
| CTA visible without scroll | [ ] Pass [ ] Fail | |
| No horizontal overflow/scroll | [ ] Pass [ ] Fail | |
| Hero image doesn't push content down | [ ] Pass [ ] Fail | |

**Why it matters:** Mobile visitors are even more impatient. If they have to scroll to understand what the page is or what to do, they'll leave.

---

### 2. Tap Targets

| Check | Status | Notes |
|-------|--------|-------|
| CTA button at least 44x44px | [ ] Pass [ ] Fail | |
| Adequate spacing between links (8px min) | [ ] Pass [ ] Fail | |
| Form fields easy to tap | [ ] Pass [ ] Fail | |
| Nav menu items not crammed together | [ ] Pass [ ] Fail | |
| No accidental tap zones | [ ] Pass [ ] Fail | |

**Test:** Try to tap every interactive element with your thumb. If you miss or hit the wrong thing, it fails.

**Why it matters:** Fat fingers on small screens = frustration and exits.

---

### 3. Text Readability

| Check | Status | Notes |
|-------|--------|-------|
| Base font size 16px or larger | [ ] Pass [ ] Fail | |
| Line length appropriate (45-75 chars) | [ ] Pass [ ] Fail | |
| Adequate line height (1.5 minimum) | [ ] Pass [ ] Fail | |
| Sufficient color contrast | [ ] Pass [ ] Fail | |
| No need to pinch-zoom to read | [ ] Pass [ ] Fail | |

**Why it matters:** If visitors have to zoom to read, you've lost them.

---

### 4. Form Usability

| Check | Status | Notes |
|-------|--------|-------|
| Input fields full-width on mobile | [ ] Pass [ ] Fail | |
| Correct input types (tel, email, etc.) | [ ] Pass [ ] Fail | |
| Autocomplete attributes set | [ ] Pass [ ] Fail | |
| Labels visible while typing | [ ] Pass [ ] Fail | |
| Form doesn't scroll independently | [ ] Pass [ ] Fail | |
| Submit button full-width | [ ] Pass [ ] Fail | |
| Error messages visible near field | [ ] Pass [ ] Fail | |
| Keyboard doesn't hide form fields | [ ] Pass [ ] Fail | |

**Test:** Fill out the entire form on a phone. Note any friction.

**Why it matters:** Mobile form friction is the #1 conversion killer.

---

### 5. Load Performance

| Check | Status | Notes |
|-------|--------|-------|
| Loads in under 3 seconds on 4G | [ ] Pass [ ] Fail | |
| No layout shift while loading | [ ] Pass [ ] Fail | |
| Images sized appropriately | [ ] Pass [ ] Fail | |
| No heavy scripts blocking render | [ ] Pass [ ] Fail | |
| Lazy loading for below-fold content | [ ] Pass [ ] Fail | |

**Test with:**
- PageSpeed Insights (mobile tab)
- WebPageTest.org (3G setting)
- Chrome DevTools Network tab (throttle to Slow 3G)

**Why it matters:** Mobile connections are slower, and patience is shorter.

---

## Common Mobile Failures

### Navigation Issues
- Desktop nav doesn't collapse to hamburger menu
- Menu covers entire screen when opened
- Can't close menu easily
- Menu items too small to tap

### Image Issues
- Images don't resize, cause horizontal scroll
- Images load at desktop sizes (slow)
- Text on images becomes unreadable
- Background images don't adapt

### Layout Issues
- Columns don't stack on mobile
- Content overflows viewport
- Fixed elements cover content
- Sticky headers too tall

### Typography Issues
- Text too small (under 14px)
- Lines too long (can't track easily)
- Not enough contrast on outdoor screens
- Fancy fonts load slowly

### Form Issues
- Fields too small to tap
- Can't see field labels
- Dropdowns impossible to use
- Submit button off-screen

### CTA Issues
- Button not in thumb zone
- Floating CTA covers content
- CTA disappears behind keyboard
- Multiple CTAs confusing on small screen

---

## Mobile-First Recommendations

When writing recommendations, prioritize:

1. **Critical Path Fixes** - Issues that prevent conversion
   - Form doesn't work
   - CTA not visible
   - Page doesn't load

2. **High-Impact Fixes** - Issues that hurt conversion significantly
   - Tap targets too small
   - Load time over 5 seconds
   - Text unreadable

3. **Experience Fixes** - Issues that create friction
   - Layout quirks
   - Navigation problems
   - Minor visual issues

---

## Mobile Testing Script

Quick script to check key metrics:

```bash
# Capture mobile screenshot
npx playwright screenshot [URL] mobile.png --viewport-size=375,812 --full-page

# Check if page is mobile-friendly
curl "https://searchconsole.googleapis.com/v1/urlTestingTools/mobileFriendlyTest:run" \
  -H "Content-Type: application/json" \
  -d '{"url": "[URL]"}'

# Get PageSpeed mobile score
curl "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=[URL]&strategy=mobile"
```

---

## Mobile Audit Report Section Template

```markdown
## Mobile Analysis

**Mobile Score:** [X]/20

### Critical Issues Found

1. **[Issue]**
   - Current: [Description]
   - Impact: [Why it hurts conversion]
   - Fix: [Specific recommendation]

### Recommendations by Priority

**Fix Immediately:**
- [ ] [Issue]
- [ ] [Issue]

**Fix Soon:**
- [ ] [Issue]
- [ ] [Issue]

**Nice to Have:**
- [ ] [Issue]

### Screenshots
[Mobile above-fold screenshot]
[Mobile full-page screenshot]
[Any specific issue screenshots]
```

---

## Mobile Stats to Share with Clients

Use these to emphasize mobile importance:

- 60%+ of web traffic is mobile
- 53% of mobile users abandon sites that take over 3 seconds to load
- Mobile conversion rates are typically 50% lower than desktop (opportunity!)
- Google uses mobile-first indexing
- 88% of consumers who search for a local business on mobile call or visit within 24 hours

**Frame it:** "Your page scores [X]% on desktop but only [Y]% on mobile. Since [Z]% of your traffic is mobile, fixing this could be a 20-30% conversion lift."
