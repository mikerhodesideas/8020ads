# Audit Report Template

## Report Structure

Use this template for professional audit deliverables:

---

# Landing Page Audit Report

**Client**: [Company Name]
**Page URL**: [URL]
**Audit Date**: [Date]
**Auditor**: [Name/Company]

---

## Executive Summary

**Overall Score**: [X] / 100 ([Grade])

[2-3 sentence summary of findings. Lead with the most impactful insight.]

### Score Breakdown

| Category | Score | Weight | Weighted |
|----------|-------|--------|----------|
| Message & Value Clarity | _/10 | 30% | _/30 |
| Trust & Social Proof | _/10 | 25% | _/25 |
| Call-to-Action & Forms | _/8 | 20% | _/20 |
| Technical Performance | _/8 | 15% | _/15 |
| Visual Design & UX | _/8 | 10% | _/10 |
| **TOTAL** | | | **_/100** |

### Key Findings

**Conversion Killers** (Fix Immediately):
- [Issue 1]
- [Issue 2]

**Quick Wins** (High Impact, Low Effort):
- [Issue 1]
- [Issue 2]

**Projected Impact**: Addressing the top 3 issues could improve conversion rates by [X-Y]%.

---

## Detailed Findings

### Category 1: Message & Value Clarity (Score: _/10)

#### 1.1 Headline Effectiveness — Score: [0/1/2]
**Finding**: [Specific observation]
**Issue**: [What's wrong]
**Recommendation**: [Specific fix with example]

[Repeat for each criterion]

### Category 2: Trust & Social Proof (Score: _/10)

[Same structure as above]

### Category 3: Call-to-Action & Forms (Score: _/8)

[Same structure as above]

### Category 4: Technical Performance (Score: _/8)

[Same structure as above]

**Technical Data**:
- PageSpeed Score (Mobile): [X]
- PageSpeed Score (Desktop): [X]
- LCP: [X]s
- INP: [X]ms
- CLS: [X]

### Category 5: Visual Design & UX (Score: _/8)

[Same structure as above]

---

## Priority Roadmap

### Phase 1: Critical Fixes (Week 1)
| Item | Current | Target | Est. Impact |
|------|---------|--------|-------------|
| [Fix 1] | [Issue] | [Goal] | [X%] |
| [Fix 2] | [Issue] | [Goal] | [X%] |

### Phase 2: High-Impact Improvements (Weeks 2-3)
[Same table structure]

### Phase 3: Optimization & Testing (Ongoing)
[Same table structure]

---

## Projected Results

**Current State**:
- Estimated conversion rate: [X]%
- At [Y] monthly visitors = [Z] conversions

**After Phase 1-2 Improvements**:
- Projected conversion rate: [X-Y]%
- At [Y] monthly visitors = [Z-ZZ] conversions
- Potential additional conversions/month: [N]

**Note**: These projections are estimates based on industry benchmarks. Actual results may vary.

---

## Appendix

### Tools Used
- Google PageSpeed Insights
- [Other tools]

### Screenshots
[Include annotated screenshots highlighting specific issues]

### Methodology
This audit uses a research-backed framework evaluating 22 criteria across 5 categories. Scoring is based on established CRO best practices from Conversion Rate Experts, Unbounce, and Google's quality guidelines.

---

## Writing Guidelines

When writing findings:

### Be Specific, Not Vague

**Bad**: "The headline could be better"

**Good**: "The headline 'Welcome to ABC Plumbing' (Score: 0) fails to communicate what you offer or who you serve. Visitors can't understand the value within 3 seconds. Recommended: 'Emergency Plumber in [City] - At Your Door in 60 Minutes or It's Free' which clearly states the service, location, and differentiator."

### Include Evidence

Reference specific elements:
- Quote the actual headline/copy
- Cite page load times from tools
- Note exact form field count
- Describe specific design issues

### Make Recommendations Actionable

**Bad**: "Add more trust elements"

**Good**: "Add Google Reviews widget showing your 4.8-star rating with 127 reviews to the right of the contact form. This placement near the conversion point addresses hesitation at the critical moment."

### Use Client's Language

Match their industry terminology. A plumber's audit should reference "emergency calls" and "service area," not "conversion funnel optimization."

### Quantify When Possible

"Reducing form fields from 7 to 4 could increase form completions by 50-120% based on industry benchmarks."

---

## Blueprint Addendum (When Creating Improved Design)

If the engagement includes a blueprint, add:

### Landing Page Blueprint

**Target Score**: [X] / 100

#### Above-the-Fold Specification

**Headline**: [Exact recommended text]
**Subheadline**: [Exact recommended text]
**CTA**: [Button text and color recommendation]
**Hero Image**: [Description or reference]

#### Content Sections (Top to Bottom)

1. **Hero Section**
   - Components: [List]
   - Copy: [Exact text]
   
2. **Trust Bar**
   - Elements: [List badges/logos needed]
   
3. **Benefits Section**
   - Format: [3 columns with icons, or list, etc.]
   - Content: [Bullet points]

[Continue for all sections]

#### Technical Requirements

- Target load time: < 2.5s
- Required tracking: [List]
- Mobile specifications: [Key requirements]

#### Handoff Checklist

For developers/designers:
- [ ] All copy provided
- [ ] Image specifications defined
- [ ] Mobile breakpoints specified
- [ ] Form fields and validation rules
- [ ] CTA destinations
- [ ] Tracking implementation guide
