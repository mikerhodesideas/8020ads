# Priority Matrix

## Conversion Killers (Fix Immediately)

These issues actively prevent conversions. Address before any other optimization:

| Issue | Impact | Why Critical |
|-------|--------|--------------|
| Page load time > 5 seconds | Loses 50%+ visitors | Users won't wait; they'll bounce to competitor |
| Broken or missing CTA | 0% can convert | No path to conversion exists |
| Ad-to-page message mismatch | Immediate bounce | Visitor feels misled, loses trust instantly |
| Non-functional on mobile | Loses 83% traffic | Majority of traffic can't convert |
| Form errors or broken submission | 0% form conversions | Technical failure at critical moment |
| Missing SSL/security | Browser warnings | Scary warnings drive away visitors |

**Action**: Any Score 0 in these areas = immediate fix before other work.

---

## High Impact Quick Wins

Changes that typically deliver highest ROI with moderate effort:

| Change | Potential Lift | Effort | Notes |
|--------|---------------|--------|-------|
| Headline optimization | Up to 307% | Low | Test outcome-focused vs feature-focused |
| Form field reduction | Up to 120% | Low | Remove non-essential fields |
| Adding testimonials | 34-270% | Medium | Specific, named, with photos |
| CTA text improvement | Up to 202% | Low | Action-oriented, first-person |
| Trust badges near CTA | 15-34% | Low | Payment logos, guarantees, reviews |
| Phone number in header | 10-30% | Low | Click-to-call for local services |

**Priority order**:
1. Form field reduction (highest documented lift)
2. Headline optimization (second-highest lift)
3. Adding testimonials (if missing)
4. CTA improvements
5. Trust badges

---

## Medium Impact (Optimize After Fundamentals)

Address these after conversion killers and quick wins:

| Change | Typical Lift | Effort |
|--------|-------------|--------|
| Visual hierarchy improvements | 10-25% | Medium |
| Adding video content | Up to 86% | High |
| Navigation reduction | Up to 28% | Low |
| Copy rewriting for outcomes | 15-40% | Medium |
| Image optimization/replacement | 10-20% | Medium |
| Mobile-specific optimizations | 8-15% | Medium |

---

## Lower Impact (Polish & Test)

Save for after major issues resolved:

| Change | Typical Lift | Notes |
|--------|-------------|-------|
| Button color testing | 2-10% | Context-dependent |
| Minor copy tweaks | 2-8% | Diminishing returns |
| Font changes | 1-5% | Rarely impactful |
| A/B testing refinements | Varies | Requires traffic volume |
| Advanced personalization | 5-15% | Needs technical setup |

---

## Decision Framework

### When evaluating a landing page:

```
1. Check for Conversion Killers
   ↓ Any found? → Fix first, stop other work
   
2. Score All Categories
   ↓ Identify all 0-scores
   
3. Prioritize by Impact × Ease
   - Score 0 items → Must fix
   - High-weight categories → Higher priority
   - Quick wins → Do first
   
4. Create Phased Roadmap
   Phase 1: Conversion killers + quick wins
   Phase 2: Medium impact items
   Phase 3: Testing and polish
```

### Minimum Viable Landing Page

For a page to be "acceptable," it must have:

- [ ] Load time < 5 seconds
- [ ] Functional on mobile
- [ ] Clear headline (score 1+)
- [ ] Working CTA/form
- [ ] At least one trust element
- [ ] Basic tracking in place

Any page missing these is fundamentally broken.

---

## Traffic-Based Prioritization

### Low Traffic (<1,000 visits/month)
- Focus on conversion killers and fundamentals
- Skip A/B testing (not enough volume)
- Implement best practices directly
- Prioritize quick wins with proven impact

### Medium Traffic (1,000-10,000 visits/month)
- Can run basic A/B tests (4-6 week cycles)
- Prioritize high-impact changes first
- Test one element at a time
- Document results for iteration

### High Traffic (>10,000 visits/month)
- A/B test significant changes
- Can test smaller optimizations
- Multivariate testing possible
- Continuous optimization culture

---

## ROI Calculation Framework

To prioritize fixes by business impact:

```
Monthly Traffic × Current CR × AOV = Current Revenue

If CR improves by X%:
Monthly Traffic × New CR × AOV = Potential Revenue

Potential Revenue - Current Revenue = Monthly Lift

If page fix costs $Y:
Payback Period = $Y / Monthly Lift
```

**Example**:
- 5,000 visits/month
- 2% conversion rate = 100 leads
- Each lead worth $500 = $50,000/month
- Headline fix improves CR to 3% = 150 leads
- New revenue: $75,000/month
- Monthly lift: $25,000
- If fix costs $2,000, payback = 2.4 days
