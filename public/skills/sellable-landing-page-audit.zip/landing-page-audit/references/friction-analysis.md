# Friction Analysis Prompt

Use this prompt with Claude to perform deep friction analysis on a landing page. Provide screenshots and context for best results.

---

## The Prompt

```
You are a conversion rate optimization expert. Analyze this landing page for friction points - anything that slows down, confuses, or stops a visitor from converting.

**Page context:**
- URL: [URL]
- Target audience: [Who the page is for]
- Desired action: [What visitors should do]
- Traffic source: [Where visitors come from]
- Current conversion rate: [If known]

**Ad copy driving traffic (if applicable):**
[Paste ad copy or describe the promise made]

**Screenshots provided:**
- Desktop full page
- Desktop above-fold
- Mobile full page
- Mobile above-fold

Analyze the page for these friction types:

## 1. Visual Friction
- Is the eye path disrupted or confused?
- Are multiple elements competing for attention?
- Is the visual hierarchy unclear?
- Is above-the-fold too cluttered?
- Do colors/fonts support or fight readability?

## 2. Cognitive Friction
- Is the headline instantly clear?
- Can visitors understand what this is in 5 seconds?
- Are there too many choices creating decision paralysis?
- Is any critical information missing?
- Is there jargon or unclear language?
- Do visitors know exactly what happens next?

## 3. Emotional Friction
- Does the page feel trustworthy at first glance?
- Is the tone too aggressive or too passive?
- Does it feel like "this is for me" to the target audience?
- Does the perceived risk feel too high?
- Is there adequate social proof to build confidence?
- Are objections addressed or ignored?

## 4. Technical Friction
- Does the page load fast enough?
- Is mobile experience degraded?
- Is the form easy to complete?
- Are buttons and links obvious and tappable?
- Are there any broken elements?

## 5. Message Match Friction
- Does the headline match what brought them here?
- Is the promised offer clearly visible?
- Is there continuity in visual style from ad to page?
- Does the CTA match the expected action?

For each friction point found:
1. Identify the specific issue
2. Explain why it causes friction
3. Estimate impact (High/Medium/Low)
4. Provide a specific fix recommendation

Prioritize findings by likely impact on conversion rate.
```

---

## Example Output Format

### Visual Friction Found

**Issue 1: Competing CTAs above fold**
- **Location:** Hero section
- **Problem:** "Get Started" button AND "Watch Demo" button AND phone number all competing for attention
- **Why it matters:** Visitors don't know which action to take, leading to choice paralysis and inaction
- **Impact:** High
- **Fix:** Make one primary CTA (Get Started) prominent, demote others to secondary styling or move below fold

**Issue 2: Low contrast headline**
- **Location:** Hero section
- **Problem:** Gray text (#666) on light background is hard to read quickly
- **Why it matters:** Visitors scanning quickly will miss the headline
- **Impact:** Medium
- **Fix:** Increase text color to #333 or darker, ensure contrast ratio meets WCAG AA standards

---

### Cognitive Friction Found

**Issue 1: Unclear value proposition**
- **Location:** Headline and subhead
- **Problem:** "Next-Generation Business Solutions" says nothing about what they actually do or who it's for
- **Why it matters:** Visitors can't determine relevance in the 5-second window before they leave
- **Impact:** High
- **Fix:** Rewrite headline to state specific benefit: "Cut Your Accounting Time in Half" or "Accounting Software for Growing E-Commerce Businesses"

**Issue 2: Too many navigation options**
- **Location:** Header
- **Problem:** Full website nav with 7 options distracts from the page's single purpose
- **Why it matters:** Every nav link is an exit opportunity; landing pages should minimize escape routes
- **Impact:** Medium
- **Fix:** Remove navigation entirely or reduce to logo only

---

### Emotional Friction Found

**Issue 1: No social proof visible**
- **Location:** Above fold
- **Problem:** Zero testimonials, logos, or trust signals visible without scrolling
- **Why it matters:** Visitors need quick confidence signals before engaging
- **Impact:** High
- **Fix:** Add one strong testimonial or "500+ companies trust us" badge above the fold

**Issue 2: Stock photo feels inauthentic**
- **Location:** Hero image
- **Problem:** Obvious stock photo of smiling businesspeople doesn't feel real
- **Why it matters:** Generic imagery signals generic company, reduces trust
- **Impact:** Low-Medium
- **Fix:** Replace with real team photo, product screenshot, or relevant illustration

---

### Technical Friction Found

**Issue 1: Slow load time**
- **Location:** Full page
- **Problem:** PageSpeed score 45, LCP over 4 seconds
- **Why it matters:** 53% of mobile visitors abandon pages taking over 3 seconds to load
- **Impact:** High
- **Fix:** Compress images, defer non-critical scripts, enable caching

---

### Message Match Friction Found

**Issue 1: Ad-to-page disconnect**
- **Ad copy:** "Get a Free Marketing Audit"
- **Page headline:** "Transform Your Digital Presence"
- **Problem:** Ad promises something specific, page headline is vague
- **Why it matters:** Visitors who clicked for a free audit don't see that offer immediately, causing confusion and bounce
- **Impact:** High
- **Fix:** Lead with "Your Free Marketing Audit" in headline, make it match exactly

---

## Using the Friction Analysis

1. **Run the checklist first** - Catch obvious issues
2. **Then run friction analysis** - Find subtle problems
3. **Cross-reference findings** - Some will overlap
4. **Prioritize by impact** - High impact friction first
5. **Include in report** - Use friction analysis to explain the "why" behind checklist failures

---

## Friction Red Flags by Industry

### B2B SaaS
- Free trial with credit card required (high friction)
- Long forms before seeing product
- No clear explanation of what the product does
- Missing security/compliance badges

### Local Services
- No phone number visible
- No service area mentioned
- No reviews or testimonials
- No photos of actual work

### E-commerce
- Price not visible
- Shipping info unclear
- Return policy buried
- Product images low quality

### Professional Services
- No credentials or qualifications
- Missing case studies or results
- No face/photo of the person
- No clear process explanation

---

## Quick Friction Scan (2 Minutes)

Before deep analysis, do a quick scan:

1. **5-Second Test:** What is this page about? Who is it for? What should I do?
2. **Squint Test:** Blur your eyes - does the CTA still stand out?
3. **Thumb Test:** On mobile, can you reach the CTA with your thumb?
4. **Trust Test:** Would you enter your credit card on this page?
5. **Back Button Test:** Is there any reason to hit back instead of convert?

If any answer is "no" or "unclear," you've found friction.
