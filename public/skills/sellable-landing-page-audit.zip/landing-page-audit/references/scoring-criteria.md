# Scoring Criteria Reference

## Category 1: Message & Value Clarity (30% weight)

### 1.1 Headline Effectiveness
**Question**: Does the headline clearly communicate what the business offers AND who it is for within 3 seconds?

| Score | Criteria |
|-------|----------|
| 0 | Missing, vague, or generic (e.g., "Welcome to Our Website") |
| 1 | Partially clear - communicates offer OR audience, not both |
| 2 | Immediately clear - visitor knows exactly what is offered and for whom |

**Examples**:
- Score 0: "Welcome to ABC Services"
- Score 1: "Professional Plumbing Services"
- Score 2: "24/7 Emergency Plumber in Phoenix - At Your Door in 60 Minutes or It's Free"

### 1.2 Value Proposition Clarity
**Question**: Is the primary benefit to the customer immediately obvious above the fold?

| Score | Criteria |
|-------|----------|
| 0 | No clear value proposition visible without scrolling |
| 1 | Value proposition present but focuses on features, not benefits |
| 2 | Clear outcome-focused benefit that answers "What's in it for me?" |

**Test**: Can someone describe the main benefit after 5 seconds of viewing?

### 1.3 Ad-to-Page Message Match
**Question**: Does the landing page headline and content directly reflect the ad that drove the click?

| Score | Criteria |
|-------|----------|
| 0 | Significant disconnect between ad promise and page content |
| 1 | General theme matches but specific language differs |
| 2 | Near-exact match of key phrases from ad to headline/subheadline |

**Note**: This directly affects Google Ads Quality Score.

### 1.4 Copy Scannability
**Question**: Can key information be absorbed by scanning rather than reading every word?

| Score | Criteria |
|-------|----------|
| 0 | Dense paragraphs, no visual breaks, requires linear reading |
| 1 | Some bullet points or short paragraphs, but inconsistent |
| 2 | Clear hierarchy with bullets, short paragraphs (2-3 sentences), bold key points |

**Research**: Copy at 5th-7th grade level converts at 11.1% vs 5.3% for professional-level text.

### 1.5 Outcome-Focused Language
**Question**: Does the copy focus on customer outcomes rather than business features?

| Score | Criteria |
|-------|----------|
| 0 | Copy is company-centric ("We have 20 years experience") |
| 1 | Mix of features and benefits without clear outcome framing |
| 2 | Customer-centric copy painting a picture of life after using the product/service |

**Framework**: Problem-Agitate-Solve (PAS) structure is most effective.

---

## Category 2: Call-to-Action & Forms (20% weight)

### 2.1 CTA Clarity and Visibility
**Question**: Is the primary call-to-action immediately obvious and compelling?

| Score | Criteria |
|-------|----------|
| 0 | No clear CTA, or multiple competing CTAs with equal prominence |
| 1 | CTA present but uses weak language ("Submit", "Learn More") or poor placement |
| 2 | Primary CTA is visually prominent, uses action-oriented language, above fold |

**Best practices**:
- Use first-person ("Get My Free Quote" vs "Get Your Free Quote")
- Be specific about outcome ("Start Saving Today" vs "Submit")
- Use contrasting color
- One primary CTA per page

### 2.2 Form Length & Friction
**Question**: Is the form optimized for minimum necessary fields?

| Score | Criteria |
|-------|----------|
| 0 | 8+ fields without justification, or asking for sensitive info early |
| 1 | 5-7 fields with reasonable justification for each |
| 2 | 4 or fewer fields capturing only essential information |

**Research**:
- Reducing fields from 11 to 4 = 120% more conversions
- 3 fields shows highest conversion rate (~25%)
- 81% of people abandon forms after starting

**Exception**: High-value B2B offers can use 7-10 fields to qualify buyers.

### 2.3 Above-the-Fold Conversion Path
**Question**: Can a visitor begin the conversion process without scrolling?

| Score | Criteria |
|-------|----------|
| 0 | CTA or form not visible without scrolling |
| 1 | CTA visible but form/next step requires scrolling |
| 2 | Clear conversion path starts above fold on both desktop and mobile |

**Note**: Test both desktop (1440px) and mobile viewports.

### 2.4 Urgency & Scarcity (When Appropriate)
**Question**: Are legitimate urgency or scarcity elements used?

| Score | Criteria |
|-------|----------|
| 0 | Fake urgency ("Only 3 left!" when unlimited), or no urgency where appropriate |
| 1 | Legitimate but weak urgency elements |
| 2 | Real urgency appropriately communicated, OR N/A for page type |

**Legitimate examples**:
- Limited-time offers with real deadlines
- Seasonal relevance ("Book before summer rush")
- Capacity constraints ("Only 5 spots remaining in February")

---

## Category 3: Technical Performance (15% weight)

### How to Get PageSpeed Data

Ask the user to run PageSpeed Insights manually:
1. Go to https://pagespeed.web.dev/
2. Enter the URL and click "Analyze"
3. **Select "Mobile"** view
4. Share data via: results link, copy/paste text, or screenshot

**Use real-world data** (top section, from Chrome UX Report) when available. Lab data (bottom section) is useful for diagnostics but often shows worse scores due to throttling.

### 3.1 Page Load Speed
**Question**: What is the PageSpeed Performance score?

| Score | Criteria |
|-------|----------|
| 0 | Performance score below 50 |
| 1 | Performance score 50-89 |
| 2 | Performance score 90-100 |

**Research**:
- Pages loading in 1s convert 3x higher than 5s pages
- Each 1-second delay costs ~7% in conversions
- 47% expect pages to load in 2 seconds or less

**Tool**: PageSpeed Insights (manual - no API key required)

### 3.2 Core Web Vitals
**Question**: Does the page pass Google's Core Web Vitals thresholds?

**Thresholds** (from real-world data section):

| Metric | Good | Needs Work | Poor |
|--------|------|------------|------|
| LCP | < 2.5s | 2.5-4s | > 4s |
| INP | < 200ms | 200-500ms | > 500ms |
| CLS | < 0.1 | 0.1-0.25 | > 0.25 |

| Score | Criteria |
|-------|----------|
| 0 | One or more metrics in "Poor" range |
| 1 | All metrics "Good" or "Needs Improvement", none "Poor" |
| 2 | All three metrics in "Good" range (shows "Passed" badge) |

**Tool**: PageSpeed Insights (check "Core Web Vitals Assessment" at top)

### 3.3 Mobile Responsiveness
**Question**: Does the page render and function correctly on mobile devices?

| Score | Criteria |
|-------|----------|
| 0 | Not mobile-friendly (horizontal scroll, tiny text, broken layout) |
| 1 | Responsive but with usability issues (buttons too close, form hard to use) |
| 2 | Fully optimized mobile experience with touch-friendly elements |

**Checklist**:
- Click-to-call phone numbers
- Touch targets at least 48x48 pixels
- Form fields sized for mobile keyboards
- No horizontal scrolling

### 3.4 Tracking Implementation
**Question**: Is conversion tracking properly implemented?

| Score | Criteria |
|-------|----------|
| 0 | No conversion tracking or broken tracking |
| 1 | Basic tracking (pageviews) but no conversion events |
| 2 | Complete tracking with conversion events, GA4, and Google Ads tags |

**Tool**: Google Tag Assistant, GA4 DebugView

---

## Category 4: Visual Design & UX (10% weight)

### 4.1 Visual Hierarchy
**Question**: Does the design guide the eye through content toward the CTA?

| Score | Criteria |
|-------|----------|
| 0 | No clear hierarchy; equal visual weight everywhere |
| 1 | Some hierarchy but competing elements or unclear path |
| 2 | Clear headline > subheadline > benefits > CTA progression |

**Test**: "Squint test" - when you squint, important elements should still stand out.

### 4.2 White Space & Readability
**Question**: Is there adequate spacing between elements?

| Score | Criteria |
|-------|----------|
| 0 | Crowded layout with insufficient margins and line spacing |
| 1 | Adequate spacing but inconsistent throughout |
| 2 | Generous, consistent white space that aids comprehension |

### 4.3 Image Quality & Relevance
**Question**: Are images high-quality, relevant, and authentic?

| Score | Criteria |
|-------|----------|
| 0 | No images, poor quality images, or obviously generic stock photos |
| 1 | Relevant stock images, properly sized |
| 2 | Authentic images (real product/team/results) that support the message |

**Research**: User-generated photos trusted 2.4x more than brand content.

### 4.4 Navigation Simplicity
**Question**: Is navigation minimized to reduce distractions?

| Score | Criteria |
|-------|----------|
| 0 | Full website navigation with many exit points |
| 1 | Reduced navigation but still multiple links away from conversion |
| 2 | Minimal/no navigation; page focused entirely on conversion goal |

**Research**: Removing navigation can increase conversions by up to 28%.

---

## Score Calculation

### Step 1: Calculate Raw Scores
Sum scores for each category:
- Category 1 (5 items): ___ / 10
- Category 2 (4 items): ___ / 8
- Category 3 (4 items): ___ / 8
- Category 4 (4 items): ___ / 8

### Step 2: Apply Weights
Convert to weighted score (out of 75):

```
Category 1: (raw / 10) × 30 = ___
Category 2: (raw / 8) × 20 = ___
Category 3: (raw / 8) × 15 = ___
Category 4: (raw / 8) × 10 = ___
                    TOTAL = ___ / 75
```

### Step 3: Assign Grade
- 85-100: A (Excellent)
- 70-84: B (Good)
- 55-69: C (Fair)
- 40-54: D (Poor)
- 0-39: F (Critical)
