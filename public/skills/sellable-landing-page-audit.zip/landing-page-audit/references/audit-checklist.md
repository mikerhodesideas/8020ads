# The 50-Point Landing Page Audit Checklist

Systematic checklist covering every element that affects conversion. Score each item and calculate total.

---

## Scoring System

- **Pass (1 point)** - Meets best practice, no issues
- **Partial (0.5 point)** - Present but needs improvement
- **Fail (0 points)** - Missing, broken, or seriously flawed

**Calculate:** Total points / 50 = Score %

**Interpretation:**
- 80%+ = Strong foundation, minor optimization needed
- 60-79% = Good but has notable issues
- 40-59% = Significant problems, major work needed
- Below 40% = Consider rebuild vs. repair

---

## Section 1: Above the Fold (15 points)

Everything visible before scrolling on desktop (1440px) and mobile (375px).

### Headline & Value Proposition (6 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 1 | **Clear headline** - States what you get or what problem is solved | [ ] | [ ] | [ ] | |
| 2 | **Benefit-focused** - About the customer, not the company | [ ] | [ ] | [ ] | |
| 3 | **Subhead expands** - Adds context, doesn't repeat headline | [ ] | [ ] | [ ] | |
| 4 | **Matches ad copy** - Headline aligns with what brought them here | [ ] | [ ] | [ ] | |
| 5 | **Unique value clear** - Know why to choose you vs. alternatives | [ ] | [ ] | [ ] | |
| 6 | **Readable at a glance** - Font size, contrast, line length all good | [ ] | [ ] | [ ] | |

### Visual Elements (5 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 7 | **Hero image relevant** - Supports the message, not just decoration | [ ] | [ ] | [ ] | |
| 8 | **Visual hierarchy** - Eye naturally flows to key elements | [ ] | [ ] | [ ] | |
| 9 | **No visual clutter** - Clean, focused, not overwhelming | [ ] | [ ] | [ ] | |
| 10 | **Logo present but not dominant** - Branding without distraction | [ ] | [ ] | [ ] | |
| 11 | **Professional quality** - Images, graphics look polished | [ ] | [ ] | [ ] | |

### Primary CTA (4 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 12 | **CTA visible above fold** - Don't have to scroll to take action | [ ] | [ ] | [ ] | |
| 13 | **Single clear CTA** - One primary action, not competing options | [ ] | [ ] | [ ] | |
| 14 | **CTA stands out** - Color contrast, size make it obvious | [ ] | [ ] | [ ] | |
| 15 | **Action-oriented text** - "Get Your Free Quote" not "Submit" | [ ] | [ ] | [ ] | |

**Section 1 Score:** ___/15

---

## Section 2: Trust & Credibility (10 points)

Elements that build confidence and reduce perceived risk.

### Social Proof (5 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 16 | **Testimonials present** - Real quotes from real customers | [ ] | [ ] | [ ] | |
| 17 | **Specific results cited** - Numbers, outcomes, not vague praise | [ ] | [ ] | [ ] | |
| 18 | **Attribution included** - Names, photos, companies where possible | [ ] | [ ] | [ ] | |
| 19 | **Quantity shown** - "500+ customers" or "4.9 stars from 200 reviews" | [ ] | [ ] | [ ] | |
| 20 | **Relevant proof** - Testimonials from similar customers/situations | [ ] | [ ] | [ ] | |

### Authority Signals (5 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 21 | **Trust badges** - Security, certifications, associations | [ ] | [ ] | [ ] | |
| 22 | **Real photos** - Actual team/office, not obvious stock | [ ] | [ ] | [ ] | |
| 23 | **Contact info visible** - Phone, address, email accessible | [ ] | [ ] | [ ] | |
| 24 | **Credentials shown** - Years in business, qualifications, awards | [ ] | [ ] | [ ] | |
| 25 | **Media mentions/logos** - "As seen in" or client logos | [ ] | [ ] | [ ] | |

**Section 2 Score:** ___/10

---

## Section 3: Form & CTA (10 points)

The conversion mechanism itself.

### Form Design (6 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 26 | **Appropriate field count** - Only what's truly needed | [ ] | [ ] | [ ] | |
| 27 | **Clear field labels** - Know exactly what to enter | [ ] | [ ] | [ ] | |
| 28 | **Input types correct** - Email field shows email keyboard, etc. | [ ] | [ ] | [ ] | |
| 29 | **Error handling clear** - Know what went wrong if validation fails | [ ] | [ ] | [ ] | |
| 30 | **Privacy addressed** - "We won't spam you" or privacy link | [ ] | [ ] | [ ] | |
| 31 | **Progress indicator** - If multi-step, show where they are | [ ] | [ ] | [ ] | |

### CTA Button (4 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 32 | **Button text specific** - Says what happens ("Get My Quote") | [ ] | [ ] | [ ] | |
| 33 | **High contrast** - Button clearly stands out from background | [ ] | [ ] | [ ] | |
| 34 | **Adequate size** - Easy to tap on mobile (44x44px minimum) | [ ] | [ ] | [ ] | |
| 35 | **Micro-copy helps** - Text below button reduces friction | [ ] | [ ] | [ ] | |

**Section 3 Score:** ___/10

---

## Section 4: Technical (10 points)

Performance and functionality.

### Speed & Performance (4 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 36 | **Loads under 3 seconds** - Test on PageSpeed Insights | [ ] | [ ] | [ ] | |
| 37 | **Images optimized** - Compressed, proper format, lazy loaded | [ ] | [ ] | [ ] | |
| 38 | **No render blocking** - Critical content loads first | [ ] | [ ] | [ ] | |
| 39 | **Core Web Vitals pass** - LCP, FID, CLS in acceptable range | [ ] | [ ] | [ ] | |

### Mobile & Cross-Browser (4 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 40 | **Mobile responsive** - Layout adapts properly | [ ] | [ ] | [ ] | |
| 41 | **Touch-friendly** - All tap targets adequate size | [ ] | [ ] | [ ] | |
| 42 | **Text readable** - Font size adequate without zooming | [ ] | [ ] | [ ] | |
| 43 | **Cross-browser works** - Chrome, Safari, Firefox all function | [ ] | [ ] | [ ] | |

### Functionality (2 points)

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 44 | **Form submits successfully** - Actually works, confirmation shown | [ ] | [ ] | [ ] | |
| 45 | **Tracking implemented** - Analytics and conversion events fire | [ ] | [ ] | [ ] | |

**Section 4 Score:** ___/10

---

## Section 5: Copy & Content (5 points)

The words on the page.

| # | Check | Pass | Partial | Fail | Notes |
|---|-------|------|---------|------|-------|
| 46 | **Benefits over features** - Focus on outcomes, not specs | [ ] | [ ] | [ ] | |
| 47 | **Specific over vague** - "Save 3 hours/week" not "Save time" | [ ] | [ ] | [ ] | |
| 48 | **Objections addressed** - FAQs or copy handles concerns | [ ] | [ ] | [ ] | |
| 49 | **Scannable format** - Bullets, short paragraphs, headers | [ ] | [ ] | [ ] | |
| 50 | **Clear next step** - Visitor knows exactly what to do | [ ] | [ ] | [ ] | |

**Section 5 Score:** ___/5

---

## Total Score Calculation

| Section | Score | Max |
|---------|-------|-----|
| Above the Fold | | 15 |
| Trust & Credibility | | 10 |
| Form & CTA | | 10 |
| Technical | | 10 |
| Copy & Content | | 5 |
| **TOTAL** | | **50** |

**Overall Score: ___/50 = ___%**

---

## Quick Reference: Common Fails by Issue Type

### Conversion Killers (Fix Immediately)
- No clear CTA above fold (#12, #13)
- Form doesn't work (#44)
- Loads over 5 seconds (#36)
- Not mobile friendly (#40, #41)
- No social proof at all (#16-20)

### Conversion Reducers (Fix Soon)
- Headline doesn't match ad (#4)
- Too many form fields (#26)
- Button says "Submit" (#32)
- No trust signals (#21-25)
- Vague, features-focused copy (#46, #47)

### Conversion Optimizers (Fix Later)
- Visual hierarchy unclear (#8)
- No micro-copy on button (#35)
- Images not optimized (#37)
- No progress indicator on form (#31)
- Could be more scannable (#49)

---

## Using This Checklist

1. **Open the page** in desktop browser (1440px width)
2. **Go through each item** systematically
3. **Score honestly** - partial credit for "almost there"
4. **Take screenshots** of specific issues
5. **Note specifics** in the Notes column
6. **Calculate total** and interpret score
7. **Prioritize fixes** by impact (see SKILL.md)

The checklist is the foundation. The value you add is prioritization and specific recommendations.
