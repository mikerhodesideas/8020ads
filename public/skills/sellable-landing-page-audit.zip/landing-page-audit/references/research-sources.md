# Research Sources

## Key Statistics & Their Sources

### Headlines & Copy

| Statistic | Source |
|-----------|--------|
| Well-written headlines can increase conversions by up to 307% | Leadpages |
| 80% read headlines, only 20% read the rest | Copyblogger |
| Copy at 5th-7th grade level converts at 11.1% vs 5.3% for professional-level | involve.me analysis |
| Users form first impressions in 50 milliseconds | Google research |

### Page Speed & Technical

| Statistic | Source |
|-----------|--------|
| Pages loading in 1s convert 3x higher than 5s pages | Google |
| Each 1-second delay costs ~7% in conversions | Google/Portent |
| 47% expect pages to load in 2 seconds or less | Keywords Everywhere |
| 30% abandon if page takes 6-10 seconds | Kissmetrics |
| LCP < 2.5s, INP < 200ms, CLS < 0.1 (Good thresholds) | Google Core Web Vitals |

### Forms & CTAs

| Statistic | Source |
|-----------|--------|
| Reducing form fields from 11 to 4 = 120% more conversions | Imagescape/Cobloom |
| 81% abandon forms after starting | Insiteful |
| 3 fields shows highest conversion rate (~25%) | HubSpot (40,000 landing pages) |
| Personalized CTAs convert 202% better | HubSpot |
| Removing navigation can increase conversions by up to 28% | HubSpot A/B test |

### Social Proof & Trust

| Statistic | Source |
|-----------|--------|
| Displaying reviews increases conversions up to 270% | Spiegel Research Center (Northwestern) |
| Testimonials increase sales page conversions by 34% | TrustPulse/Wikijob case study |
| Video testimonials provide 80% higher conversion lift | The DVI Group |
| 97% of consumers say reviews impact purchasing decisions | Podium |
| Adding client logos can increase conversions up to 400% | Conversion Rate Experts |
| User-generated photos trusted 2.4x more than brand content | Stackla |
| Products with 4.2-4.5 stars show optimal purchase likelihood | Spiegel Research Center |

### Mobile & Traffic

| Statistic | Source |
|-----------|--------|
| 82.9% of landing page traffic is mobile | Backlinko/industry analysis |
| Mobile converts 8% lower than desktop on average | Industry benchmarks |
| 76% of local mobile searchers visit a store that day | Google |

### Conversion Benchmarks

| Statistic | Source |
|-----------|--------|
| Median conversion rate: 6.6% across industries | Unbounce Conversion Benchmark Report |
| SaaS median: ~3.8% | Industry analysis |
| Financial services: ~8.4% | Industry analysis |
| E-commerce: 2-4% typical | Industry analysis |
| Top performers: 10%+ | Various sources |

### Video & Visuals

| Statistic | Source |
|-----------|--------|
| Video on landing pages can increase conversions up to 86% | Various case studies |
| 38.6% of marketers say video is #1 element impacting conversion | Survey data |
| Users retain 80% of what they see, 20% of what they read | Visual content studies |
| 79% have watched testimonial videos | Wyzowl |

### A/B Testing

| Statistic | Source |
|-----------|--------|
| 77% of businesses use A/B testing | VWO |
| Only 1 in 8 A/B tests produces significant winner | VWO |
| 17% of marketers use A/B testing for landing pages | Survey data |

---

## Primary Research Organizations

### Conversion Rate Experts
- CRE Methodology
- Moz case study ($1M revenue increase)
- Enterprise client optimization research
- Website: conversion-rate-experts.com

### Unbounce
- Conversion Benchmark Reports (16,000+ landing pages analyzed)
- Landing page statistics
- A/B testing research
- Website: unbounce.com

### Spiegel Research Center (Northwestern University)
- Academic research on review impact
- Star rating optimization studies
- Consumer behavior research

### HubSpot
- Form optimization research (40,000+ landing pages)
- CTA testing data
- Marketing statistics
- Website: hubspot.com

### Google
- Core Web Vitals research
- PageSpeed and mobile-first data
- Quality Score documentation
- Page experience guidelines
- Website: developers.google.com

---

## CRO Agencies Cited

| Agency | Known For |
|--------|-----------|
| Conversion Rate Experts | Enterprise CRO, CRE Methodology |
| Unbounce | Landing page builder, benchmark data |
| ConversionWise | Design-focused CRO |
| VWO | A/B testing platform, research |
| Optimizely | Experimentation platform |
| CXL | CRO education and research |

---

## Tools Referenced

### Performance Testing
- Google PageSpeed Insights (free)
- GTmetrix (free tier)
- Chrome DevTools (free)
- WebPageTest (free)

### Mobile Testing
- Google Mobile-Friendly Test (free)
- Chrome DevTools Device Mode (free)
- BrowserStack (limited free)

### Tracking Verification
- Google Tag Assistant (free)
- GA4 DebugView (free)
- Screaming Frog (free tier)

### Content Analysis
- Hemingway Editor (free)
- Readable.com (limited free)

### Heatmaps & Behavior (for advanced analysis)
- Hotjar (free tier)
- Microsoft Clarity (free)
- Lucky Orange

---

## Methodology Notes

### Why These Sources

This framework prioritizes:

1. **Academic research** (Spiegel Research Center) for credibility
2. **Large-sample studies** (HubSpot 40K pages, Unbounce 16K pages)
3. **Practitioner validation** (Conversion Rate Experts case studies)
4. **Platform documentation** (Google's official guidelines)

### Limitations

- Most statistics are aggregates; individual results vary
- Benchmarks change over time; these are as of 2024-2025
- Industry-specific data may have smaller sample sizes
- Causation vs correlation in many observational studies

### Keeping Current

Key sources to monitor for updated statistics:
- Unbounce annual benchmark reports
- Google Search Central updates
- CXL research library
- HubSpot State of Marketing reports
