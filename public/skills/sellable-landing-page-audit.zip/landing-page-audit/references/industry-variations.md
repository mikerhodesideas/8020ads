# Industry-Specific Variations

## Local Services (Plumbers, Dentists, Lawyers, HVAC, etc.)

### Emphasize
- **Click-to-call phone number** in header (critical)
- **Local Google reviews** integration with star rating
- **Service area** prominently displayed
- **Emergency/24-7 availability** if applicable
- **Licensing and insurance proof**
- **Local address** with Google Maps embed
- **Response time promises** ("At your door in 60 minutes")
- **"Near me" language** in copy

### De-emphasize
- Long-form content (visitors want quick answers)
- Complex feature comparisons
- Pricing calculators (quotes work better)
- Generic stock photos (use real team photos)

### Key Trust Elements
- Google Reviews badge with count and rating
- BBB accreditation
- State licenses
- Insurance proof
- Years in business
- Local team photos

### Typical Conversion Goals
- Phone call (primary)
- Form submission for quote
- Chat initiation

### Benchmark Conversion Rates
- Emergency services: 8-15%
- Scheduled services: 5-10%
- Professional services (lawyers, accountants): 3-8%

---

## E-commerce Product Pages

### Emphasize
- **High-quality product images** (multiple angles, zoom, lifestyle)
- **Customer reviews with photos** prominently displayed
- **Clear pricing** with any discounts highlighted
- **Shipping information** (cost, speed, free threshold)
- **Stock/availability indicators**
- **Return policy** visible near CTA
- **Size guides** where relevant
- **Product comparison** if multiple options

### De-emphasize
- Long marketing copy (show, don't tell)
- Company history
- Generic value propositions

### Key Trust Elements
- Customer reviews (minimum 5, ideally 50+)
- Star ratings
- "Verified Purchase" badges
- Payment provider logos (Visa, PayPal, etc.)
- SSL security badge
- Money-back guarantee
- Free returns messaging

### Typical Conversion Goals
- Add to cart
- Direct purchase
- Wishlist addition

### Benchmark Conversion Rates
- Average: 2-4%
- Top performers: 5-10%
- Luxury/high-ticket: 1-2% (higher AOV)

---

## B2B SaaS Landing Pages

### Emphasize
- **Clear value proposition** with specific outcomes
- **Enterprise client logos** (social proof)
- **Case studies** with metrics ("Increased productivity 40%")
- **Product screenshots/demo video**
- **Security/compliance badges** (SOC2, GDPR, HIPAA)
- **Integration logos** (works with tools they use)
- **Pricing transparency** (or clear path to learn pricing)
- **ROI calculator** or savings estimator

### De-emphasize
- Fluffy marketing language
- Generic benefit claims
- Stock photos of people
- Excessive feature lists without context

### Key Trust Elements
- Client logos (especially recognizable brands)
- G2/Capterra ratings
- Case studies with named companies
- Security certifications
- Uptime guarantees
- Customer count ("Join 10,000+ companies")

### Segment Differences

**SMB-Focused SaaS**:
- Self-serve free trial CTA
- Simple pricing displayed
- Quick time-to-value messaging
- Live chat for support

**Enterprise-Focused SaaS**:
- "Request Demo" or "Contact Sales" CTA
- "Talk to an expert" messaging
- Custom pricing expected
- Multiple stakeholder content (IT, Finance, End-users)
- Longer-form content acceptable

### Benchmark Conversion Rates
- SMB SaaS: 3-7% (faster decisions)
- Mid-market SaaS: 2-5%
- Enterprise SaaS: 1-3% (longer sales cycle)

---

## Lead Generation (Professional Services)

### Emphasize
- **Lead magnet offer** (ebook, consultation, audit, webinar)
- **Professional credentials** and certifications
- **Testimonials from similar clients** (industry-specific)
- **Process explanation** ("What happens after you submit")
- **Privacy assurances** ("We'll never share your information")
- **Response time promise** ("We'll call you within 24 hours")
- **Specific outcomes** rather than vague benefits

### De-emphasize
- Excessive company background
- Team bios (unless they are the product)
- Industry jargon without explanation

### Key Trust Elements
- Professional certifications
- Association memberships
- Client testimonials with company names
- Media mentions / "As seen in"
- Years of experience
- Number of clients served

### Form Best Practices
- Lead magnets: Name + Email (2 fields)
- Consultations: Name + Email + Phone + Brief Question (4-5 fields)
- Enterprise leads: Can add Company + Role for qualification

### Benchmark Conversion Rates
- Content download: 15-30%
- Free consultation request: 5-15%
- Quote/proposal request: 3-8%

---

## Healthcare / Medical

### Emphasize
- **Provider credentials** (MD, certifications, board certifications)
- **Facility accreditations** (Joint Commission, etc.)
- **Patient testimonials** (HIPAA-compliant)
- **Insurance acceptance** information
- **Location and hours** prominently displayed
- **Online scheduling** capability
- **Emergency information** where relevant

### De-emphasize
- Generic health claims without substantiation
- Before/after photos without proper consent
- Price as primary message

### Key Trust Elements
- Board certifications
- Hospital affiliations
- Years of practice
- Patient satisfaction scores
- Insurance logos
- HIPAA compliance messaging

### Compliance Notes
- HIPAA considerations for forms/tracking
- Cannot make unsubstantiated claims
- Testimonials need proper consent
- Avoid guaranteeing outcomes

---

## Real Estate

### Emphasize
- **Property visuals** (high-quality photos, virtual tours)
- **Key property details** above fold (price, beds, baths, sqft)
- **Location information** with map
- **Agent contact information** with photo
- **Scheduling for showings** or virtual tours
- **Mortgage calculator** for buyers
- **Neighborhood information** for buyers

### De-emphasize
- Generic company information
- Long agent bios on property pages

### Key Trust Elements
- Agent photo and credentials
- Brokerage branding
- Number of transactions/years experience
- Client testimonials
- Zillow/Realtor ratings

---

## Adaptation Checklist

When applying the framework to any industry:

1. **Identify primary conversion goal** for that industry
2. **Determine key trust elements** specific to the industry
3. **Understand typical sales cycle** (immediate vs. considered)
4. **Know benchmark conversion rates** for context
5. **Identify compliance/regulatory requirements**
6. **Adjust form fields** based on qualification needs
7. **Select appropriate urgency elements** (or note if inappropriate)
