# Landing Page Structure Template

This file defines the recommended page structure for blueprints. Edit this to change what sections are recommended and in what order.

## Default Page Structure

When generating a blueprint, use these sections in this order. Skip sections that don't apply to the business type.

### 1. Hero Section
- **Purpose:** Capture attention, communicate core value proposition
- **Elements:** Headline, subheadline, primary CTA, hero image/video
- **Height:** Above the fold (no scrolling required)
- **Wireframe color:** Dark (primary focus)

### 2. Problem/Pain Section
- **Purpose:** Show you understand their situation
- **Elements:** 2-3 pain points, empathetic language
- **Height:** Short - don't dwell
- **Wireframe color:** Medium gray

### 3. Solution Section
- **Purpose:** Introduce your approach
- **Elements:** How you solve the problem, key differentiators
- **Height:** Medium
- **Wireframe color:** Medium gray

### 4. Benefits Section
- **Purpose:** What they get (outcomes, not features)
- **Elements:** 3-4 benefit blocks with icons, short descriptions
- **Height:** Medium
- **Wireframe color:** Light background

### 5. How It Works
- **Purpose:** Remove uncertainty about process
- **Elements:** 3-4 numbered steps, simple visuals
- **Height:** Medium
- **Wireframe color:** White

### 6. Social Proof Section
- **Purpose:** Build trust through others' experiences
- **Elements:** 2-3 testimonials with photos/names, case study snippets
- **Height:** Medium-large
- **Wireframe color:** Light background

### 7. FAQ Section
- **Purpose:** Handle objections, reduce friction
- **Elements:** 4-6 common questions, expandable answers
- **Height:** Variable
- **Wireframe color:** White

### 8. Final CTA Section
- **Purpose:** Convert visitors who scrolled the whole page
- **Elements:** Strong headline, repeat primary CTA, urgency if appropriate
- **Height:** Medium
- **Wireframe color:** Dark (accent color)

### 9. Footer
- **Purpose:** Secondary navigation, legal, contact
- **Elements:** Links, contact info, privacy/terms
- **Height:** Compact
- **Wireframe color:** Dark

---

## Section Variations by Industry

### Local Services (plumbers, dentists, etc.)
- Add: Phone number prominent in hero
- Add: Service area map
- Emphasize: Reviews, "years in business"

### E-commerce
- Add: Product showcase section
- Add: Shipping/returns info
- Emphasize: Trust badges, secure payment

### B2B / SaaS
- Add: Demo/trial CTA option
- Add: Integration logos
- Emphasize: ROI stats, enterprise testimonials

### Professional Services (lawyers, accountants)
- Add: Credentials section
- Add: Consultation booking
- Emphasize: Expertise, case results

---

## Wireframe Visual Specs

When generating the HTML wireframe:

```
Colors:
- Hero/CTA sections: #2d3748 (dark)
- Content sections: #e2e8f0 (light gray)
- Alternating: #f7fafc (very light)
- Accent elements: #D64C00 (burnt orange)
- Text placeholders: #718096

Heights (relative):
- Hero: 300px
- Content sections: 150-200px
- CTA sections: 200px
- Footer: 80px

Width: 100% with max-width 800px centered
```
