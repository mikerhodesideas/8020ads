---
name: landing-page-audit
description: "Audit a landing page against CRO best practices. Produces a scored evaluation report with prioritized fixes, friction analysis, and blueprint. Use when user asks to audit or review a landing page."
version: 1.0
---

# Landing Page Audit

IMPORTANT: Use the bundled scripts and reference files included with this skill. Do NOT write new scripts.

Systematic, research-backed audit of landing pages receiving paid traffic. Produces a professional HTML report with scoring, prioritized fixes, and actionable recommendations.

## Step 0: Gather Required Information

Ask the user for:
1. **URL** of the page to audit
2. **Prepared by name** - what name/brand should appear on the report
3. **What action should visitors take?** - Form submission, phone call, purchase, etc.
4. **Any ad copy running to this page?** - For message match analysis (optional)

## Step 1: Capture Screenshots

Run the bundled screenshot script:

```bash
node scripts/screenshot.cjs [URL] --output /tmp/audit/screenshots
```

This captures desktop and mobile views at multiple viewports. After capturing, READ the screenshots to visually analyze the page.

If the script fails, use manual Playwright commands:
```bash
npx playwright screenshot [URL] /tmp/audit/screenshots/desktop-fold.png --viewport-size=1440,900
npx playwright screenshot [URL] /tmp/audit/screenshots/mobile-fold.png --viewport-size=375,812
```

If the page blocks bots, ask the user for screenshots manually.

## Step 2: Fetch and Analyze the Page

Fetch the actual page content to extract text, headings, CTAs, form fields, trust signals, testimonials, and navigation structure.

## Step 3: PageSpeed Insights

Ask the user how they want to provide PageSpeed data:
1. **Paste the metrics** - direct them to pagespeed.web.dev, need: Performance Score, FCP, LCP, TBT, CLS
2. **Paste a screenshot** of the results
3. **Skip PageSpeed** - continue without performance data

### PageSpeed Scoring Thresholds

| Metric | Good | Needs Improvement | Poor |
|--------|------|-------------------|------|
| LCP | <=2.5s | 2.5-4s | >4s |
| CLS | <=0.1 | 0.1-0.25 | >0.25 |
| TBT | <=200ms | 200-600ms | >600ms |
| FCP | <=1.8s | 1.8-3s | >3s |

## Step 4: Run the Audit

Score the page against 4 categories from `references/scoring-criteria.md`:

| Category | Weight | Key Focus |
|----------|--------|-----------|
| Message & Value Clarity | 30% | Headlines, value prop, ad match |
| Call-to-Action & Forms | 20% | CTA clarity, form friction |
| Technical Performance | 15% | Speed, Core Web Vitals, mobile |
| Visual Design & UX | 10% | Hierarchy, whitespace, images |

Each criterion scores 0-2. Use `references/audit-checklist.md` for the detailed evaluation. Run friction analysis using `references/friction-analysis.md`. Run mobile checks using `references/mobile-audit.md`.

## Step 5: Prioritize Findings

Rank all issues by Impact (1-5) x Effort (1-5). Use `references/priorities.md` for guidance.

## Step 6: Generate the Report

Generate a single HTML report using `template.css` styling and `report-template.html` structure.

**Required sections:**
1. Cover page
2. Executive Summary with score circle and grade
3. Score Breakdown table
4. Top 3 Priority Fixes
5. Detailed Category Scores
6. Screenshots (base64 embedded)
7. Wireframe Visual (see `page-structure.md`)
8. Section-by-Section Recommendations
9. Developer Handoff
10. Recommendations Summary (Quick Wins, Medium Term, Consider Later)
11. Bottom Line
12. Next Steps

Save to: `/tmp/audit/landing-page-audit-[client-name].html`
Open in browser: `open /tmp/audit/landing-page-audit-[client-name].html`

## Key Statistics

- Headlines can impact conversions by up to 307%
- Pages loading in 1s convert 3x higher than 5s pages
- Reducing form fields from 11 to 4 = 120% more conversions
- Displaying reviews increases conversions up to 270%
- 82.9% of landing page traffic is mobile
- Median conversion rate across industries: 6.6%

## Bundled Resources

| File | Purpose |
|------|---------|
| `page-structure.md` | Editable page section template for blueprints |
| `references/scoring-criteria.md` | Complete evaluation criteria |
| `references/priorities.md` | Priority matrix and conversion killers |
| `references/industry-variations.md` | Industry-specific adaptations |
| `references/report-template.md` | Professional audit report structure |
| `references/research-sources.md` | Source citations for all statistics |
| `references/audit-checklist.md` | Full 50-point checklist |
| `references/discovery-questions.md` | Client intake questions |
| `references/friction-analysis.md` | Friction analysis framework |
| `references/mobile-audit.md` | Mobile-specific checks |
| `scripts/screenshot.cjs` | Automated screenshot capture |
| `template.css` | Report design system |
| `report-template.html` | Report HTML template |
