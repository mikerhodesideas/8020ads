#!/usr/bin/env python3
"""
Meta Campaign Auditor - HTML Report Generator
Reads the analysis JSON and produces a scored HTML report.
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path


def severity_color(severity: str) -> str:
    colors = {
        "critical": "#dc3545",
        "warning": "#f59e0b",
        "info": "#6b7280",
        "good": "#10b981",
    }
    return colors.get(severity, "#6b7280")


def severity_icon(severity: str) -> str:
    icons = {
        "critical": "X",
        "warning": "!",
        "info": "i",
        "good": "&#10003;",
    }
    return icons.get(severity, "i")


def grade_color(grade: str) -> str:
    colors = {
        "A": "#10b981",
        "B": "#3b82f6",
        "C": "#f59e0b",
        "D": "#f97316",
        "F": "#dc3545",
    }
    return colors.get(grade, "#6b7280")


def category_label(key: str) -> str:
    labels = {
        "campaign_structure": "Campaign Structure",
        "adset_config": "Ad Set Configuration",
        "creative_diversity": "Creative Strategy",
        "automation": "Automation & Advantage+",
        "attribution": "Attribution & Tracking",
        "frequency": "Frequency Management",
    }
    return labels.get(key, key.replace("_", " ").title())


def render_findings(findings: list) -> str:
    if not findings:
        return "<p>No findings for this category.</p>"

    html = ""
    for f in findings:
        sev = f.get("severity", "info")
        color = severity_color(sev)
        icon = severity_icon(sev)
        html += f"""
        <div style="border-left: 3px solid {color}; padding: 8px 12px; margin: 8px 0; background: #fafafa;">
            <span style="display:inline-block; width:20px; height:20px; text-align:center;
                         line-height:20px; border-radius:2px; background:{color}; color:#fff;
                         font-size:12px; font-weight:bold; margin-right:8px;">{icon}</span>
            <strong style="color:{color}; text-transform:uppercase; font-size:11px;">{sev}</strong>
            <span style="margin-left:8px;">{f['message']}</span>
        </div>
        """
    return html


def render_score_bar(score: float, label: str, weight: float = 0) -> str:
    if score >= 70:
        color = "#10b981"
    elif score >= 50:
        color = "#f59e0b"
    else:
        color = "#dc3545"

    weight_label = f" ({weight*100:.0f}%)" if weight > 0 else ""

    return f"""
    <div style="margin: 8px 0;">
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="font-weight:500;">{label}{weight_label}</span>
            <span style="font-weight:600;">{score:.0f}/100</span>
        </div>
        <div style="background:#e5e7eb; height:12px; border-radius:1px;">
            <div style="background:{color}; height:12px; width:{min(score, 100):.0f}%;
                        border-radius:1px;"></div>
        </div>
    </div>
    """


def generate_html(analysis: dict, client_name: str = "Client") -> str:
    scoring = analysis.get("scoring", {})
    overall_score = scoring.get("overall_score", 0)
    grade = scoring.get("grade", "?")
    g_color = grade_color(grade)
    category_scores = scoring.get("category_scores", {})
    weights = scoring.get("weights", {})
    top_findings = analysis.get("top_findings", [])
    analyses = analysis.get("analyses", {})
    business_type = analysis.get("business_type", "unknown")
    generated_at = analysis.get("generated_at", datetime.now().isoformat())

    # Build score bars
    score_bars_html = ""
    for key in ["campaign_structure", "adset_config", "creative_diversity",
                "automation", "attribution", "frequency"]:
        s = category_scores.get(key, 50)
        w = weights.get(key, 0)
        score_bars_html += render_score_bar(s, category_label(key), w)

    # Build top findings
    top_findings_html = ""
    for i, f in enumerate(top_findings, 1):
        sev = f.get("severity", "info")
        color = severity_color(sev)
        cat = category_label(f.get("category", ""))
        top_findings_html += f"""
        <div style="border-left: 4px solid {color}; padding: 12px 16px; margin: 12px 0; background: #fafafa;">
            <div style="font-weight:600; margin-bottom:4px;">#{i}. {cat}</div>
            <div>{f['message']}</div>
        </div>
        """

    # Build category sections
    category_sections_html = ""
    for key in ["campaign_structure", "adset_config", "creative_diversity",
                "automation", "attribution", "frequency"]:
        a = analyses.get(key, {})
        findings = a.get("findings", [])
        metrics = a.get("metrics", {})

        metrics_html = ""
        if metrics:
            metrics_html = '<div style="display:flex; flex-wrap:wrap; gap:16px; margin:12px 0;">'
            for mk, mv in metrics.items():
                if isinstance(mv, (dict, list)):
                    continue
                if mv is None:
                    continue
                display_val = f"{mv:,.1f}" if isinstance(mv, float) else str(mv)
                metrics_html += f"""
                <div style="background:#f9fafb; border:1px solid #e5e7eb; padding:8px 16px; border-radius:1px;">
                    <div style="font-size:11px; color:#6b7280; text-transform:uppercase;">{mk.replace('_', ' ')}</div>
                    <div style="font-size:18px; font-weight:600;">{display_val}</div>
                </div>
                """
            metrics_html += "</div>"

        category_sections_html += f"""
        <div style="margin: 32px 0; page-break-inside: avoid;">
            <h2 style="border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">
                {category_label(key)}
                <span style="float:right; font-size:16px; color:{severity_color('good') if a.get('score', 0) >= 70 else severity_color('warning') if a.get('score', 0) >= 50 else severity_color('critical')};">
                    {a.get('score', 'N/A')}/100
                </span>
            </h2>
            {metrics_html}
            {render_findings(findings)}
        </div>
        """

    # Recommendations
    quick_wins = []
    medium_term = []
    long_term = []
    for f in top_findings:
        sev = f.get("severity", "info")
        if sev == "critical":
            quick_wins.append(f["message"])
        elif sev == "warning":
            medium_term.append(f["message"])
        else:
            long_term.append(f["message"])

    def render_rec_list(items, title, color):
        if not items:
            return ""
        lis = "".join(f"<li style='margin:4px 0;'>{item}</li>" for item in items)
        return f"""
        <div style="flex:1; min-width:250px; border-left:3px solid {color}; padding:12px;">
            <h3 style="margin:0 0 8px 0;">{title}</h3>
            <ul style="padding-left:16px; margin:0;">{lis}</ul>
        </div>
        """

    recs_html = f"""
    <div style="display:flex; gap:24px; flex-wrap:wrap; margin:16px 0;">
        {render_rec_list(quick_wins, "Fix Now", "#dc3545")}
        {render_rec_list(medium_term, "Fix Soon", "#f59e0b")}
        {render_rec_list(long_term, "Consider", "#6b7280")}
    </div>
    """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meta Ads Audit - {client_name}</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                line-height: 1.6; color: #1f2937; background: #fff; max-width: 900px;
                margin: 0 auto; padding: 32px 24px; }}
        h1 {{ font-size: 28px; margin-bottom: 4px; }}
        h2 {{ font-size: 20px; color: #374151; }}
        h3 {{ font-size: 16px; color: #374151; }}
        p {{ margin: 8px 0; }}
        @media print {{
            body {{ padding: 0; max-width: 100%; }}
            .no-print {{ display: none; }}
        }}
    </style>
</head>
<body>

    <!-- Cover -->
    <div style="text-align:center; padding:48px 0 32px; border-bottom:3px solid #1f2937;">
        <h1>Meta Ads Account Audit</h1>
        <p style="font-size:18px; color:#6b7280;">{client_name}</p>
        <p style="font-size:14px; color:#9ca3af;">
            Generated {generated_at[:10]} | Business type: {business_type}
        </p>
    </div>

    <!-- Executive Summary -->
    <div style="margin: 32px 0; padding: 24px; background: #f9fafb; border: 1px solid #e5e7eb;">
        <div style="display:flex; align-items:center; gap:24px;">
            <div style="text-align:center;">
                <div style="width:80px; height:80px; border-radius:50%; border:4px solid {g_color};
                            display:flex; align-items:center; justify-content:center;">
                    <span style="font-size:28px; font-weight:700; color:{g_color};">{overall_score:.0f}</span>
                </div>
                <div style="font-size:24px; font-weight:700; color:{g_color}; margin-top:4px;">
                    Grade: {grade}
                </div>
            </div>
            <div style="flex:1;">
                <h2 style="margin-bottom:8px; border:none;">Executive Summary</h2>
                <p>This audit analyzed the Meta Ads account across 6 dimensions:
                   campaign structure, ad set configuration, creative strategy,
                   automation settings, attribution, and frequency management.</p>
            </div>
        </div>
    </div>

    <!-- Score Breakdown -->
    <div style="margin: 32px 0;">
        <h2 style="margin-bottom:16px;">Score Breakdown</h2>
        {score_bars_html}
    </div>

    <!-- Top Findings -->
    <div style="margin: 32px 0;">
        <h2 style="margin-bottom:16px;">Top Priority Findings</h2>
        {top_findings_html}
    </div>

    <!-- Category Details -->
    {category_sections_html}

    <!-- Recommendations -->
    <div style="margin: 32px 0;">
        <h2 style="margin-bottom:16px;">Recommendations Summary</h2>
        {recs_html}
    </div>

    <!-- Next Steps -->
    <div style="margin: 32px 0; padding: 24px; background: #f0fdf4; border-left: 4px solid #10b981;">
        <h2 style="margin-bottom:12px;">Next Steps</h2>
        <ol style="padding-left:20px;">
            <li style="margin:6px 0;">Address all critical findings immediately (see Fix Now above)</li>
            <li style="margin:6px 0;">Run the <strong>Meta Creative Analyzer</strong> for a deeper creative deep-dive</li>
            <li style="margin:6px 0;">Implement warning-level fixes over the next 2 weeks</li>
            <li style="margin:6px 0;">Re-audit in 30 days to measure improvement</li>
        </ol>
    </div>

    <div style="text-align:center; padding:24px 0; margin-top:32px; border-top:1px solid #e5e7eb;
                color:#9ca3af; font-size:12px;">
        Generated by Meta Campaign Auditor | {datetime.now().strftime('%Y-%m-%d %H:%M')}
    </div>

</body>
</html>"""

    return html


def main():
    parser = argparse.ArgumentParser(description="Generate Meta Ads audit HTML report")
    parser.add_argument("--analysis", required=True, help="Path to analysis.json")
    parser.add_argument("--output", required=True, help="Output HTML file path")
    parser.add_argument("--client-name", default="Client", help="Client name for report header")
    args = parser.parse_args()

    with open(args.analysis) as f:
        analysis = json.load(f)

    html = generate_html(analysis, args.client_name)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w") as f:
        f.write(html)

    print(f"Report generated: {args.output}")


if __name__ == "__main__":
    main()
