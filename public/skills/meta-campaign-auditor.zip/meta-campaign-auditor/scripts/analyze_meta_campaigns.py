#!/usr/bin/env python3
"""
Meta Campaign Auditor - CSV Analysis Script
Processes Meta Ads Manager CSV exports and produces structured analysis JSON.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from datetime import datetime

import pandas as pd
import numpy as np


# ---------------------------------------------------------------------------
# Column name normalization
# ---------------------------------------------------------------------------

COLUMN_ALIASES = {
    # Campaign level
    "campaign name": "campaign_name",
    "campaign_name": "campaign_name",
    "campaign id": "campaign_id",
    "campaign budget optimization": "budget_type",
    "campaign objective": "objective",
    "buying type": "buying_type",
    # Ad set level
    "ad set name": "adset_name",
    "adset name": "adset_name",
    "ad set id": "adset_id",
    "adset id": "adset_id",
    "ad set budget": "adset_budget",
    "budget": "adset_budget",
    "daily budget": "daily_budget",
    "lifetime budget": "lifetime_budget",
    "targeting": "targeting",
    "audience": "audience",
    "placement": "placement",
    "optimization goal": "optimization_goal",
    "attribution setting": "attribution_setting",
    "delivery status": "delivery_status",
    # Ad level
    "ad name": "ad_name",
    "ad id": "ad_id",
    "creative": "creative",
    "body": "body",
    "title": "title",
    "call to action": "cta",
    # Metrics (common)
    "amount spent (usd)": "spend",
    "amount spent": "spend",
    "spend": "spend",
    "cost": "spend",
    "impressions": "impressions",
    "reach": "reach",
    "frequency": "frequency",
    "clicks (all)": "clicks_all",
    "link clicks": "link_clicks",
    "ctr (all)": "ctr_all",
    "ctr (link click-through rate)": "ctr_link",
    "cpc (all)": "cpc_all",
    "cpc (cost per link click)": "cpc_link",
    "cpm (cost per 1,000 impressions)": "cpm",
    "cpm": "cpm",
    "results": "results",
    "result type": "result_type",
    "cost per result": "cost_per_result",
    "result rate": "result_rate",
    # Conversions
    "purchases": "purchases",
    "purchase roas (return on ad spend)": "roas",
    "roas": "roas",
    "website purchases": "purchases",
    "leads": "leads",
    "add to cart": "add_to_cart",
    "initiate checkout": "initiate_checkout",
    "purchase conversion value": "purchase_value",
    "website purchase roas": "roas",
    # Video
    "3-second video views": "video_views_3s",
    "video views": "video_views_3s",
    "thruplay": "thruplay",
    "thruplay actions": "thruplay",
    "video average play time": "video_avg_play_time",
    "video plays": "video_plays",
    # Dates
    "reporting starts": "date_start",
    "reporting ends": "date_end",
    "day": "date",
    "date": "date",
}


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize column names to canonical form."""
    rename_map = {}
    for col in df.columns:
        lower = col.strip().lower()
        if lower in COLUMN_ALIASES:
            rename_map[col] = COLUMN_ALIASES[lower]
    df = df.rename(columns=rename_map)
    return df


def to_numeric_safe(series: pd.Series) -> pd.Series:
    """Convert to numeric, handling currency symbols and commas."""
    if series.dtype in (np.float64, np.int64, float, int):
        return series
    return pd.to_numeric(
        series.astype(str)
        .str.replace(r"[$,€£]", "", regex=True)
        .str.replace(r"\s+", "", regex=True)
        .str.strip(),
        errors="coerce",
    )


# ---------------------------------------------------------------------------
# Data level detection
# ---------------------------------------------------------------------------

def detect_data_level(df: pd.DataFrame) -> str:
    """Detect whether a DataFrame is campaign, ad set, or ad level data."""
    cols = set(df.columns)
    if "ad_name" in cols or "ad_id" in cols:
        return "ad"
    if "adset_name" in cols or "adset_id" in cols:
        return "adset"
    return "campaign"


def load_csvs(input_path: str) -> dict:
    """Load CSV files and return dict keyed by data level."""
    path = Path(input_path).expanduser()
    frames = {"campaign": None, "adset": None, "ad": None}

    csv_files = []
    if path.is_dir():
        csv_files = list(path.glob("*.csv"))
    elif path.is_file() and path.suffix.lower() == ".csv":
        csv_files = [path]
    else:
        print(f"Error: {input_path} is not a valid CSV file or directory", file=sys.stderr)
        sys.exit(1)

    if not csv_files:
        print(f"Error: No CSV files found at {input_path}", file=sys.stderr)
        sys.exit(1)

    for csv_file in csv_files:
        # Try different encodings
        for encoding in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
            try:
                df = pd.read_csv(csv_file, encoding=encoding)
                break
            except (UnicodeDecodeError, pd.errors.ParserError):
                continue
        else:
            print(f"Warning: Could not read {csv_file}, skipping", file=sys.stderr)
            continue

        df = normalize_columns(df)
        level = detect_data_level(df)

        # Convert numeric columns
        numeric_cols = [
            "spend", "impressions", "reach", "frequency", "clicks_all",
            "link_clicks", "ctr_all", "ctr_link", "cpc_all", "cpc_link",
            "cpm", "results", "cost_per_result", "roas", "purchases",
            "purchase_value", "leads", "add_to_cart", "initiate_checkout",
            "video_views_3s", "thruplay", "daily_budget", "lifetime_budget",
            "adset_budget",
        ]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = to_numeric_safe(df[col])

        if frames[level] is None:
            frames[level] = df
        else:
            frames[level] = pd.concat([frames[level], df], ignore_index=True)

        print(f"Loaded {csv_file.name} as {level}-level data ({len(df)} rows)")

    return frames


# ---------------------------------------------------------------------------
# Analysis functions
# ---------------------------------------------------------------------------

def analyze_campaign_structure(df_campaign: pd.DataFrame, business_type: str) -> dict:
    """Analyze campaign structure: objectives, CBO/ABO, count."""
    result = {
        "score": 0,
        "max_score": 100,
        "findings": [],
        "metrics": {},
    }

    if df_campaign is None or df_campaign.empty:
        result["findings"].append({
            "severity": "warning",
            "message": "No campaign-level data provided. Campaign structure analysis limited.",
        })
        result["score"] = 50
        return result

    n_campaigns = len(df_campaign)
    result["metrics"]["campaign_count"] = n_campaigns

    score = 100

    # Campaign count check
    if n_campaigns > 15:
        score -= 20
        result["findings"].append({
            "severity": "critical",
            "message": f"{n_campaigns} active campaigns detected. Budget fragmentation is likely. Consolidate to 3-7 campaigns.",
        })
    elif n_campaigns < 3:
        score -= 10
        result["findings"].append({
            "severity": "warning",
            "message": f"Only {n_campaigns} campaign(s). Consider adding campaigns for different objectives or funnel stages.",
        })
    else:
        result["findings"].append({
            "severity": "good",
            "message": f"{n_campaigns} campaigns is a healthy count for most accounts.",
        })

    # Objective analysis
    if "objective" in df_campaign.columns:
        objectives = df_campaign["objective"].dropna().unique().tolist()
        result["metrics"]["objectives"] = objectives
        result["metrics"]["objective_count"] = len(objectives)

        objective_alignment = {
            "ecommerce": ["OUTCOME_SALES", "Sales", "Conversions", "CONVERSIONS"],
            "leadgen": ["OUTCOME_LEADS", "Lead generation", "Leads", "LEAD_GENERATION", "Conversions", "CONVERSIONS"],
            "app": ["OUTCOME_APP_PROMOTION", "App installs", "APP_INSTALLS"],
            "awareness": ["OUTCOME_AWARENESS", "Brand awareness", "Reach", "BRAND_AWARENESS", "REACH"],
        }
        expected = objective_alignment.get(business_type, [])

        if "spend" in df_campaign.columns:
            total_spend = df_campaign["spend"].sum()
            for _, row in df_campaign.iterrows():
                obj = str(row.get("objective", "")).strip()
                camp_spend = row.get("spend", 0) or 0
                if obj and expected and not any(e.lower() in obj.lower() for e in expected):
                    pct = (camp_spend / total_spend * 100) if total_spend > 0 else 0
                    if pct > 10:
                        score -= 10
                        result["findings"].append({
                            "severity": "warning",
                            "message": f"Campaign '{row.get('campaign_name', 'Unknown')}' uses objective '{obj}' "
                                       f"which may not align with {business_type} goals ({pct:.0f}% of spend).",
                        })

    # CBO vs ABO
    if "budget_type" in df_campaign.columns:
        cbo_count = df_campaign["budget_type"].str.contains("CBO|campaign", case=False, na=False).sum()
        abo_count = n_campaigns - cbo_count
        result["metrics"]["cbo_campaigns"] = int(cbo_count)
        result["metrics"]["abo_campaigns"] = int(abo_count)

        if abo_count > cbo_count and n_campaigns > 2:
            score -= 10
            result["findings"].append({
                "severity": "warning",
                "message": f"More ABO ({abo_count}) than CBO ({cbo_count}) campaigns. CBO is generally preferred "
                           "for better budget distribution. Review whether ABO campaigns need manual budget control.",
            })
    elif "daily_budget" in df_campaign.columns or "lifetime_budget" in df_campaign.columns:
        result["findings"].append({
            "severity": "info",
            "message": "Budget type column not found. Could not determine CBO vs ABO split.",
        })

    # Naming convention check
    if "campaign_name" in df_campaign.columns:
        names = df_campaign["campaign_name"].dropna().tolist()
        has_separator = sum(1 for n in names if any(sep in str(n) for sep in [" - ", " | ", "_"])) / max(len(names), 1)
        if has_separator < 0.5:
            score -= 5
            result["findings"].append({
                "severity": "info",
                "message": "Campaign names lack consistent separators. A naming convention "
                           "(e.g., 'Objective - Audience - Funnel Stage') improves organization.",
            })

    result["score"] = max(0, score)
    return result


def analyze_adset_config(df_adset: pd.DataFrame) -> dict:
    """Analyze ad set configuration: audiences, budgets, placements."""
    result = {
        "score": 0,
        "max_score": 100,
        "findings": [],
        "metrics": {},
    }

    if df_adset is None or df_adset.empty:
        result["findings"].append({
            "severity": "warning",
            "message": "No ad set-level data provided. Ad set analysis limited.",
        })
        result["score"] = 50
        return result

    n_adsets = len(df_adset)
    result["metrics"]["adset_count"] = n_adsets
    score = 100

    # Budget distribution
    if "spend" in df_adset.columns:
        total_spend = df_adset["spend"].sum()
        result["metrics"]["total_spend"] = float(total_spend)

        if total_spend > 0:
            spend_pcts = (df_adset["spend"] / total_spend * 100).fillna(0)

            # Flag under-budget ad sets
            if "daily_budget" in df_adset.columns:
                low_budget = df_adset[df_adset["daily_budget"] < 5]
                if len(low_budget) > 0:
                    score -= 10
                    result["findings"].append({
                        "severity": "warning",
                        "message": f"{len(low_budget)} ad set(s) have daily budgets below $5. "
                                   "This is usually insufficient for the algorithm to learn.",
                    })

            # Flag concentration
            max_pct = spend_pcts.max()
            if max_pct > 80 and n_adsets > 2:
                score -= 5
                result["findings"].append({
                    "severity": "info",
                    "message": f"One ad set consumes {max_pct:.0f}% of total spend. "
                               "Verify this is intentional and not CBO over-allocating.",
                })

    # Ad set count per campaign
    if "campaign_name" in df_adset.columns:
        adsets_per_campaign = df_adset.groupby("campaign_name").size()
        result["metrics"]["adsets_per_campaign"] = adsets_per_campaign.to_dict()

        over_split = adsets_per_campaign[adsets_per_campaign > 10]
        if len(over_split) > 0:
            score -= 15
            for camp, count in over_split.items():
                result["findings"].append({
                    "severity": "critical",
                    "message": f"Campaign '{camp}' has {count} ad sets. This splits budget too thin "
                               "and prevents the algorithm from learning. Consolidate to 3-5 ad sets.",
                })

    # Frequency analysis
    if "frequency" in df_adset.columns:
        high_freq = df_adset[df_adset["frequency"] > 3.0]
        if len(high_freq) > 0:
            score -= 5
            result["findings"].append({
                "severity": "warning",
                "message": f"{len(high_freq)} ad set(s) have frequency >3. "
                           "High frequency in prospecting causes fatigue. Check if these are retargeting.",
            })
        avg_freq = df_adset["frequency"].mean()
        result["metrics"]["avg_frequency"] = float(avg_freq) if not pd.isna(avg_freq) else None

    # Placement analysis
    if "placement" in df_adset.columns:
        placements = df_adset.groupby("placement").agg({
            "spend": "sum",
            "results": "sum",
            "impressions": "sum",
        }).reset_index()
        placements["cpa"] = placements.apply(
            lambda r: r["spend"] / r["results"] if r["results"] > 0 else None, axis=1
        )
        result["metrics"]["placement_breakdown"] = placements.to_dict(orient="records")

        # Flag Audience Network
        an_rows = placements[placements["placement"].str.contains("audience.network", case=False, na=False)]
        if not an_rows.empty:
            an_spend = an_rows["spend"].sum()
            an_pct = (an_spend / placements["spend"].sum() * 100) if placements["spend"].sum() > 0 else 0
            if an_pct > 15:
                score -= 10
                result["findings"].append({
                    "severity": "warning",
                    "message": f"Audience Network receives {an_pct:.0f}% of spend. "
                               "Check CPA vs other placements; it often delivers low-quality traffic.",
                })

    # CPM analysis
    if "cpm" in df_adset.columns:
        avg_cpm = df_adset["cpm"].mean()
        result["metrics"]["avg_cpm"] = float(avg_cpm) if not pd.isna(avg_cpm) else None

    result["score"] = max(0, score)
    return result


def analyze_creative_diversity(df_ad: pd.DataFrame, business_type: str) -> dict:
    """Analyze creative format mix, volume, fatigue signals."""
    result = {
        "score": 0,
        "max_score": 100,
        "findings": [],
        "metrics": {},
    }

    if df_ad is None or df_ad.empty:
        result["findings"].append({
            "severity": "warning",
            "message": "No ad-level data provided. Creative analysis limited.",
        })
        result["score"] = 50
        return result

    n_ads = len(df_ad)
    result["metrics"]["total_ads"] = n_ads
    score = 100

    # Detect format from ad name or format column
    def detect_format(row):
        for col in ("creative", "ad_name"):
            if col in row.index and pd.notna(row[col]):
                name = str(row[col]).lower()
                if "video" in name:
                    return "video"
                if "carousel" in name:
                    return "carousel"
                if "collection" in name or "instant experience" in name:
                    return "collection"
        # Fallback: check for video metrics
        if "video_views_3s" in row.index and pd.notna(row.get("video_views_3s")) and row.get("video_views_3s", 0) > 0:
            return "video"
        return "image"

    df_ad = df_ad.copy()
    df_ad["format"] = df_ad.apply(detect_format, axis=1)

    format_counts = df_ad["format"].value_counts().to_dict()
    result["metrics"]["format_distribution"] = format_counts

    # Format mix scoring
    format_set = set(format_counts.keys())
    dominant_pct = max(format_counts.values()) / n_ads * 100 if n_ads > 0 else 0

    if dominant_pct > 80:
        score -= 15
        dominant_format = max(format_counts, key=format_counts.get)
        result["findings"].append({
            "severity": "warning",
            "message": f"{dominant_pct:.0f}% of ads are {dominant_format}. "
                       "Test more formats for better performance discovery.",
        })

    if "video" not in format_set:
        score -= 10
        result["findings"].append({
            "severity": "warning",
            "message": "No video ads detected. Video typically outperforms static on Meta. "
                       "Consider adding video creatives.",
        })

    if len(format_set) >= 3:
        result["findings"].append({
            "severity": "good",
            "message": f"Good format variety: {', '.join(format_set)}.",
        })

    # Ads per ad set
    if "adset_name" in df_ad.columns:
        ads_per_adset = df_ad.groupby("adset_name").size()
        result["metrics"]["avg_ads_per_adset"] = float(ads_per_adset.mean())

        single_ad = ads_per_adset[ads_per_adset == 1]
        if len(single_ad) > 0:
            score -= 10
            result["findings"].append({
                "severity": "warning",
                "message": f"{len(single_ad)} ad set(s) have only 1 ad. "
                           "You need 3-6 ads per ad set for proper creative testing.",
            })

        overloaded = ads_per_adset[ads_per_adset > 10]
        if len(overloaded) > 0:
            score -= 5
            result["findings"].append({
                "severity": "info",
                "message": f"{len(overloaded)} ad set(s) have >10 ads. "
                           "Budget is spread too thin across creatives. Consolidate to best performers.",
            })

    # Video hook rate
    if "video_views_3s" in df_ad.columns and "impressions" in df_ad.columns:
        video_ads = df_ad[df_ad["format"] == "video"].copy()
        if not video_ads.empty:
            video_ads["hook_rate"] = video_ads["video_views_3s"] / video_ads["impressions"] * 100
            avg_hook = video_ads["hook_rate"].mean()
            result["metrics"]["avg_hook_rate"] = float(avg_hook) if not pd.isna(avg_hook) else None

            if avg_hook < 15:
                score -= 10
                result["findings"].append({
                    "severity": "critical",
                    "message": f"Average video hook rate is {avg_hook:.1f}% (poor, <15%). "
                               "First 3 seconds need stronger hooks.",
                })
            elif avg_hook < 25:
                result["findings"].append({
                    "severity": "info",
                    "message": f"Average video hook rate is {avg_hook:.1f}% (average). "
                               "Room for improvement; target >25%.",
                })

    # ThruPlay hold rate
    if "thruplay" in df_ad.columns and "video_views_3s" in df_ad.columns:
        video_ads = df_ad[(df_ad["format"] == "video") & (df_ad["video_views_3s"] > 0)].copy()
        if not video_ads.empty:
            video_ads["hold_rate"] = video_ads["thruplay"] / video_ads["video_views_3s"] * 100
            avg_hold = video_ads["hold_rate"].mean()
            result["metrics"]["avg_hold_rate"] = float(avg_hold) if not pd.isna(avg_hold) else None

    # Fatigue indicators (frequency + CTR)
    if "frequency" in df_ad.columns and "ctr_link" in df_ad.columns:
        fatigued = df_ad[(df_ad["frequency"] > 3) & (df_ad["ctr_link"] < df_ad["ctr_link"].median() * 0.8)]
        result["metrics"]["potentially_fatigued_ads"] = len(fatigued)
        if len(fatigued) > 0:
            score -= 5
            result["findings"].append({
                "severity": "warning",
                "message": f"{len(fatigued)} ads show fatigue signals (high frequency + below-median CTR). "
                           "Consider refreshing or pausing.",
            })

    result["score"] = max(0, score)
    return result


def analyze_automation(df_campaign: pd.DataFrame, df_adset: pd.DataFrame) -> dict:
    """Analyze Advantage+ settings and learning phase status."""
    result = {
        "score": 0,
        "max_score": 100,
        "findings": [],
        "metrics": {},
    }
    score = 80  # Start at 80 since we often lack full data

    if df_adset is not None and "delivery_status" in df_adset.columns:
        learning = df_adset[df_adset["delivery_status"].str.contains("learning", case=False, na=False)]
        learning_limited = df_adset[
            df_adset["delivery_status"].str.contains("learning limited", case=False, na=False)
        ]
        result["metrics"]["learning_phase_count"] = len(learning)
        result["metrics"]["learning_limited_count"] = len(learning_limited)

        if len(learning_limited) > 0:
            score -= 15
            result["findings"].append({
                "severity": "critical",
                "message": f"{len(learning_limited)} ad set(s) are 'Learning Limited'. "
                           "They are not getting enough conversion events (~50/week) to optimize. "
                           "Consider: increasing budget, broadening audience, or optimizing for a "
                           "higher-funnel event.",
            })
    else:
        result["findings"].append({
            "severity": "info",
            "message": "Delivery status data not available. Could not assess learning phase status. "
                       "Export with delivery status column for this check.",
        })

    result["score"] = max(0, score)
    return result


def analyze_attribution(df_campaign: pd.DataFrame, df_adset: pd.DataFrame) -> dict:
    """Analyze attribution windows and conversion events."""
    result = {
        "score": 0,
        "max_score": 100,
        "findings": [],
        "metrics": {},
    }
    score = 80

    if df_adset is not None and "attribution_setting" in df_adset.columns:
        attr_settings = df_adset["attribution_setting"].dropna().unique().tolist()
        result["metrics"]["attribution_windows"] = attr_settings

        for setting in attr_settings:
            s = str(setting).lower()
            if "1 day" in s and "click" in s and "view" not in s:
                score -= 15
                result["findings"].append({
                    "severity": "warning",
                    "message": f"Attribution window '{setting}' is very narrow. "
                               "1-day click only misses view-through conversions. "
                               "Recommended: 7-day click, 1-day view.",
                })
    else:
        result["findings"].append({
            "severity": "info",
            "message": "Attribution setting column not found. Cannot verify attribution windows. "
                       "Check this manually in Ads Manager.",
        })

    # Conversion event analysis
    if df_adset is not None and "optimization_goal" in df_adset.columns:
        opt_goals = df_adset["optimization_goal"].dropna().value_counts().to_dict()
        result["metrics"]["optimization_goals"] = opt_goals
    elif df_campaign is not None and "result_type" in df_campaign.columns:
        result_types = df_campaign["result_type"].dropna().value_counts().to_dict()
        result["metrics"]["result_types"] = result_types

    result["score"] = max(0, score)
    return result


def analyze_frequency(df_adset: pd.DataFrame, df_campaign: pd.DataFrame) -> dict:
    """Analyze frequency and reach efficiency."""
    result = {
        "score": 0,
        "max_score": 100,
        "findings": [],
        "metrics": {},
    }
    score = 90

    source = df_adset if df_adset is not None else df_campaign
    if source is None or source.empty:
        result["score"] = 50
        return result

    if "frequency" in source.columns:
        avg_freq = source["frequency"].mean()
        max_freq = source["frequency"].max()
        result["metrics"]["avg_frequency"] = float(avg_freq) if not pd.isna(avg_freq) else None
        result["metrics"]["max_frequency"] = float(max_freq) if not pd.isna(max_freq) else None

        if avg_freq > 3:
            score -= 20
            result["findings"].append({
                "severity": "critical",
                "message": f"Account average frequency is {avg_freq:.1f}. This is high for prospecting. "
                           "Users are seeing ads too many times, causing fatigue and wasted spend.",
            })
        elif avg_freq > 2:
            score -= 10
            result["findings"].append({
                "severity": "warning",
                "message": f"Account average frequency is {avg_freq:.1f}. Getting high. "
                           "Monitor closely, especially prospecting campaigns.",
            })
        else:
            result["findings"].append({
                "severity": "good",
                "message": f"Account average frequency is {avg_freq:.1f}. Healthy range.",
            })

    if "reach" in source.columns and "impressions" in source.columns:
        total_reach = source["reach"].sum()
        total_imps = source["impressions"].sum()
        if total_reach > 0:
            result["metrics"]["overall_frequency_calc"] = float(total_imps / total_reach)

    result["score"] = max(0, score)
    return result


def compute_overall_score(analyses: dict) -> dict:
    """Compute weighted overall score from category analyses."""
    weights = {
        "campaign_structure": 0.20,
        "adset_config": 0.25,
        "creative_diversity": 0.25,
        "automation": 0.10,
        "attribution": 0.15,
        "frequency": 0.05,
    }

    weighted_sum = 0
    total_weight = 0
    category_scores = {}

    for key, weight in weights.items():
        if key in analyses:
            s = analyses[key].get("score", 50)
            category_scores[key] = s
            weighted_sum += s * weight
            total_weight += weight

    overall = weighted_sum / total_weight if total_weight > 0 else 50

    if overall >= 85:
        grade = "A"
    elif overall >= 70:
        grade = "B"
    elif overall >= 55:
        grade = "C"
    elif overall >= 40:
        grade = "D"
    else:
        grade = "F"

    return {
        "overall_score": round(overall, 1),
        "grade": grade,
        "category_scores": category_scores,
        "weights": weights,
    }


def collect_top_findings(analyses: dict, n: int = 5) -> list:
    """Collect the top N most critical findings across all categories."""
    severity_rank = {"critical": 0, "warning": 1, "info": 2, "good": 3}
    all_findings = []

    for category, analysis in analyses.items():
        for finding in analysis.get("findings", []):
            all_findings.append({
                "category": category,
                **finding,
            })

    all_findings.sort(key=lambda f: severity_rank.get(f.get("severity", "info"), 2))
    return all_findings[:n]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Analyze Meta Ads CSV exports")
    parser.add_argument("--input", required=True, help="Path to CSV file or folder of CSVs")
    parser.add_argument("--business-type", default="ecommerce",
                        choices=["ecommerce", "leadgen", "app", "awareness"],
                        help="Business type for contextual scoring")
    parser.add_argument("--output", default="/tmp/meta-audit/",
                        help="Output directory for analysis JSON")
    args = parser.parse_args()

    # Create output directory
    os.makedirs(args.output, exist_ok=True)

    print("=" * 60)
    print("Meta Campaign Auditor - CSV Analysis")
    print("=" * 60)

    # Load data
    print("\nLoading CSV files...")
    data = load_csvs(args.input)

    loaded = [k for k, v in data.items() if v is not None]
    if not loaded:
        print("Error: No valid data loaded. Check your CSV files.", file=sys.stderr)
        sys.exit(1)

    print(f"\nData levels found: {', '.join(loaded)}")
    for level, df in data.items():
        if df is not None:
            print(f"  {level}: {len(df)} rows, {len(df.columns)} columns")

    # Run analyses
    print("\nRunning analysis...")

    analyses = {}

    print("  Campaign structure...")
    analyses["campaign_structure"] = analyze_campaign_structure(
        data.get("campaign") or data.get("adset") or data.get("ad"),
        args.business_type,
    )

    print("  Ad set configuration...")
    analyses["adset_config"] = analyze_adset_config(
        data.get("adset") or data.get("ad"),
    )

    print("  Creative diversity...")
    analyses["creative_diversity"] = analyze_creative_diversity(
        data.get("ad"),
        args.business_type,
    )

    print("  Automation & Advantage+...")
    analyses["automation"] = analyze_automation(
        data.get("campaign"),
        data.get("adset"),
    )

    print("  Attribution & tracking...")
    analyses["attribution"] = analyze_attribution(
        data.get("campaign"),
        data.get("adset"),
    )

    print("  Frequency management...")
    analyses["frequency"] = analyze_frequency(
        data.get("adset"),
        data.get("campaign"),
    )

    # Overall scoring
    print("  Computing overall score...")
    scoring = compute_overall_score(analyses)
    top_findings = collect_top_findings(analyses)

    # Build output
    output = {
        "generated_at": datetime.now().isoformat(),
        "business_type": args.business_type,
        "data_levels_loaded": loaded,
        "scoring": scoring,
        "top_findings": top_findings,
        "analyses": analyses,
    }

    output_path = os.path.join(args.output, "analysis.json")
    with open(output_path, "w") as f:
        json.dump(output, f, indent=2, default=str)

    print(f"\n{'=' * 60}")
    print(f"Overall Score: {scoring['overall_score']}/100 (Grade: {scoring['grade']})")
    print(f"{'=' * 60}")
    print(f"\nTop findings:")
    for i, finding in enumerate(top_findings, 1):
        severity = finding.get("severity", "info").upper()
        print(f"  {i}. [{severity}] {finding['message']}")

    print(f"\nAnalysis saved to: {output_path}")
    return output


if __name__ == "__main__":
    main()
