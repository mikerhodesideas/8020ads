---
name: meta-campaign-auditor
description: |
  Comprehensive Meta Ads account audit from exported CSV data. Analyzes campaign structure,
  ad set config, creative diversity, Advantage+ settings, attribution, and more.
  USE WHEN user asks to audit a Meta/Facebook Ads account, review Meta campaign performance,
  or analyze Meta Ads exports.
  Triggers: "meta audit", "facebook ads audit", "meta ads review", "audit meta account",
  "meta campaign analysis", "facebook campaign audit"
version: 1.0
last_updated: 2026-03-21
members: true
---

# Meta Campaign Auditor

Produce a comprehensive audit of a Meta Ads account from exported CSV data. Analyzes campaign structure, ad set configuration, creative performance, Advantage+ settings, attribution, and conversion events. Flags common mistakes and outputs a scored HTML report.

## Trigger

- User mentions auditing a Meta Ads or Facebook Ads account
- User provides Meta Ads CSV exports and asks for analysis
- User says "meta audit", "facebook ads audit", or similar

## Command Format

```
/meta-campaign-auditor [path-to-csv-folder-or-file]
```

**Examples:**
- `/meta-campaign-auditor ~/Downloads/meta-export/` - Audit from a folder of CSVs
- `/meta-campaign-auditor ~/Desktop/campaign-report.csv` - Audit from a single file

## Required Data

The skill works with CSV exports from Meta Ads Manager. Ask the user to export at these levels:

1. **Campaign-level data** (required): Campaign name, objective, budget type (CBO/ABO), spend, results, cost per result, impressions, reach, frequency, ROAS
2. **Ad set-level data** (required): Ad set name, campaign name, audience, placements, budget, spend, results, cost per result, impressions, reach, frequency, CPM
3. **Ad-level data** (required): Ad name, ad set name, format (video/image/carousel/collection), spend, impressions, clicks, CTR, results, cost per result, video views (3s, ThruPlay), link clicks

**Optional but valuable:**
- Breakdown by placement (Facebook Feed, Instagram Stories, Audience Network, etc.)
- Breakdown by device
- Event Match Quality data (from Events Manager export)
- Audience overlap report

### How to Export from Meta Ads Manager

Tell the user:
> In Meta Ads Manager:
> 1. Select the date range you want to audit (last 30 or 90 days recommended)
> 2. Go to the Campaigns tab, click "Reports" > "Export Table Data" > CSV
> 3. Repeat for Ad Sets tab and Ads tab
> 4. For placement breakdown: select Campaigns tab, click "Breakdown" > "By delivery" > "Placement", then export
>
> Save all CSVs to one folder and give me the path.

## Process

### Step 0: Gather Context

Use AskUserQuestion to collect:

1. **CSV location** - Path to folder or individual files
2. **Business type** - E-commerce, lead gen, app install, or brand awareness
3. **Monthly budget** - Approximate monthly Meta spend (for context)
4. **Key conversion event** - Purchase, Lead, AddToCart, etc.
5. **Any known issues?** - Optional: anything specific they want checked

### Step 1: Load and Validate Data

Run the analysis script:

```bash
python3 .claude/skills/meta-campaign-auditor/scripts/analyze_meta_campaigns.py \
  --input "[path-to-csv-or-folder]" \
  --business-type "[ecommerce|leadgen|app|awareness]" \
  --output /tmp/meta-audit/
```

The script will:
- Auto-detect which CSV contains campaign, ad set, and ad level data
- Normalize column names (Meta exports vary by language/settings)
- Validate required columns exist
- Output structured JSON analysis to `/tmp/meta-audit/analysis.json`

If the script fails due to missing columns or unexpected format, ask the user to re-export or clarify which columns map to what.

### Step 2: Campaign Structure Analysis

Evaluate and score these dimensions:

**2a. Campaign Objective Alignment**
- Are campaign objectives matched to business goals?
- Flag mismatches: e.g., Traffic objective for an e-commerce store that should use Sales
- Check for too many campaigns with overlapping objectives
- Ideal: 3-7 active campaigns for most accounts

**2b. CBO vs ABO Usage**
- CBO (Campaign Budget Optimization) preferred for most use cases in 2025+
- ABO acceptable for testing new audiences or when ad sets have very different budgets
- Flag: ABO campaigns where all ad sets have similar budgets (should be CBO)
- Flag: More than 50% of spend on ABO without clear testing rationale

**2c. Campaign Count & Organization**
- Too many campaigns (>15 active) = budget fragmentation
- Too few (<3) = insufficient segmentation
- Check naming conventions for consistency
- Flag duplicate or near-duplicate campaigns

### Step 3: Ad Set Configuration Audit

**3a. Audience Overlap Detection**
- Compare audience definitions across ad sets
- Flag ad sets in different campaigns targeting the same interests/demographics
- Self-competition wastes budget and inflates CPMs
- Score: percentage of ad sets with likely overlap

**3b. Budget Distribution**
- Flag ad sets with <$5/day (insufficient for learning)
- Flag single ad sets consuming >80% of campaign budget in CBO
- Check if budgets align with audience size (small audience + large budget = frequency issues)
- Ideal: each ad set should exit learning phase within 7 days

**3c. Placement Performance**
- Break down performance by placement (Feed, Stories, Reels, Audience Network, etc.)
- Flag Audience Network if CPA is >2x other placements
- Flag placements with high spend but low conversion rate
- Check Advantage+ Placements vs Manual: is manual restriction justified by data?

**3d. Audience Size & Targeting**
- Flag audiences <100K (too narrow for most objectives)
- Flag audiences >50M (too broad unless using Advantage+ targeting)
- Check for stacking too many interests (usually reduces performance)
- Review lookalike audience percentages (1% vs 5% vs 10%)

### Step 4: Creative Diversity Analysis

**4a. Format Mix**
- Calculate ratio: video / static image / carousel / collection
- Ideal mix varies by business type:
  - E-commerce: 40% video, 25% carousel, 25% static, 10% collection
  - Lead gen: 50% video, 30% static, 20% carousel
- Flag: >80% single format (insufficient testing)
- Flag: no video ads (video typically outperforms on Meta)

**4b. Creative Volume**
- Ideal: 3-6 active ads per ad set
- Flag: ad sets with only 1 ad (no testing)
- Flag: ad sets with >10 ads (budget too thin per creative)
- Check total creative count vs spend (need sufficient budget per creative)

**4c. Creative Fatigue Indicators**
- Flag ads running >21 days with declining CTR trend
- Flag ads where frequency >3 and CTR has dropped >20% from peak
- Flag ad sets where all creatives show declining performance
- Calculate average creative lifespan in the account

**4d. UGC vs Branded Content**
- Classify ads as UGC-style vs branded/polished
- Flag: 100% branded with no UGC testing
- UGC typically outperforms for direct response, branded better for awareness

### Step 5: Advantage+ & Automation Review

**5a. Advantage+ Campaign Settings**
- Advantage+ Shopping: is it being used for e-commerce? Should it be?
- Advantage+ Creative: enhancements on/off, which ones?
- Advantage+ Audience: is broad targeting being tested?
- Advantage+ Placements: on by default, flag if manually restricted without data justification

**5b. Learning Phase Status**
- Flag ad sets stuck in learning (or "Learning Limited")
- Learning Limited = not getting ~50 optimization events per week
- Common causes: budget too low, audience too small, too many ad sets splitting conversions
- Calculate % of spend in learning vs optimized ad sets

### Step 6: Attribution & Tracking

**6a. Attribution Window**
- Default: 7-day click, 1-day view
- Flag if using 1-day click only (underreports conversions for long sales cycles)
- Flag if using 28-day windows (inflates attribution)
- Check consistency across campaigns

**6b. Conversion Events**
- Are campaigns optimizing for the right event in the funnel?
- Flag: optimizing for Purchase with <50 purchases/week (should use AddToCart or higher-funnel)
- Flag: optimizing for ViewContent (too high-funnel for most)
- Check if custom conversions are properly defined

**6c. Event Match Quality (if data provided)**
- Score per event (1-10 scale from Meta)
- Flag events with EMQ <6 (data quality issues)
- Recommend server-side tracking improvements
- Check CAPI implementation indicators

### Step 7: Frequency & Reach Analysis

- Calculate account-level frequency across campaigns
- Flag campaigns with frequency >3 in prospecting (cold audiences)
- Flag retargeting with frequency >8 (ad fatigue)
- Check reach vs audience size ratio
- Identify cannibalization: same users seeing ads from multiple campaigns

### Step 8: Scoring & Report Generation

**Scoring Categories:**

| Category | Weight | Sections |
|----------|--------|----------|
| Campaign Structure | 20% | Objectives, CBO/ABO, organization |
| Ad Set Configuration | 25% | Audiences, budgets, placements |
| Creative Strategy | 25% | Format mix, volume, fatigue, UGC |
| Automation & Advantage+ | 10% | Advantage+ settings, learning phase |
| Attribution & Tracking | 15% | Windows, events, EMQ |
| Frequency Management | 5% | Frequency caps, reach efficiency |

**Overall Score (0-100):**
- 85-100 (A): Excellent, well-optimized account
- 70-84 (B): Good, minor improvements needed
- 55-69 (C): Fair, significant optimization opportunity
- 40-54 (D): Poor, structural issues hurting performance
- 0-39 (F): Critical, fundamental problems

Generate the HTML report:

```bash
python3 .claude/skills/meta-campaign-auditor/scripts/generate_report.py \
  --analysis /tmp/meta-audit/analysis.json \
  --output output/meta-audit-[client-name].html
```

### Step 9: Open Report

```bash
open output/meta-audit-[client-name].html
```

## Report Structure

The HTML report includes:

1. **Cover Page** - Client name, date range, prepared by, overall score
2. **Executive Summary** - Overall grade, 3 key findings, top metric highlights
3. **Score Breakdown** - Visual bars for all 6 categories
4. **Campaign Structure** - Objective alignment, CBO/ABO analysis, campaign map
5. **Ad Set Deep Dive** - Audience overlap heatmap, budget distribution, placement breakdown
6. **Creative Analysis** - Format mix pie chart, fatigue indicators, diversity score
7. **Advantage+ Review** - Automation settings checklist with recommendations
8. **Attribution & Tracking** - Attribution windows, event configuration, EMQ scores
9. **Frequency Analysis** - Frequency distribution, reach efficiency
10. **Top 5 Priority Fixes** - Ranked by impact and effort
11. **Recommendations Summary** - Quick Wins, Medium Term, Long Term
12. **Next Steps** - Specific action items with timeline

## Report Design

- Light theme (per brain design preferences)
- No rounded corners (border-radius: 2px max)
- No gradients, solid colors only
- Accent borders with straight vertical lines (border-left)
- Charts: strong x/y axes, subtle grid, no box around charts
- Score circles matching the Google Ads audit style
- Color coding: green (good), amber (warning), red (critical)

## Output

- HTML report saved to `output/meta-audit-[client-name].html` and opened in browser
- Analysis JSON saved to `/tmp/meta-audit/analysis.json` for further processing

## Optional Follow-ups

- **PDF export**: Use the pdf skill to convert HTML to PDF
- **Creative deep-dive**: Hand off to meta-creative-analyzer for detailed creative analysis
- **Comparison**: Re-run in 30 days and compare scores

## Common Meta Ads Mistakes (Flag These)

1. **Too many ad sets** - Splitting budget across 10+ ad sets prevents learning
2. **Audience overlap** - Multiple ad sets targeting the same people, bidding against yourself
3. **Creative fatigue ignored** - Running the same ads for months without refresh
4. **Wrong optimization event** - Optimizing for Purchase with insufficient volume
5. **Ignoring Advantage+** - Manual settings where automation would perform better
6. **1-day click attribution only** - Misses view-through and longer click windows
7. **No creative testing framework** - Random ads instead of systematic testing
8. **Audience Network left on** - Often drains budget with low-quality traffic
9. **Budget below learning threshold** - Ad sets that never exit learning phase
10. **Retargeting frequency too high** - Annoying potential customers with 10+ impressions

## Dependencies

- Python 3 with pandas, numpy (from root package)
- No separate package.json (uses brain root)
