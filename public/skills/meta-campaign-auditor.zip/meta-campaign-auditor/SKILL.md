---
name: meta-campaign-auditor
description: "Comprehensive Meta Ads account audit from exported CSV data. Analyzes campaign structure, ad set config, creative diversity, Advantage+ settings, attribution, and more. Outputs scored HTML report."
version: 1.0
---

# Meta Campaign Auditor

Produce a comprehensive audit of a Meta Ads account from exported CSV data. Analyzes campaign structure, ad set configuration, creative performance, Advantage+ settings, attribution, and conversion events. Outputs a scored HTML report.

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

## When to Use

- User mentions auditing a Meta Ads or Facebook Ads account
- User provides Meta Ads CSV exports and asks for analysis
- User says "meta audit", "facebook ads audit", or similar

## Input Requirements

Gather from the user:
1. **CSV location** - Path to folder or individual files
2. **Business type** - ecommerce, leadgen, app, or awareness
3. **Monthly budget** - Approximate monthly Meta spend
4. **Key conversion event** - Purchase, Lead, AddToCart, etc.
5. **Any known issues?** - Optional specifics to check

### How to Export from Meta Ads Manager

Tell the user:
> In Meta Ads Manager:
> 1. Select the date range (last 30 or 90 days recommended)
> 2. Go to the Campaigns tab, click "Reports" > "Export Table Data" > CSV
> 3. Repeat for Ad Sets tab and Ads tab
> 4. Save all CSVs to one folder and provide the path

## Process

### Step 1: Run the Analysis Script

Run the bundled analysis script at `scripts/analyze_meta_campaigns.py`:

```bash
python3 scripts/analyze_meta_campaigns.py \
  --input "[path-to-csv-or-folder]" \
  --business-type "[ecommerce|leadgen|app|awareness]" \
  --output /tmp/meta-audit/
```

**Dependencies:** pandas, numpy (install via `pip install pandas numpy` if not available)

The script auto-detects campaign, ad set, and ad level data from the CSVs and scores 6 categories:

| Category | Weight | What It Covers |
|----------|--------|---------------|
| Campaign Structure | 20% | Objectives, CBO/ABO, organization |
| Ad Set Configuration | 25% | Audiences, budgets, placements |
| Creative Strategy | 25% | Format mix, volume, fatigue, UGC |
| Automation & Advantage+ | 10% | Settings, learning phase |
| Attribution & Tracking | 15% | Windows, events, EMQ |
| Frequency Management | 5% | Caps, reach efficiency |

### Step 2: Generate HTML Report

Run the bundled report generator at `scripts/generate_report.py`:

```bash
python3 scripts/generate_report.py \
  --analysis /tmp/meta-audit/analysis.json \
  --output meta-audit-report.html \
  --client-name "Client Name"
```

### Step 3: Open Report

Open the HTML report in the browser.

## Grading Scale

| Grade | Score | Meaning |
|-------|-------|---------|
| A | 85-100 | Excellent, well-optimized account |
| B | 70-84 | Good, minor improvements needed |
| C | 55-69 | Fair, significant optimization opportunity |
| D | 40-54 | Poor, structural issues |
| F | 0-39 | Critical, fundamental problems |

## Common Meta Ads Mistakes (Flag These)

1. Too many ad sets splitting budget and preventing learning
2. Audience overlap causing self-competition
3. Creative fatigue from running same ads too long
4. Wrong optimization event for the conversion volume
5. Ignoring Advantage+ where automation would help
6. 1-day click attribution only (misses view-through)
7. No creative testing framework
8. Audience Network draining budget with low-quality traffic
9. Budgets below learning threshold
10. Retargeting frequency too high
