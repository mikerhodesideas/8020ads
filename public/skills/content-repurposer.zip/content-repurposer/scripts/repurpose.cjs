#!/usr/bin/env node

/**
 * Content Repurposer - HTML Output Generator
 *
 * Takes platform-specific social post content (as JSON via stdin) and
 * generates a single HTML document with all versions, character counts,
 * and copy-to-clipboard buttons.
 *
 * Usage:
 *   echo '<json>' | node repurpose.cjs --output /tmp/repurposed/
 *
 * Input JSON format:
 * {
 *   "sourceTitle": "Blog Post Title",
 *   "sourceWordCount": 2500,
 *   "sourceSlug": "blog-post-title",
 *   "keyInsights": ["insight 1", "insight 2"],
 *   "platforms": {
 *     "linkedin": {
 *       "post": "LinkedIn post text here...",
 *       "visualSuggestion": "Carousel with 5 slides covering key points"
 *     },
 *     "twitter": {
 *       "tweets": ["1/6 Tweet one...", "2/6 Tweet two...", ...],
 *       "visualSuggestion": "Text graphic with the hook statement"
 *     },
 *     "instagram": {
 *       "caption": "Instagram caption here...",
 *       "hashtags": "#marketing #digitalads #ppc",
 *       "visualSuggestion": "Carousel with key takeaways"
 *     },
 *     "facebook": {
 *       "post": "Facebook post text here...",
 *       "visualSuggestion": "Single image quote graphic"
 *     }
 *   }
 * }
 */

const fs = require('fs');
const path = require('path');

// Parse CLI args
const args = process.argv.slice(2);
let outputDir = '/tmp/repurposed/';

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--output' && args[i + 1]) {
    outputDir = args[++i];
  }
}

// Read JSON from stdin
let inputData = '';
process.stdin.setEncoding('utf-8');
process.stdin.on('data', (chunk) => { inputData += chunk; });
process.stdin.on('end', () => {
  try {
    const data = JSON.parse(inputData);
    generateOutput(data);
  } catch (err) {
    console.error('Error parsing input JSON:', err.message);
    process.exit(1);
  }
});

function generateOutput(data) {
  const {
    sourceTitle = 'Untitled',
    sourceWordCount = 0,
    sourceSlug = 'content',
    keyInsights = [],
    platforms = {}
  } = data;

  fs.mkdirSync(outputDir, { recursive: true });

  let sections = '';

  // Source summary section
  sections += `
    <div class="section">
      <h2>Source Content</h2>
      <div class="meta-row">
        <span><strong>Title:</strong> ${esc(sourceTitle)}</span>
        <span><strong>Word count:</strong> ${sourceWordCount.toLocaleString()}</span>
      </div>
      <h3>Key Insights Extracted</h3>
      <ul>
        ${keyInsights.map(i => `<li>${esc(i)}</li>`).join('\n        ')}
      </ul>
    </div>`;

  // LinkedIn
  if (platforms.linkedin) {
    const charCount = (platforms.linkedin.post || '').length;
    sections += platformSection(
      'LinkedIn',
      '#0A66C2',
      platforms.linkedin.post,
      charCount,
      platforms.linkedin.visualSuggestion,
      'linkedin-post'
    );
  }

  // Twitter/X
  if (platforms.twitter) {
    const tweets = platforms.twitter.tweets || [];
    const tweetBlocks = tweets.map((tweet, i) => {
      const chars = tweet.length;
      const overLimit = chars > 280;
      return `
        <div class="tweet-block">
          <div class="tweet-header">
            <span class="tweet-num">Tweet ${i + 1}/${tweets.length}</span>
            <span class="char-count ${overLimit ? 'over-limit' : ''}">${chars}/280</span>
            <button class="copy-btn" onclick="copyText('tweet-${i}')">Copy</button>
          </div>
          <pre class="post-text" id="tweet-${i}">${esc(tweet)}</pre>
        </div>`;
    }).join('\n');

    sections += `
    <div class="section">
      <div class="platform-header" style="border-color: #1DA1F2;">
        <h2>Twitter/X Thread</h2>
      </div>
      ${tweetBlocks}
      ${platforms.twitter.visualSuggestion ? `<div class="visual-suggestion"><strong>Suggested visual:</strong> ${esc(platforms.twitter.visualSuggestion)}</div>` : ''}
    </div>`;
  }

  // Instagram
  if (platforms.instagram) {
    const caption = platforms.instagram.caption || '';
    const hashtags = platforms.instagram.hashtags || '';
    const fullText = caption + (hashtags ? '\n\n\n\n\n\n' + hashtags : '');
    const charCount = fullText.length;
    sections += platformSection(
      'Instagram',
      '#E4405F',
      fullText,
      charCount,
      platforms.instagram.visualSuggestion,
      'instagram-post'
    );
  }

  // Facebook
  if (platforms.facebook) {
    const charCount = (platforms.facebook.post || '').length;
    sections += platformSection(
      'Facebook',
      '#1877F2',
      platforms.facebook.post,
      charCount,
      platforms.facebook.visualSuggestion,
      'facebook-post'
    );
  }

  const filename = `${sourceSlug}-social-posts.html`;
  const filePath = path.join(outputDir, filename);
  fs.writeFileSync(filePath, buildHTML(sourceTitle, sections), 'utf-8');
  console.log(`Output written: ${filePath}`);
}

function platformSection(name, color, text, charCount, visualSuggestion, id) {
  return `
    <div class="section">
      <div class="platform-header" style="border-color: ${color};">
        <h2>${name}</h2>
        <span class="char-count">${charCount} characters</span>
        <button class="copy-btn" onclick="copyText('${id}')">Copy</button>
      </div>
      <pre class="post-text" id="${id}">${esc(text || '')}</pre>
      ${visualSuggestion ? `<div class="visual-suggestion"><strong>Suggested visual:</strong> ${esc(visualSuggestion)}</div>` : ''}
    </div>`;
}

function buildHTML(title, sections) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Social Posts - ${esc(title)}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #fff; color: #1a1a1a; max-width: 800px; margin: 0 auto; padding: 32px 24px;
      line-height: 1.6;
    }
    h1 { font-size: 1.5rem; margin-bottom: 8px; }
    h2 { font-size: 1.2rem; margin: 0; }
    h3 { font-size: 1rem; margin: 16px 0 8px; color: #333; }
    .subtitle { color: #666; font-size: 0.9rem; margin-bottom: 32px; }
    .section {
      margin-bottom: 32px; padding-bottom: 24px;
      border-bottom: 1px solid #e0e0e0;
    }
    .meta-row {
      display: flex; gap: 24px; margin-bottom: 12px;
      font-size: 0.9rem; color: #555;
    }
    ul { padding-left: 20px; margin-bottom: 8px; }
    li { margin-bottom: 4px; font-size: 0.9rem; }
    .platform-header {
      display: flex; align-items: center; gap: 16px;
      border-left: 4px solid; padding-left: 12px;
      margin-bottom: 16px;
    }
    .char-count {
      font-size: 0.8rem; color: #888;
      background: #f5f5f5; padding: 2px 8px; border-radius: 2px;
    }
    .char-count.over-limit { color: #DC2626; background: #fef2f2; font-weight: 600; }
    .copy-btn {
      background: #1a1a1a; color: #fff; border: none;
      padding: 4px 12px; font-size: 0.8rem; cursor: pointer;
      border-radius: 2px; margin-left: auto;
    }
    .copy-btn:hover { background: #333; }
    .copy-btn:active { background: #555; }
    .post-text {
      background: #fafafa; border: 1px solid #e0e0e0;
      padding: 16px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 0.9rem; line-height: 1.6; white-space: pre-wrap;
      word-wrap: break-word; border-radius: 2px;
    }
    .visual-suggestion {
      margin-top: 12px; padding: 10px 14px;
      background: #fff8f0; border-left: 3px solid #D64C00;
      font-size: 0.85rem; color: #555;
    }
    .tweet-block { margin-bottom: 12px; }
    .tweet-header {
      display: flex; align-items: center; gap: 12px; margin-bottom: 4px;
    }
    .tweet-num { font-weight: 600; font-size: 0.85rem; color: #1DA1F2; }
    @media print {
      .copy-btn { display: none; }
      .section { break-inside: avoid; }
    }
  </style>
</head>
<body>
  <h1>Social Posts</h1>
  <div class="subtitle">Repurposed from: ${esc(title)}</div>
  ${sections}
  <p style="margin-top:32px;font-size:0.8rem;color:#999;text-align:center;">
    Generated ${new Date().toISOString().split('T')[0]} | Review and personalize before posting
  </p>
  <script>
    function copyText(id) {
      const el = document.getElementById(id);
      if (!el) return;
      const text = el.textContent;
      navigator.clipboard.writeText(text).then(() => {
        const btn = el.closest('.section')?.querySelector('.copy-btn')
          || el.previousElementSibling?.querySelector('.copy-btn')
          || event.target;
        const original = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => { btn.textContent = original; }, 1500);
      });
    }
  </script>
</body>
</html>`;
}

function esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
