---
name: content-repurposer
description: "Take long-form content (blog post, video transcript, podcast notes) and generate platform-specific social posts for LinkedIn, Twitter/X, Instagram, and Facebook. Outputs an HTML file with copy buttons."
version: 1.0
---

# Content Repurposer

Take a long-form content piece and generate platform-specific social posts for every channel. One piece of content becomes 4+ ready-to-schedule posts.

IMPORTANT: Use the bundled scripts included with this skill. Do NOT write new scripts.

## When to Use

- "repurpose this blog post"
- "turn this into social posts"
- "create social content from this transcript"

## Process

### Phase 1: Source Content Ingestion

1. If file path: Read the file
2. If URL: Use WebFetch to extract the content
3. If pasted text: Use the text directly

Extract from the source:
- Title/headline
- Key insights (3-5 main points)
- Quotable lines (punchy statements that stand alone)
- Statistics or data points
- Actionable takeaways
- Story elements (anecdotes, examples)
- Core topic/theme in 2-3 words

### Phase 2: Confirm Platforms and Tone

Ask the user which platforms (LinkedIn, Twitter/X, Instagram, Facebook) and what tone (Professional, Conversational, Bold/Provocative, Educational).

### Phase 3: Generate Platform Content

#### LinkedIn Post
- 1000-1300 characters
- Hook first line (before "see more")
- 5-8 short paragraphs with line breaks
- CTA question at the end
- 3-5 hashtags at the very end, separated by blank line
- No emojis unless conversational tone
- Use "I" not "we"

#### Twitter/X Thread
- 5-7 tweets, each under 280 characters
- Tweet 1: Bold claim or surprising stat (standalone)
- Tweets 2-5: One key point per tweet
- Tweet 6: Summary/CTA
- No hashtags (algorithm deprioritizes them)

#### Instagram Caption
- Hook in first 125 characters (visible preview)
- 3-5 short paragraphs, story format
- CTA: "Save this", "Tag someone"
- 15-20 hashtags after 5 line breaks
- Emoji usage encouraged (1-2 per paragraph)

#### Facebook Post
- 300-600 characters
- Question or relatable statement opening
- Conversational, like talking to a friend
- 1-2 questions to invite comments
- No hashtags, link in comments

### Phase 4: Output

Pipe the generated content as JSON to the bundled script at `scripts/repurpose.cjs`. The script reads JSON from stdin and outputs a single HTML file with all platforms, character counts, and copy buttons.

```bash
echo '<json>' | node scripts/repurpose.cjs --output /tmp/repurposed/
```

**JSON format:**
```json
{
  "sourceTitle": "Blog Post Title",
  "sourceWordCount": 2500,
  "sourceSlug": "blog-post-title",
  "keyInsights": ["insight 1", "insight 2"],
  "platforms": {
    "linkedin": {
      "post": "LinkedIn post text...",
      "visualSuggestion": "Carousel with 5 slides"
    },
    "twitter": {
      "tweets": ["1/6 Tweet one...", "2/6 Tweet two..."],
      "visualSuggestion": "Text graphic"
    },
    "instagram": {
      "caption": "Instagram caption...",
      "hashtags": "#marketing #digitalads",
      "visualSuggestion": "Carousel with takeaways"
    },
    "facebook": {
      "post": "Facebook post text...",
      "visualSuggestion": "Quote graphic"
    }
  }
}
```

Open the generated HTML file in the browser for review.
