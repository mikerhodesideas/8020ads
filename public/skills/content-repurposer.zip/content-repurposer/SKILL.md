---
name: content-repurposer
description: "Take long-form content (blog post, video transcript, podcast notes) and generate platform-specific social posts for LinkedIn, Twitter/X, Instagram, and Facebook. Extracts key insights, quotes, and stats, then adapts tone and format per platform. Suggests visual format for each."
version: 1.0
last_updated: 2026-03-21
members: true
context: fork
---

# Content Repurposer

Take a long-form content piece and generate platform-specific social posts for every channel. One piece of content becomes 4+ ready-to-schedule posts.

## When to Use

- "repurpose this blog post"
- "turn this into social posts"
- "create social content from this transcript"
- `/content-repurposer`

## Command Format

```
/content-repurposer <source>
```

Where `<source>` is one of:
- A file path to a blog post, transcript, or article (markdown, HTML, or plain text)
- A URL to fetch content from (uses WebFetch)
- Pasted text (if the user pastes content directly in the conversation)

## Workflow

### Phase 1: Source Content Ingestion

1. **If file path:** Read the file
2. **If URL:** Use WebFetch to extract the content
3. **If pasted text:** Use the text directly

Parse the source content and extract:
- **Title/headline** (if present)
- **Key insights** (3-5 main points or arguments)
- **Quotable lines** (specific, punchy statements that stand alone)
- **Statistics or data points** (numbers, percentages, results)
- **Actionable takeaways** (things the reader can do)
- **Story elements** (anecdotes, examples, case studies)
- **Core topic/theme** in 2-3 words

### Phase 2: Platform Configuration

Use `AskUserQuestion` to confirm platforms and tone:

**Question:** "Which platforms do you want content for?"

| Option | Description |
|--------|-------------|
| LinkedIn | Professional tone, 1300 char max, hook-first |
| Twitter/X | Thread format, 5-7 tweets, each standalone |
| Instagram | Casual tone, caption + hashtags |
| Facebook | Conversational, engagement-focused |

Use AskUserQuestion with multiSelect: true. Default: all selected.

**Question:** "What tone should the posts use?"

| Option | Description |
|--------|-------------|
| Professional | Authority, expertise, thought leadership |
| Conversational | Friendly, approachable, relatable |
| Bold/Provocative | Strong opinions, contrarian takes, attention-grabbing |
| Educational | Teaching, explaining, step-by-step |

Use AskUserQuestion with multiSelect: false. Default: Professional.

### Phase 3: Generate Platform Content

Run the generation script to produce the output document:

```bash
node .claude/skills/content-repurposer/scripts/repurpose.cjs \
  --source "<source-file-or-text>" \
  --output /tmp/repurposed/
```

The script handles HTML output formatting. Claude generates the actual content for each platform following these specifications:

#### LinkedIn Post

**Format:** Single post, 1000-1300 characters
**Structure:**
1. **Hook** (first line): Attention-grabbing statement or question. This line appears before "see more" so it must compel the click.
2. **Body** (5-8 short paragraphs): Key insight, supporting evidence, personal take. Use line breaks between paragraphs (LinkedIn rewards white space).
3. **CTA** (last line): Question to drive comments, or clear next step.

**Rules:**
- No hashtags in the body (add 3-5 at the very end, separated by a blank line)
- No emojis unless the tone is Conversational
- Short paragraphs (1-2 sentences each)
- Use "I" not "we"

**Suggested visual:** Carousel (key points as slides), single image (quote graphic), or document PDF

#### Twitter/X Thread

**Format:** 5-7 tweets, numbered, each under 280 characters
**Structure:**
1. **Tweet 1 (Hook):** Bold claim, surprising stat, or provocative question. Must work as a standalone tweet.
2. **Tweets 2-5 (Body):** One key point per tweet. Each tweet should make sense if someone sees it in isolation.
3. **Tweet 6 (Summary/CTA):** Recap the core message, ask for engagement.
4. **Tweet 7 (optional):** "If you found this useful, repost tweet 1" or link to full content.

**Rules:**
- Each tweet under 280 characters (hard limit)
- Number format: "1/" or "1/7"
- No hashtags (Twitter algorithm deprioritizes them)
- Include one tweet with a stat or data point if available

**Suggested visual:** Thread starter image (text graphic with the hook), or relevant chart/screenshot

#### Instagram Caption

**Format:** Caption, 300-500 characters for the visible portion, up to 2200 total
**Structure:**
1. **Hook** (first line): Must grab attention in the preview (first ~125 characters visible)
2. **Body** (3-5 short paragraphs): Story format, personal angle, relatable language
3. **CTA:** "Save this for later", "Tag someone who needs this", or similar engagement prompt
4. **Hashtag block:** 15-20 relevant hashtags (mix of broad and niche), separated by 5 line breaks from the caption

**Rules:**
- Casual, conversational tone regardless of global tone setting (Instagram is informal)
- Emoji usage encouraged (1-2 per paragraph)
- Line breaks between paragraphs
- Write for mobile reading (short lines)

**Suggested visual:** Carousel (5-10 slides with key points), Reel script (15-30 seconds), or single quote graphic

#### Facebook Post

**Format:** Single post, 300-600 characters ideal (can go longer but engagement drops)
**Structure:**
1. **Hook** (first line): Question or relatable statement
2. **Body** (2-3 short paragraphs): Conversational retelling of the key insight, written as if talking to a friend
3. **CTA:** Question that invites comments ("What has been your experience with X?" or "Anyone else seeing this?")

**Rules:**
- Most conversational of all platforms
- Questions perform well (use 1-2)
- No hashtags (Facebook algorithm ignores them)
- Link in comments, not in the post (if linking back to full content)

**Suggested visual:** Native video (if source is video), single image, or text-on-image graphic

### Phase 4: Output Generation

Generate a single HTML document containing all platform versions:

**Document structure:**
1. **Source summary** (title, word count, key extractions)
2. **LinkedIn section** (post text + visual suggestion + character count)
3. **Twitter/X section** (thread with all tweets + visual suggestion + per-tweet character count)
4. **Instagram section** (caption + hashtag block + visual suggestion + character count)
5. **Facebook section** (post text + visual suggestion + character count)
6. **Copy buttons** next to each post for easy clipboard copying

Save to `/tmp/repurposed/{source-slug}-social-posts.html`

Open in browser: `open /tmp/repurposed/{source-slug}-social-posts.html`

### Phase 5: Summary

Present a brief summary:
- Source content: title, word count
- Posts generated: list of platforms
- Key angle used across posts
- Reminder: review and personalize before posting

## Output HTML Design

- Light theme
- Each platform section has a distinct header with platform name
- Post text in a monospace-friendly container for easy copying
- Character count displayed next to each post/tweet
- Visual suggestion displayed as a styled callout below each post
- Copy-to-clipboard buttons (JavaScript onclick)
- border-radius: 2px maximum
- No gradients
- Print-friendly CSS

## Files

| File | Purpose |
|------|---------|
| `SKILL.md` | This file (skill definition, platform specs, workflow) |
| `scripts/repurpose.cjs` | HTML output generator and file writer |

## Dependencies

No additional dependencies. Uses Node.js built-in `fs` and `path` modules only.
