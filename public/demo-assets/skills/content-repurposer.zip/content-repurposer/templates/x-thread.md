<!-- Template: X/Twitter Thread -->
<!-- Tweets: 5-7 -->
<!-- Max per tweet: 280 characters (hard limit) -->
<!-- Structure: Hook -> Context -> Key Points -> Takeaway -->

**1/** [HOOK: Must work completely standalone. If this tweet gets zero engagement, the thread is dead. Lead with the sharpest insight, most surprising stat, or boldest claim from the source.]

**2/** [CONTEXT: Quick setup. What's the background? Keep it tight. One or two sentences max.]

**3/** [KEY POINT 1: The most important supporting detail. A specific number, example, or proof point.]

**4/** [KEY POINT 2: Second supporting detail. Different angle from tweet 3.]

**5/** [KEY POINT 3: Third supporting detail, or a "but here's the thing" twist that adds nuance.]

**6/** [SYNTHESIS: Pull it together. What does this mean? Why does it matter right now?]

**7/** [TAKEAWAY: What to do next. A clear action, a question worth considering, or the one thing to remember. End strong.]

<!--
RULES:
- 5-7 tweets (more is OK if the content demands it, fewer is OK if it's tight)
- Each tweet: 280 characters max. Count carefully. This is a HARD limit.
- Numbered format: 1/, 2/, 3/, etc.
- Tweet 1 is the hook. It MUST work as a standalone tweet.
- Each tweet should flow into the next
- Each tweet should also make sense if read alone (for quote tweets)
- No hashtags unless joining a specific live conversation
- Final tweet should feel like a full stop, not a fade-out

TONE:
- Punchy and direct
- Conversational, like you're telling a friend
- Assertive (state things, don't hedge)
- Short sentences, sometimes fragments
- OK to start sentences with And, But, So
- Smart-casual: confident without being try-hard

FORMAT TRICKS:
- Line breaks within a tweet for emphasis
- Single-word sentences for punch
- Questions to create curiosity (sparingly)
- "Here's the thing:" as a pivot works once per thread

AVOID:
- "Thread:" or "THREAD" labels (let the numbers speak)
- "A thread on..." openers
- Emojis as bullet points
- "1/7" format (just use 1/)
- Hashtag dumps
- "Follow me for more" endings
-->
