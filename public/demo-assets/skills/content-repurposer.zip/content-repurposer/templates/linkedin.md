<!-- Template: LinkedIn Post -->
<!-- Max Length: 1300 characters -->
<!-- Structure: Hook -> Context -> Insight -> Evidence -> Takeaway + Hashtags -->

[HOOK: One powerful opening line. A number, a result, a bold claim, or a counterintuitive statement. This line decides if anyone reads further. No "I just..." or "I recently..." openers.]

---

[CONTEXT: 2-3 short sentences. What's the situation? What happened? Set the scene fast. No throat-clearing.]

[INSIGHT: The main point. What's the non-obvious takeaway? Be specific, not generic. This is the value.]

---

[EVIDENCE: Back it up. A specific example, a number, a before/after, a concrete detail. This earns credibility.]

-> [Supporting detail 1]
-> [Supporting detail 2]
-> [Supporting detail 3]

---

[TAKEAWAY: One sentence. What should the reader do differently after reading this?]

[CTA: A specific question or challenge. Not "Thoughts?" or "Agree?" - ask something that invites a real answer.]

#Hashtag1 #Hashtag2 #Hashtag3

<!--
RULES:
- 1300 characters max (hard limit)
- Hook must be the first line, no preamble
- Use --- as section separators for readability
- Use -> for bullet points
- No hashtags in the body text
- 3-5 hashtags at the very end, after a blank line
- Short paragraphs (1-3 sentences max)
- White space between sections
- No emojis (or minimal, max 1-2 if absolutely needed)
- Write as someone sharing experience, not promoting content
- Lead with the insight, not the setup

TONE:
- Practitioner sharing a real lesson
- Direct, not preachy
- Confident without being arrogant
- Conversational but professional
- Specific over vague ("saved 3 hours/week" not "saved time")

AVOID:
- "I'm excited to share..."
- "In today's fast-paced world..."
- "Here's why..." as an opener
- Listicle format (1. 2. 3.) unless the content genuinely demands it
- Corporate buzzwords
- Humble bragging
-->
