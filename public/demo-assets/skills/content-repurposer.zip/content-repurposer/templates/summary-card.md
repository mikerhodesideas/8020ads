<!-- Template: Summary Card -->
<!-- Max: 3 bullet points + 1 takeaway line -->
<!-- Purpose: The absolute minimum someone needs to get the core message -->

## [TITLE or TOPIC]

**Takeaway:** [One sentence. The single most important thing to know.]

- [BULLET 1: First key point. Concrete and specific. Include a number if one exists.]
- [BULLET 2: Second key point. Different angle from bullet 1.]
- [BULLET 3: Third key point. Or a "what to do about it" action step.]

*Source: [title of original content] | [word count] words | [reading time] min read*

<!--
RULES:
- 3 bullet points maximum. If you can do it in 2, do it in 2.
- One-line takeaway at the top (bold)
- Each bullet is one sentence, max two
- Think: if someone ONLY reads this card, do they get the core message?
- No fluff, no setup, just the essential points
- Include the source attribution line at the bottom

TONE:
- Crisp and factual
- Executive summary energy
- Every word must earn its place
- Numbers and specifics over generalities

USE CASES:
- Slack share ("Here's the TLDR")
- Internal team briefing
- Quick reference card
- Meeting prep summary

AVOID:
- "This article discusses..."
- Background or context paragraphs
- More than 3 bullets (be ruthless about cutting)
- Vague language ("various", "many", "significant")
-->
