<!-- Template: Email Newsletter Blurb -->
<!-- Max Length: 150 words -->
<!-- Structure: Key Insight -> Context -> CTA -->
<!-- Purpose: A section within a larger newsletter, not a standalone email -->

**[SUBJECT LINE SUGGESTION: 5-8 words, curiosity-driven or benefit-driven]**

[KEY INSIGHT: Open with the single most important takeaway from the source. State it plainly in 1-2 sentences. No buildup.]

[CONTEXT: 1-2 sentences of supporting detail. Why does this matter? What's the evidence? Keep it brief, this is a teaser, not the full piece.]

[OPTIONAL: One short bullet list if there are 2-3 concrete points worth highlighting]
- [Point 1]
- [Point 2]

[CTA: One clear call to action. "Read the full piece here" or "Try this today" or "Reply and tell me X". Make it specific.]

<!--
RULES:
- 150 words max (hard limit)
- One key insight only. Don't try to summarise everything.
- Scannable: short sentences, maybe one bullet list
- Warm but not casual, informative but not dry
- The reader should understand the core message without clicking through
- But they should WANT to click through for more

TONE:
- Like a smart friend recommending something worth reading
- Personal without being chatty
- Confident and clear
- "Here's something I found useful" energy

AVOID:
- "In this week's newsletter..."
- Multiple CTAs (pick one)
- Long paragraphs
- Hype language ("amazing", "incredible", "you won't believe")
- Passive voice
-->
