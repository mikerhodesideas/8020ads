#!/usr/bin/env python3
"""
Content Repurposer - Extraction Script

Reads long-form content (markdown, text, or plain text) and extracts:
- Semantic sections (by headings or double newlines)
- Key quotes (sentences with numbers, strong statements)
- Statistics and numbers mentioned
- Main thesis/argument
- Word count, reading time, section count

Outputs:
1. manifest.json - Structured data for template filling
2. content-hub.html - Interactive HTML with all platform versions (tabs + copy buttons)

Usage:
    python extract.py <input_file> [--output manifest.json]
    python extract.py <input_file> --manifest-only
"""

import json
import os
import re
import sys
from collections import Counter
from pathlib import Path


# --- Text Analysis ---

def read_input(file_path: str) -> str:
    """Read input file, handling .md, .txt, and other text formats."""
    path = Path(file_path)
    if not path.exists():
        print(f"Error: File not found: {file_path}", file=sys.stderr)
        sys.exit(1)

    encodings = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]
    for enc in encodings:
        try:
            return path.read_text(encoding=enc)
        except (UnicodeDecodeError, UnicodeError):
            continue

    print(f"Error: Could not decode file: {file_path}", file=sys.stderr)
    sys.exit(1)


def detect_title(text: str) -> str:
    """Try to detect a title from the content."""
    lines = text.strip().split("\n")

    # Check for YAML frontmatter title
    if lines[0].strip() == "---":
        for line in lines[1:]:
            if line.strip() == "---":
                break
            match = re.match(r"^title:\s*[\"']?(.+?)[\"']?\s*$", line)
            if match:
                return match.group(1).strip()

    # Check for markdown H1
    for line in lines[:10]:
        stripped = line.strip()
        if stripped.startswith("# ") and not stripped.startswith("##"):
            return stripped.lstrip("# ").strip()

    # Check for first non-empty line that looks like a title (short, no period)
    for line in lines[:5]:
        stripped = line.strip()
        if stripped and len(stripped) < 120 and not stripped.endswith("."):
            # Skip frontmatter delimiters and metadata
            if stripped == "---" or ":" in stripped[:20]:
                continue
            return stripped

    return "Untitled Content"


def strip_frontmatter(text: str) -> str:
    """Remove YAML frontmatter if present."""
    if text.strip().startswith("---"):
        parts = text.strip().split("---", 2)
        if len(parts) >= 3:
            return parts[2].strip()
    return text


def split_sections(text: str) -> list:
    """Split content into semantic sections by headings or double newlines."""
    clean = strip_frontmatter(text)
    sections = []

    # Try splitting by markdown headings first
    heading_pattern = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
    headings = list(heading_pattern.finditer(clean))

    if headings:
        # Add content before first heading as intro
        intro = clean[: headings[0].start()].strip()
        if intro:
            sections.append({"heading": "Introduction", "content": intro, "level": 0})

        for i, match in enumerate(headings):
            level = len(match.group(1))
            heading = match.group(2).strip()
            start = match.end()
            end = headings[i + 1].start() if i + 1 < len(headings) else len(clean)
            content = clean[start:end].strip()
            if content:
                sections.append(
                    {"heading": heading, "content": content, "level": level}
                )
    else:
        # Fall back to splitting by double newlines
        blocks = re.split(r"\n\s*\n", clean)
        for i, block in enumerate(blocks):
            block = block.strip()
            if block:
                # Use first line as a pseudo-heading if it's short
                lines = block.split("\n")
                first = lines[0].strip()
                if len(first) < 80 and len(lines) > 1 and not first.endswith("."):
                    sections.append(
                        {
                            "heading": first,
                            "content": "\n".join(lines[1:]).strip(),
                            "level": 2,
                        }
                    )
                else:
                    sections.append(
                        {
                            "heading": f"Section {i + 1}",
                            "content": block,
                            "level": 2,
                        }
                    )

    return sections if sections else [{"heading": "Content", "content": clean, "level": 0}]


def extract_sentences(text: str) -> list:
    """Split text into individual sentences."""
    # Handle common abbreviations to avoid false splits
    clean = text.replace("Mr.", "Mr").replace("Mrs.", "Mrs").replace("Dr.", "Dr")
    clean = clean.replace("vs.", "vs").replace("e.g.", "eg").replace("i.e.", "ie")
    clean = clean.replace("etc.", "etc")

    # Split on sentence boundaries
    sentences = re.split(r"(?<=[.!?])\s+", clean)
    return [s.strip() for s in sentences if s.strip() and len(s.strip()) > 10]


def is_fragment(sent: str) -> bool:
    """Check if a sentence looks like a list fragment, template, or non-prose."""
    stripped = sent.strip()
    # Starts with list markers, bullets, or template placeholders
    if re.match(r"^[-*>+]|^\d+[.)]\s|^\[|^<!--", stripped):
        return True
    # Contains template-like patterns
    if stripped.count('"') >= 4 or stripped.count("(") >= 3:
        return True
    # Very short or no verb-like structure
    words = stripped.split()
    if len(words) < 6:
        return True
    return False


def extract_key_quotes(text: str) -> list:
    """Extract sentences that are strong quotes: contain numbers, percentages,
    bold claims, or are structurally interesting."""
    sentences = extract_sentences(strip_frontmatter(text))
    quotes = []

    for sent in sentences:
        score = 0
        # Contains numbers or percentages
        if re.search(r"\d+[%x]|\d{2,}|\$\d+", sent):
            score += 3
        # Contains comparison words
        if re.search(r"\b(more than|less than|better|worse|faster|slower|doubled|tripled|half)\b", sent, re.I):
            score += 2
        # Contains strong opinion markers
        if re.search(r"\b(never|always|must|critical|essential|wrong|right|mistake|secret|key|important)\b", sent, re.I):
            score += 2
        # Contains result/outcome language
        if re.search(r"\b(result|found|discovered|learned|realized|turned out|surprised|changed)\b", sent, re.I):
            score += 1
        # Reasonable length (not too short, not too long)
        word_count = len(sent.split())
        if 8 <= word_count <= 30:
            score += 1
        # Starts with a strong word
        if re.match(r"^(The |This |I |We |Most |Every |No |Stop |Start |Don't )", sent):
            score += 1

        if score >= 3:
            # Clean up markdown artifacts
            clean_sent = re.sub(r"[*_`#]", "", sent).strip()
            if clean_sent and clean_sent not in quotes and not is_fragment(clean_sent):
                quotes.append(clean_sent)

    # Return top quotes, sorted by position in text (to maintain narrative order)
    return quotes[:10]


def extract_statistics(text: str) -> list:
    """Extract numbers, percentages, and data points mentioned in the text."""
    clean = strip_frontmatter(text)
    stats = []

    patterns = [
        (r"(\d+(?:\.\d+)?%)", "percentage"),
        (r"\$(\d[\d,.]*)", "dollar amount"),
        (r"(\d[\d,.]+)\s*(hours?|minutes?|days?|weeks?|months?|years?)", "time"),
        (r"(\d[\d,.]+)\s*(times?|x)\s", "multiplier"),
        (r"(\d[\d,.]+)\s*(people|users?|customers?|members?|companies|teams?)", "count"),
    ]

    for pattern, stat_type in patterns:
        for match in re.finditer(pattern, clean, re.I):
            # Get surrounding context (the sentence containing the stat)
            start = max(0, match.start() - 80)
            end = min(len(clean), match.end() + 80)
            context = clean[start:end].strip()
            # Clean to sentence boundaries
            context = re.sub(r"^.*?(?=[A-Z])", "", context, count=1)
            context = re.sub(r"[.!?].*$", "", context) + "."
            context = re.sub(r"[*_`#]", "", context).strip()

            stat_entry = {
                "value": match.group(0).strip(),
                "type": stat_type,
                "context": context[:150],
            }
            if stat_entry not in stats:
                stats.append(stat_entry)

    return stats[:15]


def detect_thesis(text: str, sections: list) -> str:
    """Try to detect the main argument or thesis of the content."""
    clean = strip_frontmatter(text)

    # Check for explicit thesis markers
    thesis_patterns = [
        r"(?:the (?:main|key|core|central) (?:point|argument|thesis|idea|insight) is[:\s]+)(.+?)[.\n]",
        r"(?:in short|in summary|the bottom line|here's (?:the|what)|my (?:take|argument|point))[:\s]+(.+?)[.\n]",
        r"(?:tl;?dr)[:\s]+(.+?)[.\n]",
    ]

    for pattern in thesis_patterns:
        match = re.search(pattern, clean, re.I)
        if match:
            result = re.sub(r"[*_`#]", "", match.group(1)).strip()
            if not is_fragment(result):
                return result

    # Use the first section's first substantive sentence as thesis proxy
    if sections:
        first_content = sections[0].get("content", "")
        sentences = extract_sentences(first_content)
        for sent in sentences[:5]:
            clean_sent = re.sub(r"[*_`#]", "", sent).strip()
            if len(clean_sent.split()) >= 8 and not is_fragment(clean_sent):
                return clean_sent[:200]

    # Last resort: first long non-fragment sentence of the whole text
    sentences = extract_sentences(clean)
    for sent in sentences[:10]:
        clean_sent = re.sub(r"[*_`#]", "", sent).strip()
        if len(clean_sent.split()) >= 8 and not is_fragment(clean_sent):
            return clean_sent[:200]

    return "No clear thesis detected."


def extract_keywords(text: str, top_n: int = 10) -> list:
    """Extract frequently used significant words."""
    clean = strip_frontmatter(text).lower()
    # Remove markdown, URLs, and non-alpha
    clean = re.sub(r"https?://\S+", "", clean)
    clean = re.sub(r"[^a-z\s]", " ", clean)
    words = clean.split()

    # Common English stop words
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "need", "dare", "ought",
        "used", "to", "of", "in", "for", "on", "with", "at", "by", "from",
        "as", "into", "through", "during", "before", "after", "above",
        "below", "between", "out", "off", "over", "under", "again",
        "further", "then", "once", "here", "there", "when", "where", "why",
        "how", "all", "both", "each", "few", "more", "most", "other",
        "some", "such", "no", "nor", "not", "only", "own", "same", "so",
        "than", "too", "very", "just", "because", "but", "and", "or",
        "if", "while", "about", "up", "down", "that", "this", "these",
        "those", "it", "its", "they", "them", "their", "we", "us", "our",
        "you", "your", "he", "him", "his", "she", "her", "i", "my", "me",
        "what", "which", "who", "whom", "also", "even", "still", "much",
        "many", "well", "back", "way", "get", "got", "one", "two", "new",
        "like", "make", "made", "know", "see", "think", "take", "come",
        "going", "want", "look", "use", "find", "give", "tell", "work",
        "call", "try", "ask", "put", "keep", "let", "say", "said",
        "thing", "things", "really", "something", "don", "t", "s", "re",
        "ve", "ll", "d", "m", "didn", "doesn", "isn", "wasn", "aren",
        "won", "wouldn", "couldn", "shouldn", "haven", "hasn", "hadn",
    }

    # Count significant words (4+ chars, not stop words)
    filtered = [w for w in words if len(w) >= 4 and w not in stop_words]
    counts = Counter(filtered)

    return [{"word": word, "count": count} for word, count in counts.most_common(top_n)]


def build_manifest(file_path: str, text: str) -> dict:
    """Build the complete manifest from source text."""
    sections = split_sections(text)
    clean_text = strip_frontmatter(text)
    words = clean_text.split()
    word_count = len(words)
    reading_time = max(1, round(word_count / 250))

    key_quotes = extract_key_quotes(text)
    statistics = extract_statistics(text)
    thesis = detect_thesis(text, sections)
    keywords = extract_keywords(text)
    title = detect_title(text)

    return {
        "source_file": os.path.basename(file_path),
        "title": title,
        "word_count": word_count,
        "reading_time": reading_time,
        "section_count": len(sections),
        "quote_count": len(key_quotes),
        "stat_count": len(statistics),
        "sections": sections,
        "key_quotes": key_quotes,
        "statistics": statistics,
        "main_thesis": thesis,
        "keywords": keywords,
    }


# --- HTML Generation ---

def generate_html(manifest: dict) -> str:
    """Generate the interactive content-hub.html with tabs and copy buttons."""
    title = manifest["title"]
    word_count = manifest["word_count"]
    reading_time = manifest["reading_time"]
    section_count = manifest["section_count"]
    quote_count = manifest["quote_count"]
    stat_count = manifest["stat_count"]
    key_quotes = manifest["key_quotes"]
    statistics = manifest["statistics"]
    thesis = manifest["main_thesis"]
    keywords = manifest["keywords"]

    # Build quotes HTML
    quotes_html = ""
    if key_quotes:
        for q in key_quotes:
            escaped = q.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
            quotes_html += f'<div class="quote-item">&ldquo;{escaped}&rdquo;</div>\n'
    else:
        quotes_html = '<p class="muted">No strong quotes detected.</p>'

    # Build stats HTML
    stats_html = ""
    if statistics:
        for s in statistics:
            val = s["value"].replace("&", "&amp;").replace("<", "&lt;")
            ctx = s["context"].replace("&", "&amp;").replace("<", "&lt;")
            stats_html += f'''<div class="stat-item">
                <span class="stat-value">{val}</span>
                <span class="stat-type">({s["type"]})</span>
                <span class="stat-context">{ctx}</span>
            </div>\n'''
    else:
        stats_html = '<p class="muted">No statistics or numbers detected.</p>'

    # Build keywords HTML
    keywords_html = ""
    if keywords:
        for kw in keywords:
            keywords_html += f'<span class="keyword-tag">{kw["word"]} ({kw["count"]})</span>\n'
    else:
        keywords_html = '<p class="muted">No significant keywords detected.</p>'

    thesis_escaped = thesis.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Hub - {title.replace('"', '&quot;')}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #fafafa;
            color: #1a1a1a;
            line-height: 1.6;
            padding: 0;
        }}

        .header {{
            background: #fff;
            border-bottom: 1px solid #e0e0e0;
            padding: 24px 32px;
        }}

        .header h1 {{
            font-size: 22px;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 4px;
        }}

        .header .subtitle {{
            font-size: 14px;
            color: #666;
        }}

        .metrics-bar {{
            display: flex;
            gap: 24px;
            padding: 16px 32px;
            background: #fff;
            border-bottom: 1px solid #e0e0e0;
        }}

        .metric {{
            display: flex;
            align-items: baseline;
            gap: 6px;
        }}

        .metric-value {{
            font-size: 18px;
            font-weight: 700;
            color: #D64C00;
        }}

        .metric-label {{
            font-size: 12px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}

        .tabs {{
            display: flex;
            background: #fff;
            border-bottom: 1px solid #e0e0e0;
            padding: 0 32px;
            overflow-x: auto;
        }}

        .tab {{
            padding: 14px 20px;
            font-size: 14px;
            font-weight: 500;
            color: #666;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            white-space: nowrap;
            transition: color 0.15s, border-color 0.15s;
            background: none;
            border-top: none;
            border-left: none;
            border-right: none;
            font-family: inherit;
        }}

        .tab:hover {{
            color: #1a1a1a;
        }}

        .tab.active {{
            color: #D64C00;
            border-bottom-color: #D64C00;
        }}

        .tab-content {{
            display: none;
            padding: 32px;
            max-width: 800px;
        }}

        .tab-content.active {{
            display: block;
        }}

        .content-card {{
            background: #fff;
            border: 1px solid #e0e0e0;
            border-left: 3px solid #D64C00;
            border-radius: 2px;
            padding: 24px;
            margin-bottom: 20px;
        }}

        .content-card .card-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }}

        .content-card .card-title {{
            font-size: 16px;
            font-weight: 600;
            color: #1a1a1a;
        }}

        .content-card .card-meta {{
            font-size: 12px;
            color: #888;
        }}

        .content-card pre {{
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            line-height: 1.7;
            white-space: pre-wrap;
            word-wrap: break-word;
            color: #333;
            margin: 0;
        }}

        .copy-btn {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            background: #D64C00;
            color: #fff;
            border: none;
            border-radius: 2px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            font-family: inherit;
            transition: background 0.15s;
        }}

        .copy-btn:hover {{
            background: #b84000;
        }}

        .copy-btn.copied {{
            background: #16a34a;
        }}

        .copy-btn svg {{
            width: 14px;
            height: 14px;
            fill: currentColor;
        }}

        /* Source Analysis Tab */
        .analysis-section {{
            margin-bottom: 28px;
        }}

        .analysis-section h3 {{
            font-size: 15px;
            font-weight: 600;
            color: #1a1a1a;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 1px solid #eee;
        }}

        .thesis-box {{
            background: #fff;
            border: 1px solid #e0e0e0;
            border-left: 3px solid #D64C00;
            border-radius: 2px;
            padding: 16px 20px;
            font-size: 15px;
            line-height: 1.6;
            color: #333;
            font-style: italic;
        }}

        .quote-item {{
            padding: 12px 16px;
            margin-bottom: 8px;
            background: #f8f8f8;
            border-left: 2px solid #ddd;
            border-radius: 2px;
            font-size: 14px;
            line-height: 1.5;
            color: #444;
        }}

        .stat-item {{
            display: flex;
            align-items: baseline;
            gap: 8px;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
            flex-wrap: wrap;
        }}

        .stat-value {{
            font-weight: 700;
            color: #D64C00;
            font-size: 15px;
        }}

        .stat-type {{
            font-size: 12px;
            color: #999;
        }}

        .stat-context {{
            font-size: 13px;
            color: #666;
            flex-basis: 100%;
            padding-left: 0;
            margin-top: 2px;
        }}

        .keyword-tag {{
            display: inline-block;
            padding: 4px 10px;
            margin: 3px;
            background: #f0f0f0;
            border-radius: 2px;
            font-size: 13px;
            color: #555;
        }}

        .muted {{
            color: #999;
            font-style: italic;
            font-size: 14px;
        }}

        .placeholder-msg {{
            padding: 40px 20px;
            text-align: center;
            color: #999;
            font-size: 15px;
        }}

        .placeholder-msg p {{
            margin-bottom: 8px;
        }}

        .placeholder-msg code {{
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 2px;
            font-size: 13px;
        }}

        @media (max-width: 640px) {{
            .header, .metrics-bar, .tabs, .tab-content {{
                padding-left: 16px;
                padding-right: 16px;
            }}

            .metrics-bar {{
                flex-wrap: wrap;
                gap: 12px;
            }}

            .content-card .card-header {{
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title.replace("<", "&lt;").replace(">", "&gt;")}</h1>
        <div class="subtitle">Content Hub - Repurposed for multiple platforms</div>
    </div>

    <div class="metrics-bar">
        <div class="metric">
            <span class="metric-value">{word_count:,}</span>
            <span class="metric-label">Words</span>
        </div>
        <div class="metric">
            <span class="metric-value">{reading_time}</span>
            <span class="metric-label">Min Read</span>
        </div>
        <div class="metric">
            <span class="metric-value">{section_count}</span>
            <span class="metric-label">Sections</span>
        </div>
        <div class="metric">
            <span class="metric-value">{quote_count}</span>
            <span class="metric-label">Key Quotes</span>
        </div>
        <div class="metric">
            <span class="metric-value">{stat_count}</span>
            <span class="metric-label">Stats Found</span>
        </div>
    </div>

    <div class="tabs">
        <button class="tab active" data-tab="linkedin">LinkedIn</button>
        <button class="tab" data-tab="x-thread">X Thread</button>
        <button class="tab" data-tab="email">Email Blurb</button>
        <button class="tab" data-tab="summary">Summary Card</button>
        <button class="tab" data-tab="analysis">Source Analysis</button>
    </div>

    <!-- LinkedIn Tab -->
    <div class="tab-content active" id="tab-linkedin">
        <div class="content-card">
            <div class="card-header">
                <span class="card-title">LinkedIn Post</span>
                <span class="card-meta">Max 1,300 characters</span>
            </div>
            <pre id="linkedin-content">LinkedIn version will be generated by the Cowork agent using the manifest data and linkedin.md template.

To populate this tab, the agent reads the manifest, applies the LinkedIn template rules, generates the post, and embeds it here.</pre>
        </div>
        <button class="copy-btn" onclick="copyContent('linkedin-content')">
            <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            Copy to Clipboard
        </button>
    </div>

    <!-- X Thread Tab -->
    <div class="tab-content" id="tab-x-thread">
        <div class="content-card">
            <div class="card-header">
                <span class="card-title">X/Twitter Thread</span>
                <span class="card-meta">5-7 tweets, 280 chars each</span>
            </div>
            <pre id="x-thread-content">X thread version will be generated by the Cowork agent using the manifest data and x-thread.md template.

To populate this tab, the agent reads the manifest, applies the X thread template rules, generates the thread, and embeds it here.</pre>
        </div>
        <button class="copy-btn" onclick="copyContent('x-thread-content')">
            <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            Copy to Clipboard
        </button>
    </div>

    <!-- Email Blurb Tab -->
    <div class="tab-content" id="tab-email">
        <div class="content-card">
            <div class="card-header">
                <span class="card-title">Email Newsletter Blurb</span>
                <span class="card-meta">Max 150 words</span>
            </div>
            <pre id="email-content">Email blurb version will be generated by the Cowork agent using the manifest data and email-blurb.md template.

To populate this tab, the agent reads the manifest, applies the email template rules, generates the blurb, and embeds it here.</pre>
        </div>
        <button class="copy-btn" onclick="copyContent('email-content')">
            <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            Copy to Clipboard
        </button>
    </div>

    <!-- Summary Card Tab -->
    <div class="tab-content" id="tab-summary">
        <div class="content-card">
            <div class="card-header">
                <span class="card-title">Summary Card</span>
                <span class="card-meta">3 bullets + takeaway</span>
            </div>
            <pre id="summary-content">Summary card version will be generated by the Cowork agent using the manifest data and summary-card.md template.

To populate this tab, the agent reads the manifest, applies the summary template rules, generates the card, and embeds it here.</pre>
        </div>
        <button class="copy-btn" onclick="copyContent('summary-content')">
            <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            Copy to Clipboard
        </button>
    </div>

    <!-- Source Analysis Tab -->
    <div class="tab-content" id="tab-analysis">
        <div class="analysis-section">
            <h3>Main Thesis</h3>
            <div class="thesis-box">{thesis_escaped}</div>
        </div>

        <div class="analysis-section">
            <h3>Key Quotes ({quote_count})</h3>
            {quotes_html}
        </div>

        <div class="analysis-section">
            <h3>Statistics & Numbers ({stat_count})</h3>
            {stats_html}
        </div>

        <div class="analysis-section">
            <h3>Top Keywords</h3>
            <div>{keywords_html}</div>
        </div>
    </div>

    <script>
        // Tab switching
        document.querySelectorAll('.tab').forEach(tab => {{
            tab.addEventListener('click', () => {{
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                const target = document.getElementById('tab-' + tab.dataset.tab);
                if (target) target.classList.add('active');
            }});
        }});

        // Copy to clipboard
        function copyContent(elementId) {{
            const el = document.getElementById(elementId);
            if (!el) return;

            const text = el.textContent || el.innerText;
            const btn = el.closest('.tab-content').querySelector('.copy-btn');

            if (navigator.clipboard && navigator.clipboard.writeText) {{
                navigator.clipboard.writeText(text).then(() => {{
                    showCopied(btn);
                }}).catch(() => {{
                    fallbackCopy(text, btn);
                }});
            }} else {{
                fallbackCopy(text, btn);
            }}
        }}

        function fallbackCopy(text, btn) {{
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            try {{
                document.execCommand('copy');
                showCopied(btn);
            }} catch (e) {{
                console.error('Copy failed:', e);
            }}
            document.body.removeChild(ta);
        }}

        function showCopied(btn) {{
            if (!btn) return;
            const original = btn.innerHTML;
            btn.classList.add('copied');
            btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg> Copied!';
            setTimeout(() => {{
                btn.classList.remove('copied');
                btn.innerHTML = original;
            }}, 2000);
        }}
    </script>
</body>
</html>'''

    return html


# --- Main ---

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Extract content data for repurposing")
    parser.add_argument("input_file", help="Path to the input file (.md, .txt, or plain text)")
    parser.add_argument("--output", "-o", default="manifest.json", help="Output manifest filename (default: manifest.json)")
    parser.add_argument("--html", default="content-hub.html", help="Output HTML filename (default: content-hub.html)")
    parser.add_argument("--manifest-only", action="store_true", help="Only output the manifest, skip HTML generation")

    args = parser.parse_args()

    # Read input
    print(f"Reading: {args.input_file}")
    text = read_input(args.input_file)

    # Build manifest
    print("Analysing content...")
    manifest = build_manifest(args.input_file, text)

    # Determine output directory (same as input file)
    out_dir = os.path.dirname(os.path.abspath(args.input_file))
    if not out_dir:
        out_dir = os.getcwd()

    # Write manifest
    manifest_path = os.path.join(out_dir, args.output)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    print(f"Manifest saved: {manifest_path}")

    # Write HTML
    if not args.manifest_only:
        print("Generating HTML hub...")
        html = generate_html(manifest)
        html_path = os.path.join(out_dir, args.html)
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"HTML hub saved: {html_path}")

    # Summary
    print(f"\nSource: {manifest['title']}")
    print(f"Words: {manifest['word_count']:,} | Reading time: {manifest['reading_time']} min")
    print(f"Sections: {manifest['section_count']} | Key quotes: {manifest['quote_count']} | Stats: {manifest['stat_count']}")
    print(f"Thesis: {manifest['main_thesis'][:100]}...")
    print(f"\nReady for repurposing. The Cowork agent will now generate platform versions.")


if __name__ == "__main__":
    main()
