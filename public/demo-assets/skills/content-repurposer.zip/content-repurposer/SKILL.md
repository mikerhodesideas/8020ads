---
name: content-repurposer
description: Takes long-form content (blog post, transcript, meeting notes) and produces platform-ready versions for LinkedIn, X/Twitter, email newsletters, and summary cards. Generates an interactive HTML hub with copy buttons for each version. Use when the user says "repurpose this", "turn this into posts", "content repurpose", provides long-form text, or asks to create multi-platform content from a single source.
---

# Content Repurposer

## Your Task

Transform long-form content into polished, platform-specific versions for LinkedIn, X/Twitter, email newsletters, and summary cards. Produce both individual files and an interactive HTML hub with copy-to-clipboard buttons.

**Outputs (per run):**
1. `manifest.json` - Extracted data from the source content
2. `linkedin.md` - LinkedIn post (1300 chars max)
3. `x-thread.md` - X/Twitter thread (5-7 tweets)
4. `email-blurb.md` - Email newsletter section (150 words)
5. `summary-card.md` - Quick summary (3 bullets + takeaway)
6. `content-hub.html` - Interactive HTML with all versions, copy buttons, and source analysis

## CRITICAL: Behaviour Rules

**DO NOT ask what platforms the user wants.**
**DO NOT offer options or ask clarifying questions.**
**DO NOT wait for user input before starting.**

**IMMEDIATELY AND AUTOMATICALLY:**
1. Run the extraction script on the input
2. Generate ALL platform versions
3. Build the interactive HTML hub
4. Present the results

**The user wants everything repurposed right away. Just do it.**

## Process

### Step 1: Run the Extraction Script

Run the Python extraction script on the input file:

```bash
python scripts/extract.py "<input_file>" --output manifest.json
```

This produces `manifest.json` containing:
- `title` - Detected or inferred title
- `word_count` - Total words in source
- `reading_time` - Estimated minutes to read
- `section_count` - Number of content sections
- `sections` - Array of section objects (heading + content)
- `key_quotes` - Strong statements, sentences with numbers
- `statistics` - Numbers and data points mentioned
- `main_thesis` - The core argument or point
- `keywords` - Frequently used significant words

If the script fails or the user provided raw text instead of a file, create the manifest manually by analysing the content directly. The script is a helper, not a hard dependency.

### Step 2: Read the Templates

Read these template files before generating content:
- `templates/linkedin.md`
- `templates/x-thread.md`
- `templates/email-blurb.md`
- `templates/summary-card.md`

Each template contains format constraints, platform-specific guidance, and the structure to follow.

### Step 3: Generate Platform Versions

Using the manifest data and templates, generate each version:

**LinkedIn Post** (`linkedin.md`):
- 1300 characters max (hard limit)
- Hook-first: open with the most compelling insight, stat, or bold claim
- No hashtags in the body text
- 3-5 hashtags at the very end, separated by a line break
- Use `---` as section separators
- Short paragraphs, scannable structure
- Write as a practitioner sharing experience, not a content marketer
- End with a specific question or challenge, not "Thoughts?"

**X/Twitter Thread** (`x-thread.md`):
- 5-7 tweets, each under 280 characters (hard limit per tweet)
- Numbered format: 1/, 2/, 3/, etc.
- Tweet 1 is the hook, must work completely standalone
- Each tweet should flow into the next but also make sense alone
- Final tweet: key takeaway or call to action
- No hashtags unless joining a specific conversation
- Punchy, direct, conversational

**Email Newsletter Blurb** (`email-blurb.md`):
- 150 words max
- One key insight from the source, clearly stated
- Brief context (1-2 sentences)
- One clear call to action (read the full piece, try something, reply)
- Scannable: short sentences, maybe one bullet list
- Warm but not casual, informative but not dry

**Summary Card** (`summary-card.md`):
- 3 bullet points maximum, each one sentence
- One-line takeaway at the top
- Think: if someone only reads this card, they get the core message
- No fluff, no setup, just the essential points

### Step 4: Build the Interactive HTML Hub

Generate `content-hub.html` with all versions embedded. The HTML must be:

- **Self-contained** - no external dependencies except optionally a Google Font CDN link
- **Light theme** - white/cream background, dark text, professional styling
- **Tabbed interface** with these tabs:
  1. LinkedIn
  2. X Thread
  3. Email Blurb
  4. Summary Card
  5. Source Analysis
- Each content tab shows the formatted version with a **"Copy to Clipboard"** button
- The "Copy to Clipboard" button must use the `navigator.clipboard.writeText()` API with a fallback to `document.execCommand('copy')`
- After copying, the button text changes to "Copied!" for 2 seconds
- The **Source Analysis** tab shows:
  - Word count, reading time, section count, quote count
  - Key quotes pulled from the source
  - Statistics/numbers mentioned
  - Main thesis/argument
  - Top keywords
- Clean card-based layout, no rounded corners beyond 2px border-radius
- Solid colours only, no gradients
- Strong accent borders (left border on cards)
- Professional typography

**HTML Styling Requirements:**
- Background: `#fafafa` or white
- Text: `#1a1a1a`
- Accent: `#D64C00` (used for active tab, accent borders, buttons)
- Cards: white background, `1px solid #e0e0e0` border, `border-radius: 2px`
- Accent border on cards: `border-left: 3px solid #D64C00`
- Font: system font stack or Inter from Google Fonts
- No gradients anywhere
- Copy button: solid `#D64C00` background, white text, `border-radius: 2px`
- Tab active state: bottom border in accent colour
- No box shadows heavier than `0 1px 3px rgba(0,0,0,0.08)`

### Step 5: Save All Output Files

Save all files in the same directory as the input file (or the current working directory if input was pasted text):

```
manifest.json
linkedin.md
x-thread.md
email-blurb.md
summary-card.md
content-hub.html
```

### Step 6: Open the HTML Hub

Open `content-hub.html` in the browser so the user can see all versions immediately.

### Step 7: Present Results

Tell the user:
- How many words were in the source
- What the main thesis/angle was
- That all 4 platform versions + the HTML hub are ready
- That they can use the HTML hub to copy any version to clipboard
- Mention the individual .md files if they prefer raw text

## Writing Rules (All Platforms)

- Write like a person, not a brand
- Direct and conversational
- Concrete over abstract
- No corporate speak or buzzwords
- Contractions are fine (I'm, can't, you're)
- Short sentences for impact (5-15 words)
- Lead with insights, not setup
- Every sentence must earn its place

## Banned Words

Never use: leverage, synergy, utilize, streamline, robust, cutting-edge, game-changer, genuinely, delve, unlock, elevate, empower, ecosystem, paradigm, disrupt, holistic, scalable

## Error Handling

- If the input file is not found, ask for the correct path
- If the Python script fails, extract data manually from the content
- If content is very short (under 100 words), still produce all versions but note that the source was brief
- If content has no clear headings, split by double newlines or paragraph breaks
