# Follow-up Email Template

Use this template to draft a follow-up email after processing meeting notes.
Replace placeholders ($variable) with actual content from the extraction.

---

**To:** $recipients
**Subject:** Action items from our meeting ($meeting_date)

---

Hi $greeting_name,

Thanks for the meeting. Here is a quick recap of what was agreed and what needs to happen next.

$decisions_section

**Action items:**

$action_items_list

$questions_section

$followup_section

Please flag anything I missed or got wrong.

Thanks,
$sender_name

---

## Template Variables

- `$recipients` - Comma-separated attendee emails or names
- `$meeting_date` - Date of the meeting
- `$greeting_name` - "everyone" or specific name if only one other attendee
- `$decisions_section` - "**Decisions:**\n- Decision 1\n- Decision 2" (omit if none)
- `$action_items_list` - "- [Owner] Action description (deadline)" for each item
- `$questions_section` - "**Open questions:**\n- Question 1" (omit if none)
- `$followup_section` - "**To follow up on:**\n- Item 1" (omit if none)
- `$sender_name` - The user's name
