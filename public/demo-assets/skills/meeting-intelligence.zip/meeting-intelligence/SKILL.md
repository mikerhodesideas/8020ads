---
name: meeting-intelligence
description: Processes meeting notes or transcripts to extract action items, decisions, questions, and follow-ups. Produces an interactive HTML dashboard with filtering, sorting, export, and a ready-to-send follow-up email. Use when the user provides a meeting transcript, meeting notes, or asks to process a meeting.
---

# Meeting Intelligence

Turn any meeting transcript or notes into an interactive HTML dashboard with action items, decisions, open questions, follow-ups, and export options.

## How It Works

1. User provides meeting notes (pasted directly or as a file path)
2. The extraction script parses the content and outputs structured JSON + an interactive HTML dashboard + a CSV of actions
3. Cowork reads the JSON and writes a brief AI summary
4. Cowork updates the dashboard with the summary and generates a follow-up email draft

## Usage

### Option A: User provides a file path

```bash
python scripts/extract-actions.py /path/to/meeting-notes.md --output-dir /path/to/output/
```

### Option B: User pastes meeting notes directly

1. Save the pasted content to a temporary file (e.g., `meeting-input.md`)
2. Run: `python scripts/extract-actions.py meeting-input.md`
3. Outputs appear in the same directory as the input file

## Step-by-Step Processing

Follow these steps in order:

### Step 1: Run the extraction script

```bash
python scripts/extract-actions.py <input_file> [--output-dir <dir>]
```

This creates three files:
- `meeting-data.json` - Structured extraction data
- `meeting-dashboard.html` - Interactive HTML dashboard
- `actions-export.csv` - CSV of action items

### Step 2: Read the JSON output

Read `meeting-data.json` to understand what was extracted. Check the `actions`, `decisions`, `questions`, and `followups` arrays.

### Step 3: Write an AI summary

Based on the full meeting content (either the original file or the extracted data), write a 2-3 sentence summary covering:
- What the meeting was about
- The most important outcomes
- Any urgent items that need immediate attention

### Step 4: Update the dashboard with the AI summary

Open `meeting-dashboard.html` and find the line containing `META.summary`. Replace the empty summary string in the JSON data with your written summary. The summary appears in the `meta_json` variable near the top of the `<script>` block.

Alternatively, if the dashboard is already generated, find the `const META =` line in the HTML and update the `summary` field.

### Step 5: Generate a follow-up email

Using the template at `templates/followup-email.md` as a guide, write a follow-up email that includes:
- A brief thanks and recap
- Key decisions made
- All action items with owners and deadlines
- Any open questions that still need answers
- A request for corrections

Save as `follow-up-email.md` in the output directory.

### Step 6: Present results to the user

Tell the user:
- How many actions, decisions, questions, and follow-ups were found
- Any urgent items that need immediate attention
- Where the output files are saved
- Suggest they open `meeting-dashboard.html` in their browser

## What Gets Extracted

### Action Items
Sentences containing commitment language: "will", "need to", "should", "must", "agreed to", "action:", "todo:", "task:". Each action gets:
- **Owner** - parsed from speaker labels or context
- **Deadline** - if mentioned (exact or relative dates)
- **Priority** - urgent (ASAP/critical/blocking), normal, or low (nice to have/no rush)
- **Status** - starts as "open", toggled via checkbox in the dashboard

### Decisions
Sentences with: "decided", "agreed", "confirmed", "approved", "going with", "chose", "settled on", "moving forward with". Includes the surrounding context as a quote.

### Questions
Sentences ending in "?" or starting with "question:", "open item:". Tracks who raised each question.

### Follow-ups
Items needing future attention: "waiting on", "revisit", "circle back", "check in", conditional items ("if X then Y"). Includes countdown indicators when deadlines are detected.

### Attendees
Detected from speaker labels (Name: text), @mentions, and names appearing multiple times.

## The HTML Dashboard

The dashboard has six tabs:

1. **Actions** - Table with checkbox toggles (open/done), filter by owner/priority/status, sortable columns. Checking an item strikes it through visually.
2. **Decisions** - Card layout with decision text and context quote from the original notes.
3. **Follow-ups** - Items with countdown badges ("3 days left", "overdue", "no deadline set"). Shows both dedicated follow-ups and action items with deadlines.
4. **Questions** - Open questions raised during the meeting, with who raised them.
5. **Summary** - AI-written summary, attendee list, actions-per-person bar chart, key metrics.
6. **Export** - Buttons to download CSV, download markdown, copy follow-up email to clipboard, download raw JSON.

## File Types Supported

- `.txt` - Plain text transcripts
- `.md` - Markdown notes or transcripts
- `.vtt` - WebVTT subtitle files (timestamps stripped)
- `.srt` - SRT subtitle files (timestamps stripped)

## Tips

- Speaker labels help assign owners. Without them, actions go to "Unassigned"
- The script handles messy notes: bullet points, mixed formatting, incomplete sentences
- Requests ("can you review this?") are attributed to the person being asked, not the asker
- Items matching both action and decision patterns are classified as decisions to avoid duplicates
- The dashboard works entirely client-side with no dependencies. Open it in any browser.
- Checkbox state persists during the browser session (JS state, not localStorage)

## Dependencies

Python 3.6+ with standard library only. No pip install needed.
