#!/usr/bin/env python3
"""
extract-actions.py - Extract action items, decisions, questions, and follow-ups
from meeting transcripts. Outputs structured JSON and an interactive HTML dashboard.

Usage:
    python extract-actions.py <transcript_file> [--output-dir <dir>]

Input: Plain text, markdown, VTT, or SRT transcript file.
Output:
    - meeting-data.json   (structured extraction data)
    - meeting-dashboard.html (interactive dashboard)
"""

import argparse
import csv
import html
import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path


# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

SPEAKER_PATTERNS = [
    re.compile(r'^\*\*([^*:]+?):\*\*\s*(.*)'),
    re.compile(r'^\*\*([^*]+?)\*\*:\s*(.*)'),
    re.compile(r'^\[([^\]]+?)\]:?\s+(.*)'),
    re.compile(r'^([A-Z][a-zA-Z\s]{1,30}):\s+(.+)'),
    re.compile(r'^([A-Z][a-zA-Z\s]{1,30})\s*[-]\s+(.+)'),
]

SPEAKER_EXCLUSIONS = {
    'action item', 'action items', 'note', 'notes', 'summary', 'context',
    'background', 'agenda', 'topic', 'discussion', 'decision', 'follow up',
    'follow-up', 'next step', 'next steps', 'todo', 'to do', 'update',
    'question', 'answer', 'result', 'outcome', 'takeaway', 'key point',
    'important', 'urgent', 'deadline', 'reminder', 'warning', 'example',
    'action', 'status', 'priority',
    # Common meeting metadata fields (from headers like "Date: March 13")
    'date', 'time', 'duration', 'location', 'attendees', 'participants',
    'subject', 'meeting', 'call', 'type', 'room', 'link', 'zoom', 'teams',
    'organizer', 'host', 'invitees', 'dial in', 'conference',
}

TIMESTAMP_PATTERNS = [
    re.compile(r'^\d{1,2}:\d{2}(:\d{2})?\s*'),
    re.compile(r'^\[\d{1,2}:\d{2}(:\d{2})?\]\s*'),
    re.compile(r'^\d{2}:\d{2}:\d{2}\.\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}\.\d{3}\s*'),
    re.compile(r'^\d+\s*$'),
]

# @mentions
AT_MENTION_PATTERN = re.compile(r'@(\w+(?:\s\w+)?)')

# Action commitment language
ACTION_SELF_PATTERNS = [
    re.compile(r"\b(I'll|I will|I'm going to|let me|I can)\b", re.IGNORECASE),
    re.compile(r"\b(will send|will share|will prepare|will draft|will review|will check|will look into|will set up|will schedule|will create|will update|will write|will get|will put|will reach)\b", re.IGNORECASE),
    re.compile(r"\b(need to|needs to|should|must)\b", re.IGNORECASE),
    re.compile(r"\b(agreed to|committed to)\b", re.IGNORECASE),
]

ACTION_LABEL_PATTERNS = [
    re.compile(r"\b(action item|action:|todo:|task:|to-do:|next step)\b", re.IGNORECASE),
]

ACTION_REQUEST_PATTERNS = [
    re.compile(r"\b(can you|could you|would you|please)\b.*\b(send|share|review|check|prepare|look|do|handle|create|update|draft|schedule|set up|write|get|put|reach)\b", re.IGNORECASE),
]

ACTION_PATTERNS = ACTION_SELF_PATTERNS + ACTION_LABEL_PATTERNS + ACTION_REQUEST_PATTERNS

ACTION_EXCLUSION_PATTERNS = [
    re.compile(r"\b(was supposed to|should have|were going to|had planned to)\b", re.IGNORECASE),
]

# Decision language
DECISION_PATTERNS = [
    re.compile(r"\b(agreed|decided|decision|let's go with|the plan is|we're going to|going with)\b", re.IGNORECASE),
    re.compile(r"\b(settled on|chosen|picked|approved|confirmed|finalised|finalized)\b", re.IGNORECASE),
    re.compile(r"\b(the approach is|the strategy is|we'll use|moving forward with)\b", re.IGNORECASE),
    re.compile(r"\b(chose|selected|going to use|will go with)\b", re.IGNORECASE),
]

# Question language
QUESTION_PATTERNS = [
    re.compile(r'\?\s*$'),
    re.compile(r"^(question:|open item:|open question:)", re.IGNORECASE),
    re.compile(r"\b(do we know|have we|are we|is there|what about|how do we|who is|when will|where do)\b", re.IGNORECASE),
]

# Follow-up / waiting language
FOLLOWUP_PATTERNS = [
    re.compile(r"\b(waiting (on|for)|pending|blocked|depends on|contingent)\b", re.IGNORECASE),
    re.compile(r"\b(revisit|circle back|check.?in|touch base|follow up|follow-up)\b", re.IGNORECASE),
    re.compile(r"\b(if .+ then|once .+ we'll|after .+ let's)\b", re.IGNORECASE),
    re.compile(r"\b(let's see how|keep an eye on|monitor)\b", re.IGNORECASE),
]

# Deadline language
DEADLINE_PATTERNS = [
    re.compile(r"\b(by|before|due|deadline)\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|end of (?:day|week|month)|eod|eow|next week|next month)\b", re.IGNORECASE),
    re.compile(r"\b(by|before|due|deadline)\s+(\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?)\b", re.IGNORECASE),
    re.compile(r"\b(by|before|due)\s+(march|april|may|june|july|august|september|october|november|december|january|february)\s+\d{1,2}(?:st|nd|rd|th)?\b", re.IGNORECASE),
    re.compile(r"\b(this week|this month|asap|as soon as possible|immediately|today|tonight)\b", re.IGNORECASE),
    re.compile(r"\b(within \d+ (?:days?|weeks?|hours?))\b", re.IGNORECASE),
]

DEADLINE_DATE_MAP = {
    'today': 0, 'tonight': 0, 'tomorrow': 1, 'eod': 0, 'end of day': 0,
    'this week': 5, 'eow': 5, 'end of week': 5,
    'next week': 7, 'this month': 14, 'next month': 30,
    'asap': 1, 'as soon as possible': 1, 'immediately': 0,
}

# Priority language
HIGH_PRIORITY_PATTERNS = [
    re.compile(r"\b(urgent|critical|asap|immediately|top priority|must|blocking|blocker)\b", re.IGNORECASE),
    re.compile(r"\b(by (?:today|tonight|tomorrow|eod))\b", re.IGNORECASE),
]

LOW_PRIORITY_PATTERNS = [
    re.compile(r"\b(nice to have|when you get a chance|no rush|low priority|eventually|someday|would be nice)\b", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

def strip_timestamps(line):
    for pat in TIMESTAMP_PATTERNS:
        line = pat.sub('', line)
    return line.strip()


def detect_speaker(line):
    for pat in SPEAKER_PATTERNS:
        m = pat.match(line)
        if m:
            speaker = m.group(1).strip().rstrip(':').strip('*').strip()
            if speaker.lower() in SPEAKER_EXCLUSIONS:
                return None, line
            rest = m.group(2).strip() if m.lastindex >= 2 else ''
            return speaker, rest
    return None, line


def parse_transcript(text):
    lines = text.split('\n')
    segments = []
    current_speaker = None
    current_text_parts = []
    current_line = 0

    for i, raw_line in enumerate(lines):
        line = strip_timestamps(raw_line)
        if not line:
            continue

        speaker, rest = detect_speaker(line)
        if speaker:
            if current_text_parts:
                segments.append({
                    'speaker': current_speaker,
                    'text': ' '.join(current_text_parts),
                    'line_num': current_line,
                })
            current_speaker = speaker
            current_text_parts = [rest] if rest else []
            current_line = i + 1
        else:
            current_text_parts.append(line)

    if current_text_parts:
        segments.append({
            'speaker': current_speaker,
            'text': ' '.join(current_text_parts),
            'line_num': current_line,
        })

    return segments


def detect_speakers(segments):
    seen = set()
    speakers = []
    for seg in segments:
        if seg['speaker'] and seg['speaker'] not in seen:
            seen.add(seg['speaker'])
            speakers.append(seg['speaker'])
    return speakers


def detect_attendees_from_mentions(text):
    """Find @mentioned names in the raw text."""
    return list(set(AT_MENTION_PATTERN.findall(text)))


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------

def matches_any(text, patterns):
    return any(p.search(text) for p in patterns)


def extract_deadline(text):
    for pat in DEADLINE_PATTERNS:
        m = pat.search(text)
        if m:
            return m.group(0).strip()
    return None


def estimate_deadline_date(deadline_text):
    """Try to estimate a concrete date from deadline text. Returns ISO date string or None."""
    if not deadline_text:
        return None
    lower = deadline_text.lower().strip()
    today = datetime.now()

    # Check direct mappings
    for phrase, days in DEADLINE_DATE_MAP.items():
        if phrase in lower:
            target = today + timedelta(days=days)
            return target.strftime('%Y-%m-%d')

    # Check day names
    day_names = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    for i, day in enumerate(day_names):
        if day in lower:
            current_day = today.weekday()
            days_ahead = i - current_day
            if days_ahead <= 0:
                days_ahead += 7
            target = today + timedelta(days=days_ahead)
            return target.strftime('%Y-%m-%d')

    # Check "within N days/weeks"
    m = re.search(r'within\s+(\d+)\s+(days?|weeks?|hours?)', lower)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        if 'week' in unit:
            n *= 7
        elif 'hour' in unit:
            n = max(1, n // 24)
        target = today + timedelta(days=n)
        return target.strftime('%Y-%m-%d')

    return None


def determine_priority(text):
    if matches_any(text, HIGH_PRIORITY_PATTERNS):
        return 'urgent'
    if matches_any(text, LOW_PRIORITY_PATTERNS):
        return 'low'
    return 'normal'


def clean_text(text):
    text = re.sub(r'^[\s\-\*\u2022]+', '', text).strip()
    if text:
        text = text[0].upper() + text[1:]
    text = text.rstrip('.')
    return text


def split_sentences(text):
    """Split text into sentences, handling abbreviations reasonably."""
    parts = re.split(r'(?<=[.!?])\s+', text)
    return [p.strip() for p in parts if p.strip()]


def extract_actions(segments, all_speakers):
    actions = []
    seen = set()

    for seg in segments:
        text = seg['text']
        if not text or len(text) < 10:
            continue

        if not matches_any(text, ACTION_PATTERNS):
            continue

        sentences = split_sentences(text)
        for sentence in sentences:
            if not matches_any(sentence, ACTION_PATTERNS):
                continue
            if matches_any(sentence, ACTION_EXCLUSION_PATTERNS):
                continue
            # Skip pure decisions
            if matches_any(sentence, DECISION_PATTERNS) and not matches_any(sentence, ACTION_SELF_PATTERNS) and not matches_any(sentence, ACTION_LABEL_PATTERNS):
                continue

            cleaned = clean_text(sentence)
            if len(cleaned) < 8:
                continue

            norm = cleaned.lower()[:60]
            if norm in seen:
                continue
            seen.add(norm)

            owner = seg['speaker'] or 'Unassigned'
            if matches_any(sentence, ACTION_REQUEST_PATTERNS) and not matches_any(sentence, ACTION_SELF_PATTERNS):
                others = [s for s in all_speakers if s != seg['speaker']]
                if others:
                    owner = others[0]

            deadline_text = extract_deadline(sentence)
            deadline_date = estimate_deadline_date(deadline_text)

            action = {
                'id': 'action-%d' % (len(actions) + 1),
                'owner': owner,
                'action': cleaned,
                'deadline': deadline_text,
                'deadline_date': deadline_date,
                'priority': determine_priority(sentence),
                'status': 'open',
                'source_line': seg['line_num'],
                'context': text[:200],
            }
            actions.append(action)

    return actions


def extract_decisions(segments):
    decisions = []
    seen = set()

    for seg in segments:
        text = seg['text']
        if not text or len(text) < 10:
            continue
        if not matches_any(text, DECISION_PATTERNS):
            continue

        sentences = split_sentences(text)
        for sentence in sentences:
            if not matches_any(sentence, DECISION_PATTERNS):
                continue

            cleaned = clean_text(sentence)
            if len(cleaned) < 10:
                continue

            norm = cleaned.lower()[:60]
            if norm in seen:
                continue
            seen.add(norm)

            decisions.append({
                'id': 'decision-%d' % (len(decisions) + 1),
                'decision': cleaned,
                'speaker': seg['speaker'],
                'context': text[:300],
                'source_line': seg['line_num'],
            })

    return decisions


def extract_questions(segments):
    questions = []
    seen = set()

    for seg in segments:
        text = seg['text']
        if not text or len(text) < 5:
            continue
        if not matches_any(text, QUESTION_PATTERNS):
            continue

        sentences = split_sentences(text)
        for sentence in sentences:
            if not matches_any(sentence, QUESTION_PATTERNS):
                continue

            cleaned = clean_text(sentence)
            if not cleaned.endswith('?'):
                cleaned += '?'
            if len(cleaned) < 8:
                continue

            norm = cleaned.lower()[:60]
            if norm in seen:
                continue
            seen.add(norm)

            questions.append({
                'id': 'question-%d' % (len(questions) + 1),
                'question': cleaned,
                'speaker': seg['speaker'],
                'source_line': seg['line_num'],
                'status': 'open',
            })

    return questions


def extract_followups(segments, action_norms):
    followups = []
    seen = set()

    for seg in segments:
        text = seg['text']
        if not text or len(text) < 10:
            continue
        if not matches_any(text, FOLLOWUP_PATTERNS):
            continue

        sentences = split_sentences(text)
        for sentence in sentences:
            if not matches_any(sentence, FOLLOWUP_PATTERNS):
                continue

            cleaned = clean_text(sentence)
            if len(cleaned) < 10:
                continue

            norm = cleaned.lower()[:60]
            if norm in seen or norm in action_norms:
                continue
            seen.add(norm)

            deadline_text = extract_deadline(sentence)
            deadline_date = estimate_deadline_date(deadline_text)

            followups.append({
                'id': 'followup-%d' % (len(followups) + 1),
                'item': cleaned,
                'speaker': seg['speaker'],
                'deadline': deadline_text,
                'deadline_date': deadline_date,
                'source_line': seg['line_num'],
            })

    return followups


# ---------------------------------------------------------------------------
# Summary & Stats
# ---------------------------------------------------------------------------

def build_stats(speakers, actions, decisions, questions, followups, segments):
    total_words = sum(len(s['text'].split()) for s in segments)

    owner_counts = {}
    for a in actions:
        owner_counts[a['owner']] = owner_counts.get(a['owner'], 0) + 1

    priority_counts = {'urgent': 0, 'normal': 0, 'low': 0}
    for a in actions:
        priority_counts[a['priority']] = priority_counts.get(a['priority'], 0) + 1

    return {
        'total_actions': len(actions),
        'total_decisions': len(decisions),
        'total_questions': len(questions),
        'total_followups': len(followups),
        'total_words': total_words,
        'total_segments': len(segments),
        'actions_per_owner': owner_counts,
        'actions_by_priority': priority_counts,
        'attendees': speakers,
    }


# ---------------------------------------------------------------------------
# HTML Dashboard Generation
# ---------------------------------------------------------------------------

def generate_dashboard_html(data):
    """Generate a self-contained interactive HTML dashboard."""

    actions_json = json.dumps(data['actions'], ensure_ascii=False)
    decisions_json = json.dumps(data['decisions'], ensure_ascii=False)
    questions_json = json.dumps(data['questions'], ensure_ascii=False)
    followups_json = json.dumps(data['followups'], ensure_ascii=False)
    stats_json = json.dumps(data['stats'], ensure_ascii=False)
    meta_json = json.dumps({
        'source_file': data.get('source_file', ''),
        'meeting_date': data.get('meeting_date', ''),
        'extracted_at': data.get('extracted_at', ''),
        'summary': data.get('summary', ''),
    }, ensure_ascii=False)

    return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meeting Intelligence Dashboard</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background: #f8f9fa;
    color: #1a1a2e;
    line-height: 1.6;
  }

  .header {
    background: #fff;
    border-bottom: 1px solid #e0e0e0;
    padding: 20px 32px;
  }

  .header h1 {
    font-size: 22px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 4px;
  }

  .header .meta {
    font-size: 13px;
    color: #666;
  }

  .stats-bar {
    display: flex;
    gap: 16px;
    padding: 16px 32px;
    background: #fff;
    border-bottom: 1px solid #e0e0e0;
    flex-wrap: wrap;
  }

  .stat-card {
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 2px;
    padding: 12px 20px;
    min-width: 120px;
    text-align: center;
  }

  .stat-card .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1a1a2e;
  }

  .stat-card .stat-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #888;
    margin-top: 2px;
  }

  .stat-card.urgent .stat-number { color: #d32f2f; }
  .stat-card.actions .stat-number { color: #1565c0; }
  .stat-card.decisions .stat-number { color: #2e7d32; }
  .stat-card.questions .stat-number { color: #ef6c00; }

  .tabs {
    display: flex;
    background: #fff;
    border-bottom: 2px solid #e0e0e0;
    padding: 0 32px;
    gap: 0;
  }

  .tab {
    padding: 12px 24px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    color: #666;
    border-bottom: 2px solid transparent;
    margin-bottom: -2px;
    transition: color 0.15s, border-color 0.15s;
    user-select: none;
  }

  .tab:hover { color: #1a1a2e; }
  .tab.active {
    color: #1565c0;
    border-bottom-color: #1565c0;
  }

  .tab-content {
    display: none;
    padding: 24px 32px;
    max-width: 1200px;
  }

  .tab-content.active { display: block; }

  /* Actions tab */
  .filter-bar {
    display: flex;
    gap: 12px;
    margin-bottom: 16px;
    align-items: center;
    flex-wrap: wrap;
  }

  .filter-bar label {
    font-size: 13px;
    color: #666;
    font-weight: 500;
  }

  .filter-bar select {
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-radius: 2px;
    font-size: 13px;
    background: #fff;
    color: #333;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border: 1px solid #e0e0e0;
  }

  th {
    text-align: left;
    padding: 10px 14px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #888;
    background: #fafafa;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
    user-select: none;
  }

  th:hover { color: #333; }
  th.sorted-asc::after { content: " \\2191"; }
  th.sorted-desc::after { content: " \\2193"; }

  td {
    padding: 10px 14px;
    font-size: 14px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: top;
  }

  tr:hover td { background: #f8f9ff; }

  tr.done td {
    text-decoration: line-through;
    color: #aaa;
  }

  tr.done td .priority-badge { opacity: 0.4; }

  .checkbox-cell {
    width: 36px;
    text-align: center;
  }

  .checkbox-cell input[type="checkbox"] {
    width: 16px;
    height: 16px;
    cursor: pointer;
  }

  .priority-badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 2px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.3px;
  }

  .priority-urgent { background: #ffebee; color: #c62828; }
  .priority-normal { background: #e3f2fd; color: #1565c0; }
  .priority-low { background: #f5f5f5; color: #888; }

  .owner-badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 2px;
    font-size: 12px;
    font-weight: 500;
    background: #e8eaf6;
    color: #283593;
  }

  /* Decisions tab */
  .decision-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-left: 3px solid #2e7d32;
    padding: 16px 20px;
    margin-bottom: 12px;
    border-radius: 0 2px 2px 0;
  }

  .decision-card .decision-text {
    font-size: 15px;
    font-weight: 500;
    color: #1a1a2e;
    margin-bottom: 8px;
  }

  .decision-card .decision-context {
    font-size: 13px;
    color: #666;
    font-style: italic;
    padding: 8px 12px;
    background: #fafafa;
    border-left: 2px solid #e0e0e0;
  }

  .decision-card .decision-speaker {
    font-size: 12px;
    color: #888;
    margin-top: 8px;
  }

  /* Follow-ups tab */
  .followup-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    padding: 16px 20px;
    margin-bottom: 12px;
    border-radius: 2px;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 16px;
  }

  .followup-card .followup-text {
    font-size: 14px;
    color: #1a1a2e;
    flex: 1;
  }

  .followup-card .followup-speaker {
    font-size: 12px;
    color: #888;
    margin-top: 4px;
  }

  .countdown-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 2px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
    flex-shrink: 0;
  }

  .countdown-overdue { background: #ffebee; color: #c62828; }
  .countdown-soon { background: #fff3e0; color: #e65100; }
  .countdown-ok { background: #e8f5e9; color: #2e7d32; }
  .countdown-none { background: #f5f5f5; color: #888; }

  /* Questions tab */
  .question-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-left: 3px solid #ef6c00;
    padding: 14px 20px;
    margin-bottom: 10px;
    border-radius: 0 2px 2px 0;
  }

  .question-card .question-text {
    font-size: 14px;
    color: #1a1a2e;
  }

  .question-card .question-speaker {
    font-size: 12px;
    color: #888;
    margin-top: 4px;
  }

  /* Summary tab */
  .summary-section {
    background: #fff;
    border: 1px solid #e0e0e0;
    padding: 20px 24px;
    margin-bottom: 16px;
    border-radius: 2px;
  }

  .summary-section h3 {
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #888;
    margin-bottom: 12px;
  }

  .summary-text {
    font-size: 15px;
    line-height: 1.7;
    color: #333;
  }

  .attendee-list {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
  }

  .attendee-chip {
    padding: 6px 16px;
    background: #e8eaf6;
    color: #283593;
    font-size: 13px;
    font-weight: 500;
    border-radius: 2px;
  }

  .owner-breakdown {
    width: 100%;
    border-collapse: collapse;
  }

  .owner-breakdown td {
    padding: 6px 12px;
    border-bottom: 1px solid #f0f0f0;
  }

  .owner-breakdown .bar-cell {
    width: 60%;
  }

  .mini-bar {
    height: 20px;
    background: #1565c0;
    border-radius: 1px;
    min-width: 4px;
  }

  /* Export tab */
  .export-section {
    background: #fff;
    border: 1px solid #e0e0e0;
    padding: 24px;
    border-radius: 2px;
  }

  .export-btn {
    display: inline-block;
    padding: 10px 24px;
    margin: 6px 8px 6px 0;
    border: 1px solid #ccc;
    background: #fff;
    color: #333;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    border-radius: 2px;
    transition: background 0.15s, border-color 0.15s;
  }

  .export-btn:hover {
    background: #f0f0f0;
    border-color: #999;
  }

  .export-btn.primary {
    background: #1565c0;
    color: #fff;
    border-color: #1565c0;
  }

  .export-btn.primary:hover {
    background: #1255a1;
  }

  .toast {
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: #333;
    color: #fff;
    padding: 12px 24px;
    border-radius: 2px;
    font-size: 14px;
    opacity: 0;
    transition: opacity 0.3s;
    pointer-events: none;
    z-index: 100;
  }

  .toast.show { opacity: 1; }

  .empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #999;
    font-size: 14px;
  }

  @media (max-width: 768px) {
    .header, .stats-bar, .tabs, .tab-content { padding-left: 16px; padding-right: 16px; }
    .stats-bar { gap: 8px; }
    .stat-card { min-width: 80px; padding: 8px 12px; }
    .stat-card .stat-number { font-size: 22px; }
    .tab { padding: 10px 14px; font-size: 13px; }
    .followup-card { flex-direction: column; }
  }
</style>
</head>
<body>

<div class="header">
  <h1>Meeting Intelligence Dashboard</h1>
  <div class="meta" id="header-meta"></div>
</div>

<div class="stats-bar" id="stats-bar"></div>

<div class="tabs" id="tabs">
  <div class="tab active" data-tab="actions">Actions</div>
  <div class="tab" data-tab="decisions">Decisions</div>
  <div class="tab" data-tab="followups">Follow-ups</div>
  <div class="tab" data-tab="questions">Questions</div>
  <div class="tab" data-tab="summary">Summary</div>
  <div class="tab" data-tab="export">Export</div>
</div>

<div class="tab-content active" id="tab-actions">
  <div class="filter-bar">
    <label>Owner:</label>
    <select id="filter-owner"><option value="all">All</option></select>
    <label>Priority:</label>
    <select id="filter-priority">
      <option value="all">All</option>
      <option value="urgent">Urgent</option>
      <option value="normal">Normal</option>
      <option value="low">Low</option>
    </select>
    <label>Status:</label>
    <select id="filter-status">
      <option value="all">All</option>
      <option value="open">Open</option>
      <option value="done">Done</option>
    </select>
  </div>
  <table id="actions-table">
    <thead>
      <tr>
        <th class="checkbox-cell"></th>
        <th data-sort="action">Item</th>
        <th data-sort="owner">Owner</th>
        <th data-sort="deadline">Deadline</th>
        <th data-sort="priority">Priority</th>
      </tr>
    </thead>
    <tbody id="actions-body"></tbody>
  </table>
</div>

<div class="tab-content" id="tab-decisions"></div>
<div class="tab-content" id="tab-followups"></div>
<div class="tab-content" id="tab-questions"></div>
<div class="tab-content" id="tab-summary"></div>
<div class="tab-content" id="tab-export"></div>

<div class="toast" id="toast"></div>

<script>
// Data injected by Python
const ACTIONS = ''' + actions_json + ''';
const DECISIONS = ''' + decisions_json + ''';
const QUESTIONS = ''' + questions_json + ''';
const FOLLOWUPS = ''' + followups_json + ''';
const STATS = ''' + stats_json + ''';
const META = ''' + meta_json + ''';

// State
const state = {
  actions: ACTIONS.map(a => ({...a})),
  sortCol: 'priority',
  sortDir: 'desc',
};

// Priority sort order
const PRIORITY_ORDER = { urgent: 0, normal: 1, low: 2 };

// ---- Utilities ----

function esc(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const target = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  today.setHours(0,0,0,0);
  return Math.ceil((target - today) / (1000 * 60 * 60 * 24));
}

function countdownBadge(dateStr) {
  const days = daysUntil(dateStr);
  if (days === null) return '<span class="countdown-badge countdown-none">No deadline set</span>';
  if (days < 0) return '<span class="countdown-badge countdown-overdue">' + Math.abs(days) + ' day' + (Math.abs(days)!==1?'s':'') + ' overdue</span>';
  if (days === 0) return '<span class="countdown-badge countdown-overdue">Due today</span>';
  if (days <= 3) return '<span class="countdown-badge countdown-soon">' + days + ' day' + (days!==1?'s':'') + ' left</span>';
  return '<span class="countdown-badge countdown-ok">' + days + ' day' + (days!==1?'s':'') + ' left</span>';
}

// ---- Header & Stats ----

function renderHeader() {
  const parts = [];
  if (META.source_file) parts.push(esc(META.source_file));
  if (META.meeting_date) parts.push(META.meeting_date);
  if (META.extracted_at) parts.push('Processed ' + new Date(META.extracted_at).toLocaleString());
  document.getElementById('header-meta').textContent = parts.join('  |  ');
}

function renderStats() {
  const bar = document.getElementById('stats-bar');
  const urgentCount = STATS.actions_by_priority.urgent || 0;
  bar.innerHTML = `
    <div class="stat-card actions"><div class="stat-number">${STATS.total_actions}</div><div class="stat-label">Actions</div></div>
    <div class="stat-card decisions"><div class="stat-number">${STATS.total_decisions}</div><div class="stat-label">Decisions</div></div>
    <div class="stat-card questions"><div class="stat-number">${STATS.total_questions}</div><div class="stat-label">Questions</div></div>
    <div class="stat-card"><div class="stat-number">${STATS.total_followups}</div><div class="stat-label">Follow-ups</div></div>
    ${urgentCount > 0 ? '<div class="stat-card urgent"><div class="stat-number">' + urgentCount + '</div><div class="stat-label">Urgent</div></div>' : ''}
    <div class="stat-card"><div class="stat-number">${STATS.attendees.length}</div><div class="stat-label">Attendees</div></div>
  `;
}

// ---- Tabs ----

document.getElementById('tabs').addEventListener('click', function(e) {
  if (!e.target.classList.contains('tab')) return;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  e.target.classList.add('active');
  document.getElementById('tab-' + e.target.dataset.tab).classList.add('active');
});

// ---- Actions Tab ----

function populateOwnerFilter() {
  const sel = document.getElementById('filter-owner');
  const owners = [...new Set(ACTIONS.map(a => a.owner))].sort();
  owners.forEach(o => {
    const opt = document.createElement('option');
    opt.value = o;
    opt.textContent = o;
    sel.appendChild(opt);
  });
}

function getFilteredActions() {
  const ownerFilter = document.getElementById('filter-owner').value;
  const priorityFilter = document.getElementById('filter-priority').value;
  const statusFilter = document.getElementById('filter-status').value;

  let items = state.actions.slice();

  if (ownerFilter !== 'all') items = items.filter(a => a.owner === ownerFilter);
  if (priorityFilter !== 'all') items = items.filter(a => a.priority === priorityFilter);
  if (statusFilter !== 'all') items = items.filter(a => a.status === statusFilter);

  // Sort
  items.sort((a, b) => {
    let av, bv;
    if (state.sortCol === 'priority') {
      av = PRIORITY_ORDER[a.priority] || 1;
      bv = PRIORITY_ORDER[b.priority] || 1;
    } else if (state.sortCol === 'owner') {
      av = a.owner.toLowerCase();
      bv = b.owner.toLowerCase();
    } else if (state.sortCol === 'deadline') {
      av = a.deadline_date || '9999-12-31';
      bv = b.deadline_date || '9999-12-31';
    } else {
      av = a.action.toLowerCase();
      bv = b.action.toLowerCase();
    }
    if (av < bv) return state.sortDir === 'asc' ? -1 : 1;
    if (av > bv) return state.sortDir === 'asc' ? 1 : -1;
    return 0;
  });

  return items;
}

function renderActions() {
  const body = document.getElementById('actions-body');
  const items = getFilteredActions();

  if (items.length === 0) {
    body.innerHTML = '<tr><td colspan="5" class="empty-state">No action items match your filters.</td></tr>';
    return;
  }

  body.innerHTML = items.map(a => {
    const isDone = a.status === 'done';
    const deadlineDisplay = a.deadline || (a.deadline_date || '-');
    return `<tr class="${isDone ? 'done' : ''}" data-id="${a.id}">
      <td class="checkbox-cell"><input type="checkbox" ${isDone ? 'checked' : ''} /></td>
      <td>${esc(a.action)}</td>
      <td><span class="owner-badge">${esc(a.owner)}</span></td>
      <td>${esc(deadlineDisplay)}</td>
      <td><span class="priority-badge priority-${a.priority}">${a.priority}</span></td>
    </tr>`;
  }).join('');

  // Checkbox handlers
  body.querySelectorAll('input[type="checkbox"]').forEach(cb => {
    cb.addEventListener('change', function() {
      const row = this.closest('tr');
      const id = row.dataset.id;
      const action = state.actions.find(a => a.id === id);
      if (action) {
        action.status = this.checked ? 'done' : 'open';
        row.classList.toggle('done', this.checked);
      }
    });
  });

  // Update sort indicators
  document.querySelectorAll('#actions-table th[data-sort]').forEach(th => {
    th.classList.remove('sorted-asc', 'sorted-desc');
    if (th.dataset.sort === state.sortCol) {
      th.classList.add(state.sortDir === 'asc' ? 'sorted-asc' : 'sorted-desc');
    }
  });
}

// Sort headers
document.querySelectorAll('#actions-table th[data-sort]').forEach(th => {
  th.addEventListener('click', function() {
    const col = this.dataset.sort;
    if (state.sortCol === col) {
      state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
      state.sortCol = col;
      state.sortDir = col === 'priority' ? 'desc' : 'asc';
    }
    renderActions();
  });
});

// Filter handlers
['filter-owner', 'filter-priority', 'filter-status'].forEach(id => {
  document.getElementById(id).addEventListener('change', renderActions);
});

// ---- Decisions Tab ----

function renderDecisions() {
  const container = document.getElementById('tab-decisions');
  if (DECISIONS.length === 0) {
    container.innerHTML = '<div class="empty-state">No decisions were identified in this meeting.</div>';
    return;
  }
  container.innerHTML = DECISIONS.map(d => `
    <div class="decision-card">
      <div class="decision-text">${esc(d.decision)}</div>
      <div class="decision-context">${esc(d.context)}</div>
      <div class="decision-speaker">${d.speaker ? esc(d.speaker) : 'Unknown'}</div>
    </div>
  `).join('');
}

// ---- Follow-ups Tab ----

function renderFollowups() {
  const container = document.getElementById('tab-followups');

  // Combine followups and actions that have deadlines
  const items = [
    ...FOLLOWUPS.map(f => ({ text: f.item, speaker: f.speaker, deadline_date: f.deadline_date, deadline: f.deadline, type: 'followup' })),
    ...ACTIONS.filter(a => a.deadline_date).map(a => ({ text: a.action, speaker: a.owner, deadline_date: a.deadline_date, deadline: a.deadline, type: 'action' })),
  ];

  if (items.length === 0) {
    container.innerHTML = '<div class="empty-state">No follow-up items or deadlines identified.</div>';
    return;
  }

  // Sort by deadline (soonest first, no-deadline last)
  items.sort((a, b) => {
    const ad = a.deadline_date || '9999-12-31';
    const bd = b.deadline_date || '9999-12-31';
    return ad.localeCompare(bd);
  });

  container.innerHTML = items.map(f => `
    <div class="followup-card">
      <div>
        <div class="followup-text">${esc(f.text)}</div>
        <div class="followup-speaker">${f.speaker ? esc(f.speaker) : ''}${f.type === 'action' ? ' (action item)' : ''}</div>
      </div>
      ${countdownBadge(f.deadline_date)}
    </div>
  `).join('');
}

// ---- Questions Tab ----

function renderQuestions() {
  const container = document.getElementById('tab-questions');
  if (QUESTIONS.length === 0) {
    container.innerHTML = '<div class="empty-state">No open questions were identified.</div>';
    return;
  }
  container.innerHTML = QUESTIONS.map(q => `
    <div class="question-card">
      <div class="question-text">${esc(q.question)}</div>
      <div class="question-speaker">${q.speaker ? 'Raised by ' + esc(q.speaker) : ''}</div>
    </div>
  `).join('');
}

// ---- Summary Tab ----

function renderSummary() {
  const container = document.getElementById('tab-summary');

  const maxActions = Math.max(...Object.values(STATS.actions_per_owner || {}), 1);
  const ownerRows = Object.entries(STATS.actions_per_owner || {}).sort((a,b) => b[1]-a[1]).map(([owner, count]) => `
    <tr>
      <td style="width:120px;font-weight:500;">${esc(owner)}</td>
      <td class="bar-cell"><div class="mini-bar" style="width:${Math.round(count/maxActions*100)}%"></div></td>
      <td style="width:40px;text-align:right;color:#888;">${count}</td>
    </tr>
  `).join('');

  container.innerHTML = `
    <div class="summary-section">
      <h3>Meeting Summary</h3>
      <div class="summary-text" id="ai-summary">${esc(META.summary) || '<em>Summary will be added by Cowork after processing.</em>'}</div>
    </div>

    <div class="summary-section">
      <h3>Attendees</h3>
      <div class="attendee-list">
        ${STATS.attendees.map(a => '<span class="attendee-chip">' + esc(a) + '</span>').join('')}
      </div>
    </div>

    <div class="summary-section">
      <h3>Actions Per Person</h3>
      <table class="owner-breakdown">${ownerRows || '<tr><td>No actions assigned</td></tr>'}</table>
    </div>

    <div class="summary-section">
      <h3>Key Metrics</h3>
      <table class="owner-breakdown">
        <tr><td>Total words</td><td style="text-align:right;font-weight:500;">${STATS.total_words.toLocaleString()}</td></tr>
        <tr><td>Discussion segments</td><td style="text-align:right;font-weight:500;">${STATS.total_segments}</td></tr>
        <tr><td>Urgent items</td><td style="text-align:right;font-weight:500;color:#c62828;">${STATS.actions_by_priority.urgent || 0}</td></tr>
      </table>
    </div>
  `;
}

// ---- Export Tab ----

function renderExport() {
  const container = document.getElementById('tab-export');
  container.innerHTML = `
    <div class="export-section">
      <h3 style="font-size:14px;text-transform:uppercase;letter-spacing:0.5px;color:#888;margin-bottom:16px;">Export Options</h3>
      <p style="margin-bottom:16px;color:#666;font-size:14px;">Download or copy meeting data in various formats.</p>
      <button class="export-btn primary" onclick="exportCSV()">Export Actions as CSV</button>
      <button class="export-btn" onclick="exportMarkdown()">Export All as Markdown</button>
      <button class="export-btn" onclick="copyFollowupEmail()">Copy Follow-up Email</button>
      <button class="export-btn" onclick="exportJSON()">Download Raw JSON</button>
    </div>
  `;
}

function exportCSV() {
  const rows = [['Status','Item','Owner','Deadline','Priority']];
  state.actions.forEach(a => {
    rows.push([a.status, a.action, a.owner, a.deadline || '', a.priority]);
  });
  const csv = rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\\n');
  downloadFile('meeting-actions.csv', csv, 'text/csv');
  showToast('CSV downloaded');
}

function exportMarkdown() {
  let md = '# Meeting Report | ' + (META.meeting_date || 'Unknown Date') + '\\n\\n';
  md += '## Summary\\n' + (META.summary || 'No summary available.') + '\\n\\n';

  md += '## Action Items\\n\\n| # | Owner | Action | Deadline | Priority | Status |\\n|---|-------|--------|----------|----------|--------|\\n';
  state.actions.forEach((a, i) => {
    md += '| ' + (i+1) + ' | ' + a.owner + ' | ' + a.action + ' | ' + (a.deadline || '-') + ' | ' + a.priority + ' | ' + a.status + ' |\\n';
  });

  md += '\\n## Decisions\\n\\n';
  DECISIONS.forEach((d, i) => {
    md += (i+1) + '. **' + d.decision + '**' + (d.speaker ? ' (' + d.speaker + ')' : '') + '\\n';
  });

  md += '\\n## Open Questions\\n\\n';
  QUESTIONS.forEach(q => {
    md += '- ' + q.question + (q.speaker ? ' (' + q.speaker + ')' : '') + '\\n';
  });

  md += '\\n## Follow-ups\\n\\n';
  FOLLOWUPS.forEach(f => {
    md += '- [ ] ' + f.item + (f.speaker ? ' (' + f.speaker + ')' : '') + '\\n';
  });

  downloadFile('meeting-report.md', md, 'text/markdown');
  showToast('Markdown downloaded');
}

function copyFollowupEmail() {
  let email = 'Subject: Action items from our meeting (' + (META.meeting_date || 'today') + ')\\n\\n';
  email += 'Hi everyone,\\n\\n';
  email += 'Thanks for the meeting. Here is a quick recap of what was agreed and what needs to happen next.\\n\\n';

  if (DECISIONS.length > 0) {
    email += 'DECISIONS:\\n';
    DECISIONS.forEach(d => { email += '- ' + d.decision + '\\n'; });
    email += '\\n';
  }

  email += 'ACTION ITEMS:\\n';
  state.actions.forEach(a => {
    email += '- [' + a.owner + '] ' + a.action;
    if (a.deadline) email += ' (' + a.deadline + ')';
    email += '\\n';
  });

  if (QUESTIONS.length > 0) {
    email += '\\nOPEN QUESTIONS (still to be resolved):\\n';
    QUESTIONS.forEach(q => { email += '- ' + q.question + '\\n'; });
  }

  email += '\\nPlease flag anything I missed or got wrong.\\n\\nThanks,\\n[Your name]';

  navigator.clipboard.writeText(email).then(() => showToast('Follow-up email copied to clipboard'));
}

function exportJSON() {
  const data = { meta: META, stats: STATS, actions: state.actions, decisions: DECISIONS, questions: QUESTIONS, followups: FOLLOWUPS };
  downloadFile('meeting-data.json', JSON.stringify(data, null, 2), 'application/json');
  showToast('JSON downloaded');
}

function downloadFile(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ---- Init ----

renderHeader();
renderStats();
populateOwnerFilter();
renderActions();
renderDecisions();
renderFollowups();
renderQuestions();
renderSummary();
renderExport();

</script>
</body>
</html>'''


# ---------------------------------------------------------------------------
# CSV Export
# ---------------------------------------------------------------------------

def write_actions_csv(actions, output_path):
    """Write actions to a CSV file."""
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Status', 'Item', 'Owner', 'Deadline', 'Priority'])
        for a in actions:
            writer.writerow([a['status'], a['action'], a['owner'], a['deadline'] or '', a['priority']])


# ---------------------------------------------------------------------------
# File reading
# ---------------------------------------------------------------------------

def read_transcript(filepath):
    path = Path(filepath)
    if not path.exists():
        print("Error: File not found: %s" % filepath, file=sys.stderr)
        sys.exit(1)

    text = path.read_text(encoding='utf-8', errors='replace')

    if path.suffix.lower() == '.vtt':
        text = re.sub(r'^WEBVTT\s*\n(Kind:.*\n)?(Language:.*\n)?\n?', '', text, count=1)

    return text


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description='Extract action items, decisions, questions, and follow-ups from a meeting transcript.'
    )
    parser.add_argument('transcript', help='Path to transcript file (.txt, .md, .vtt, .srt)')
    parser.add_argument('--output-dir', '-d', help='Output directory (default: same as input file)')
    args = parser.parse_args()

    input_path = Path(args.transcript)
    output_dir = Path(args.output_dir) if args.output_dir else input_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)

    # Read and parse
    raw_text = read_transcript(args.transcript)
    segments = parse_transcript(raw_text)

    if not segments:
        print("Error: No content found in transcript.", file=sys.stderr)
        sys.exit(1)

    speakers = detect_speakers(segments)

    # Also check for @mentions
    mentioned = detect_attendees_from_mentions(raw_text)
    for name in mentioned:
        if name not in speakers:
            speakers.append(name)

    # Extract
    actions = extract_actions(segments, speakers)
    decisions = extract_decisions(segments)
    questions = extract_questions(segments)

    action_norms = set(a['action'].lower()[:60] for a in actions)
    followups = extract_followups(segments, action_norms)

    stats = build_stats(speakers, actions, decisions, questions, followups, segments)

    # Build result
    now = datetime.now()
    data = {
        'source_file': input_path.name,
        'meeting_date': now.strftime('%Y-%m-%d'),
        'extracted_at': now.isoformat(),
        'speakers': speakers,
        'summary': '',  # Placeholder for Cowork AI summary
        'actions': actions,
        'decisions': decisions,
        'questions': questions,
        'followups': followups,
        'stats': stats,
        'segment_count': len(segments),
        'word_count': sum(len(s['text'].split()) for s in segments),
    }

    # Write outputs
    json_path = output_dir / 'meeting-data.json'
    html_path = output_dir / 'meeting-dashboard.html'
    csv_path = output_dir / 'actions-export.csv'

    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(generate_dashboard_html(data))

    write_actions_csv(actions, csv_path)

    # Print summary to stdout
    print("Meeting Intelligence Report")
    print("=" * 40)
    print("Source: %s" % input_path.name)
    print("Date: %s" % data['meeting_date'])
    print("Attendees: %s" % ', '.join(speakers) if speakers else 'Unknown')
    print()
    print("Extracted:")
    print("  %d action items" % len(actions))
    print("  %d decisions" % len(decisions))
    print("  %d open questions" % len(questions))
    print("  %d follow-up items" % len(followups))
    print()

    if actions:
        print("Action Items:")
        for i, a in enumerate(actions, 1):
            deadline = " [%s]" % a['deadline'] if a['deadline'] else ""
            priority_marker = " (!)" if a['priority'] == 'urgent' else ""
            print("  %d. [%s] %s%s%s" % (i, a['owner'], a['action'], deadline, priority_marker))
        print()

    if decisions:
        print("Decisions:")
        for i, d in enumerate(decisions, 1):
            print("  %d. %s" % (i, d['decision']))
        print()

    print("Output files:")
    print("  JSON: %s" % json_path)
    print("  HTML: %s" % html_path)
    print("  CSV:  %s" % csv_path)


if __name__ == '__main__':
    main()
